import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bookmark,
  Check,
  ChevronLeft,
  ChevronRight,
  Download,
  FileText,
  Highlighter,
  Mic,
  MicOff,
  Search,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { BookNote, LibraryResource } from '../types/gramGyan';

interface BrowserSpeechRecognition {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type ReaderTheme = 'light' | 'sepia' | 'dark';

interface BookReaderModalProps {
  book: LibraryResource;
  isBookmarked: boolean;
  isDownloaded: boolean;
  isFinished: boolean;
  initialChapter: number;
  notes: BookNote[];
  lowDataMode: boolean;
  onClose: () => void;
  onToggleBookmark: (bookId: string) => void;
  onToggleDownload: (bookId: string) => void;
  onMarkFinished: (bookId: string) => void;
  onLogReadingMinutes: (minutes: number) => void;
  onProgressChange: (bookId: string, chapterIndex: number) => void;
  onAddNote: (bookId: string, chapterIndex: number, text: string) => void;
  onDeleteNote: (noteId: string) => void;
}

export const BookReaderModal: React.FC<BookReaderModalProps> = ({
  book,
  isBookmarked,
  isDownloaded,
  isFinished,
  initialChapter,
  notes,
  lowDataMode,
  onClose,
  onToggleBookmark,
  onToggleDownload,
  onMarkFinished,
  onLogReadingMinutes,
  onProgressChange,
  onAddNote,
  onDeleteNote,
}) => {
  const [chapterIndex, setChapterIndex] = useState(
    Math.min(Math.max(0, initialChapter), Math.max(0, book.chapters.length - 1))
  );
  const [theme, setTheme] = useState<ReaderTheme>('sepia');
  const [fontSize, setFontSize] = useState<number>(17);
  const [searchTerm, setSearchTerm] = useState('');
  const [showNotesPanel, setShowNotesPanel] = useState(false);
  const [noteInput, setNoteInput] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isRecordingNote, setIsRecordingNote] = useState(false);
  const [voiceNoteError, setVoiceNoteError] = useState<string | null>(null);
  const recognitionRef = useRef<BrowserSpeechRecognition | null>(null);

  const chapter = book.chapters[chapterIndex] ?? book.chapters[0];
  const bookNotes = notes.filter((n) => n.bookId === book.id);

  useEffect(() => {
    onProgressChange(book.id, chapterIndex);
  }, [book.id, chapterIndex, onProgressChange]);

  const logMinutesRef = useRef(onLogReadingMinutes);
  useEffect(() => {
    logMinutesRef.current = onLogReadingMinutes;
  }, [onLogReadingMinutes]);

  useEffect(() => {
    const startTime = Date.now();
    return () => {
      const elapsedMinutes = Math.max(1, Math.round((Date.now() - startTime) / 60000));
      logMinutesRef.current(elapsedMinutes);
      recognitionRef.current?.abort();
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const getRecognitionLang = () => {
    const langLower = book.language.toLowerCase();
    if (langLower.includes('hindi') || langLower.includes('dogri')) return 'hi-IN';
    if (langLower.includes('urdu') || langLower.includes('kashmiri')) return 'ur-IN';
    return 'en-IN';
  };

  const handleVoiceNoteToggle = () => {
    setShowNotesPanel(true);

    if (isRecordingNote) {
      recognitionRef.current?.stop();
      setIsRecordingNote(false);
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => BrowserSpeechRecognition;
      webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
    };
    const RecognitionCtor = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!RecognitionCtor) {
      setVoiceNoteError('Voice dictation is not supported in this browser. Please type your note below.');
      return;
    }

    setVoiceNoteError(null);
    const recognition = new RecognitionCtor();
    recognition.lang = getRecognitionLang();
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript?.trim() ?? '';
      if (transcript) {
        setNoteInput((prev) => {
          const combined = prev.trim() ? `${prev.trim()} ${transcript}` : transcript;
          return combined.slice(0, 1000);
        });
      }
    };

    recognition.onerror = (event) => {
      setIsRecordingNote(false);
      recognitionRef.current = null;
      if (event?.error === 'not-allowed' || event?.error === 'service-not-allowed') {
        setVoiceNoteError('Microphone permission denied. Please allow mic access or type your note.');
      } else {
        setVoiceNoteError('Could not capture voice clearly. Please try again or type your note.');
      }
    };

    recognition.onend = () => {
      setIsRecordingNote(false);
      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    setIsRecordingNote(true);
    try {
      recognition.start();
    } catch {
      setIsRecordingNote(false);
      recognitionRef.current = null;
      setVoiceNoteError('Unable to start microphone right now. Please try again.');
    }
  };

  const handleReadAloud = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(`${chapter.title}. ${chapter.content}`);
    utterance.lang = book.language.toLowerCase().includes('hindi') ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const searchMatches = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return [];
    return book.chapters
      .map((ch, idx) => ({
        idx,
        title: ch.title,
        matches: ch.content.toLowerCase().includes(q) || ch.title.toLowerCase().includes(q),
      }))
      .filter((item) => item.matches);
  }, [book.chapters, searchTerm]);

  const themeClasses: Record<ReaderTheme, string> = {
    light: 'bg-white text-slate-900 border-slate-200',
    sepia: 'bg-[#F8F1E3] text-[#2C2218] border-[#E3D5BC]',
    dark: 'bg-slate-950 text-slate-100 border-slate-800',
  };

  const subSurfaceClasses: Record<ReaderTheme, string> = {
    light: 'bg-slate-50 border-slate-200 text-slate-700',
    sepia: 'bg-[#EFE4CE] border-[#DFCFAF] text-[#4B3A26]',
    dark: 'bg-slate-900 border-slate-800 text-slate-300',
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteInput.trim()) return;
    onAddNote(book.id, chapterIndex, noteInput.trim());
    setNoteInput('');
  };

  const renderHighlightedParagraph = (paragraph: string) => {
    const q = searchTerm.trim();
    if (!q) return paragraph;
    const escaped = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const parts = paragraph.split(new RegExp(`(${escaped})`, 'gi'));
    const lowerQ = q.toLowerCase();
    return parts.map((part, idx) =>
      part.toLowerCase() === lowerQ ? (
        <mark key={idx} className="bg-amber-300 text-slate-900 px-0.5 rounded">
          {part}
        </mark>
      ) : (
        <React.Fragment key={idx}>{part}</React.Fragment>
      )
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-2 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`Reading ${book.title}`}
    >
      <div
        className={`w-full max-w-5xl h-[92vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${themeClasses[theme]}`}
      >
        {/* Top Reader Bar */}
        <div className={`px-4 sm:px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 ${subSurfaceClasses[theme]}`}>
          <div className="min-w-0 flex-1">
            <h2 className="font-display font-semibold text-base sm:text-lg truncate">{book.title}</h2>
            <p className="text-xs opacity-80 truncate">
              {book.author} · {book.language} · Verified {book.lastVerified}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Theme Switcher */}
            <div className="flex items-center rounded-lg border border-current/15 p-0.5 text-xs">
              {(['light', 'sepia', 'dark'] as ReaderTheme[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTheme(t)}
                  className={`px-2.5 py-1 rounded-md capitalize font-medium transition-colors whitespace-nowrap ${
                    theme === t ? 'bg-emerald-700 text-white' : 'hover:bg-black/5 dark:hover:bg-white/10'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Font Size Controls */}
            <div className="flex items-center rounded-lg border border-current/15 text-xs">
              <button
                type="button"
                onClick={() => setFontSize((s) => Math.max(14, s - 2))}
                className="px-2.5 py-1.5 hover:bg-black/5 font-semibold"
                aria-label="Decrease text size"
              >
                A-
              </button>
              <span className="px-1.5 font-mono tabular-nums">{fontSize}</span>
              <button
                type="button"
                onClick={() => setFontSize((s) => Math.min(24, s + 2))}
                className="px-2.5 py-1.5 hover:bg-black/5 font-semibold"
                aria-label="Increase text size"
              >
                A+
              </button>
            </div>

            {/* Text-to-Speech */}
            <button
              type="button"
              onClick={handleReadAloud}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap ${
                isSpeaking
                  ? 'bg-amber-600 text-white border-amber-600'
                  : 'border-current/20 hover:bg-black/5'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              {isSpeaking ? 'Stop Audio' : 'Listen'}
            </button>

            {/* Bookmark */}
            <button
              type="button"
              onClick={() => onToggleBookmark(book.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap ${
                isBookmarked
                  ? 'bg-emerald-700 text-white border-emerald-700'
                  : 'border-current/20 hover:bg-black/5'
              }`}
            >
              <Bookmark className="w-4 h-4" />
              {isBookmarked ? 'Saved' : 'Bookmark'}
            </button>

            {/* Offline Download */}
            <button
              type="button"
              onClick={() => onToggleDownload(book.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap ${
                isDownloaded
                  ? 'bg-emerald-700 text-white border-emerald-700'
                  : 'border-current/20 hover:bg-black/5'
              }`}
            >
              {isDownloaded ? <Check className="w-4 h-4" /> : <Download className="w-4 h-4" />}
              {isDownloaded ? 'Offline Ready' : `Save (${lowDataMode ? book.lowDataSizeKb : book.sizeKb} KB)`}
            </button>

            {/* Highlight / Notes */}
            <button
              type="button"
              onClick={() => setShowNotesPanel((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-current/20 hover:bg-black/5 whitespace-nowrap"
            >
              <Highlighter className="w-4 h-4" />
              Notes ({bookNotes.length})
            </button>

            {/* Quick Voice Note */}
            <button
              type="button"
              onClick={handleVoiceNoteToggle}
              aria-label={isRecordingNote ? 'Stop voice note dictation' : 'Dictate voice note for this chapter'}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap ${
                isRecordingNote
                  ? 'bg-rose-600 text-white border-rose-600'
                  : 'border-current/20 hover:bg-black/5'
              }`}
            >
              {isRecordingNote ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              {isRecordingNote ? 'Stop Mic' : 'Voice Note'}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-black/10 transition-colors"
              aria-label="Close reader"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search & Chapter Strip */}
        <div className={`px-4 sm:px-6 py-2.5 border-b flex flex-wrap items-center justify-between gap-3 ${subSurfaceClasses[theme]}`}>
          <div className="flex items-center gap-2 overflow-x-auto max-w-full">
            {book.chapters.map((ch, idx) => (
              <button
                key={ch.title}
                type="button"
                onClick={() => setChapterIndex(idx)}
                className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  idx === chapterIndex
                    ? 'bg-emerald-700 text-white'
                    : 'hover:bg-black/5 opacity-80'
                }`}
              >
                Part {idx + 1}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 opacity-60" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search inside this book..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-current/20 bg-transparent focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>
        </div>

        {/* Search Match Notice */}
        {searchTerm.trim() && (
          <div className={`px-6 py-2 text-xs border-b flex items-center gap-3 flex-wrap ${subSurfaceClasses[theme]}`}>
            <span>
              Found in {searchMatches.length} section{searchMatches.length === 1 ? '' : 's'}:
            </span>
            {searchMatches.map((m) => (
              <button
                key={m.idx}
                type="button"
                onClick={() => setChapterIndex(m.idx)}
                className="underline font-medium hover:opacity-80"
              >
                {m.title}
              </button>
            ))}
          </div>
        )}

        {/* Main Content + Optional Notes Drawer */}
        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 overflow-y-auto px-6 sm:px-14 py-8">
            <article className="max-w-2xl mx-auto space-y-6">
              <div className="space-y-2 pb-4 border-b border-current/15">
                <p className="text-xs font-medium opacity-75">
                  {book.category} · Source: {book.source}
                </p>
                <h3 className="font-display font-bold text-2xl sm:text-3xl leading-tight">
                  {chapter.title}
                </h3>
              </div>

              <div className="space-y-5 leading-relaxed" style={{ fontSize: `${fontSize}px` }}>
                {chapter.content.split('\n\n').map((para, i) => (
                  <p key={i}>{renderHighlightedParagraph(para)}</p>
                ))}
              </div>

              {/* Provenance & Licensing Box */}
              <div className={`mt-10 p-4 rounded-xl border text-xs space-y-1 ${subSurfaceClasses[theme]}`}>
                <div className="font-semibold flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  Resource Verification & Licensing
                </div>
                <p>
                  Publisher / Source: {book.source} · Published: {book.publicationDate}
                </p>
                <p>
                  License: {book.copyrightStatus} · Last Verified: {book.lastVerified}
                </p>
              </div>
            </article>
          </div>

          {showNotesPanel && (
            <aside className={`w-full sm:w-80 border-l p-4 flex flex-col gap-4 overflow-y-auto ${subSurfaceClasses[theme]}`}>
              <div>
                <h4 className="font-display font-semibold text-sm">Personal Highlights & Notes</h4>
                <p className="text-xs opacity-75">Saved offline on your device for Part {chapterIndex + 1}.</p>
              </div>

              <form onSubmit={handleSaveNote} className="space-y-2">
                <textarea
                  rows={3}
                  maxLength={1000}
                  value={noteInput}
                  onChange={(e) => setNoteInput(e.target.value)}
                  placeholder="Write or dictate an important point for this chapter..."
                  className="w-full p-2.5 text-xs rounded-lg border border-current/20 bg-transparent focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                {voiceNoteError && (
                  <p className="text-[11px] text-rose-600 dark:text-rose-400 leading-snug">
                    {voiceNoteError}
                  </p>
                )}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleVoiceNoteToggle}
                    aria-label={isRecordingNote ? 'Stop voice dictation' : 'Speak note using microphone'}
                    className={`py-2 px-3 rounded-lg border text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                      isRecordingNote
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'border-current/20 hover:bg-black/5'
                    }`}
                  >
                    {isRecordingNote ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                    {isRecordingNote ? 'Listening...' : 'Dictate'}
                  </button>
                  <button
                    type="submit"
                    disabled={!noteInput.trim()}
                    className="flex-1 py-2 px-3 rounded-lg bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 disabled:opacity-50 transition-colors"
                  >
                    Save Note
                  </button>
                </div>
              </form>

              <div className="space-y-2.5">
                {bookNotes.length === 0 ? (
                  <p className="text-xs opacity-70">No notes saved for this book yet.</p>
                ) : (
                  bookNotes.map((n) => (
                    <div key={n.id} className="p-3 rounded-lg border border-current/15 text-xs space-y-1.5">
                      <div className="flex items-center justify-between opacity-75">
                        <span>Part {n.chapterIndex + 1} · {n.createdAt}</span>
                        <button
                          type="button"
                          onClick={() => onDeleteNote(n.id)}
                          className="text-rose-600 hover:underline"
                        >
                          Remove
                        </button>
                      </div>
                      <p className="leading-relaxed">{n.text}</p>
                    </div>
                  ))
                )}
              </div>
            </aside>
          )}
        </div>

        {/* Bottom Chapter Navigation */}
        <div className={`px-6 py-3 border-t flex items-center justify-between text-xs ${subSurfaceClasses[theme]}`}>
          <button
            type="button"
            disabled={chapterIndex === 0}
            onClick={() => setChapterIndex((i) => Math.max(0, i - 1))}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-current/20 disabled:opacity-40 hover:bg-black/5"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous Part
          </button>
          <div className="flex items-center gap-3">
            <span className="font-mono tabular-nums">
              Part {chapterIndex + 1} of {book.chapters.length}
            </span>
            <button
              type="button"
              onClick={() => onMarkFinished(book.id)}
              disabled={isFinished}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                isFinished
                  ? 'bg-emerald-700 text-white opacity-90'
                  : 'border border-emerald-700 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-700 hover:text-white'
              }`}
            >
              <Check className="w-3.5 h-3.5" />
              {isFinished ? 'Finished' : 'Mark Finished'}
            </button>
          </div>
          <button
            type="button"
            disabled={chapterIndex >= book.chapters.length - 1}
            onClick={() => setChapterIndex((i) => Math.min(book.chapters.length - 1, i + 1))}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-current/20 disabled:opacity-40 hover:bg-black/5"
          >
            Next Part
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
