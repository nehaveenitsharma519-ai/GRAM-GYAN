import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Globe2,
  MapPin,
  Plus,
  Search,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { VILLAGE_REGIONS } from '../data/villagesData';
import { UserLocation, VillageEntry, VillageRegion } from '../types/gramGyan';

export interface NewVillageDraft {
  name: string;
  blockOrTehsil: string;
  district: string;
  stateOrProvince: string;
  country: string;
  region: VillageRegion;
  populationApprox: string;
  highlights: string;
}

interface VillageDirectoryPanelProps {
  villages: VillageEntry[];
  currentLocation: UserLocation;
  onSelectVillage: (village: VillageEntry) => void;
  onAddVillage: (draft: NewVillageDraft, setAsActive: boolean) => Promise<void>;
  onDeleteCustomVillage: (villageId: string) => Promise<void>;
  initialShowAddForm?: boolean;
  isCloudSynced?: boolean;
  compactHeader?: boolean;
}

const QUICK_SEARCH_CHIPS = ['Bhaderwah', 'Kathua', 'Drodhu', 'Doda', 'Baramulla', 'Japan', 'Switzerland'];

export const VillageDirectoryPanel: React.FC<VillageDirectoryPanelProps> = ({
  villages,
  currentLocation,
  onSelectVillage,
  onAddVillage,
  onDeleteCustomVillage,
  initialShowAddForm = false,
  isCloudSynced = false,
  compactHeader = false,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<'All' | 'Custom' | VillageRegion>('All');
  const [showAddForm, setShowAddForm] = useState(initialShowAddForm);
  const [showAllRows, setShowAllRows] = useState(false);

  // Add Village form state
  const [name, setName] = useState('');
  const [blockOrTehsil, setBlockOrTehsil] = useState('');
  const [district, setDistrict] = useState('');
  const [stateOrProvince, setStateOrProvince] = useState('Jammu & Kashmir');
  const [country, setCountry] = useState('India');
  const [region, setRegion] = useState<VillageRegion>('Jammu & Kashmir');
  const [populationApprox, setPopulationApprox] = useState('');
  const [highlights, setHighlights] = useState('');
  const [setAsActive, setSetAsActive] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const stats = useMemo(() => {
    const jkCount = villages.filter((v) => v.region === 'Jammu & Kashmir').length;
    const indiaCount = villages.filter((v) => v.region === 'All India').length;
    const worldCount = villages.filter(
      (v) => v.region !== 'Jammu & Kashmir' && v.region !== 'All India'
    ).length;
    const customCount = villages.filter((v) => v.isCustom).length;
    return {
      total: villages.length,
      jkCount,
      indiaCount,
      worldCount,
      customCount,
    };
  }, [villages]);

  const filteredVillages = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return villages.filter((v) => {
      if (selectedRegion === 'Custom' && !v.isCustom) return false;
      if (selectedRegion !== 'All' && selectedRegion !== 'Custom' && v.region !== selectedRegion) {
        return false;
      }
      if (!q) return true;
      const haystack = `${v.name} ${v.blockOrTehsil} ${v.district} ${v.stateOrProvince} ${v.country} ${v.region} ${v.highlights}`.toLowerCase();
      return haystack.includes(q);
    });
  }, [villages, searchQuery, selectedRegion]);

  const visibleVillages = useMemo(() => {
    if (showAllRows || searchQuery.trim() || selectedRegion !== 'All') {
      return filteredVillages;
    }
    return filteredVillages.slice(0, 24);
  }, [filteredVillages, showAllRows, searchQuery, selectedRegion]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim().slice(0, 80);
    const cleanDistrict = district.trim().slice(0, 80);
    const cleanState = stateOrProvince.trim().slice(0, 80);
    const cleanCountry = country.trim().slice(0, 80);
    const cleanBlock = (blockOrTehsil.trim() || cleanName).slice(0, 80);
    const cleanHighlights = (
      highlights.trim() || `Citizen village community in ${cleanDistrict || cleanCountry}`
    ).slice(0, 300);

    if (!cleanName || !cleanDistrict || !cleanState || !cleanCountry) {
      setFormError('Please enter Village Name, District/County, State/Region, and Country.');
      return;
    }

    setFormError(null);
    setSubmitting(true);
    try {
      await onAddVillage(
        {
          name: cleanName,
          blockOrTehsil: cleanBlock,
          district: cleanDistrict,
          stateOrProvince: cleanState,
          country: cleanCountry,
          region,
          populationApprox: (populationApprox.trim() || 'Community').slice(0, 40),
          highlights: cleanHighlights,
        },
        setAsActive
      );
      setName('');
      setBlockOrTehsil('');
      setDistrict('');
      setPopulationApprox('');
      setHighlights('');
      setSavedNotice(
        `${cleanName} (${cleanDistrict}, ${cleanCountry}) added to the Village Directory${setAsActive ? ' & set as active location' : ''}.`
      );
      setTimeout(() => setSavedNotice(null), 5000);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Unable to save village right now.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
      {/* Header & Add Village Trigger */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="space-y-1 max-w-2xl">
          <div className="flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-emerald-700 dark:text-emerald-400 shrink-0" />
            <h3 className={`font-display font-bold ${compactHeader ? 'text-lg' : 'text-xl sm:text-2xl'}`}>
              World &amp; India Villages Directory ({stats.total})
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Explore Bhaderwah, Kathua, Drodhu (Dradhu), Doda, Baramulla, Indian Gram Panchayats &amp; iconic villages across the world — or add your own village anytime.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddForm((prev) => !prev)}
          className={`min-h-[42px] px-4 py-2 rounded-xl text-xs sm:text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
            showAddForm
              ? 'border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              : 'bg-emerald-700 text-white hover:bg-emerald-800 shadow-sm'
          }`}
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showAddForm ? 'Close Add Form' : 'Add Your Village'}
        </button>
      </div>

      {/* Coverage KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
          <div className="font-mono font-bold text-lg tabular-nums text-emerald-700 dark:text-emerald-400">
            {stats.jkCount}
          </div>
          <div className="text-slate-600 dark:text-slate-400">J&amp;K &amp; Ladakh Villages</div>
        </div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
          <div className="font-mono font-bold text-lg tabular-nums text-emerald-700 dark:text-emerald-400">
            {stats.indiaCount}
          </div>
          <div className="text-slate-600 dark:text-slate-400">All India Villages</div>
        </div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
          <div className="font-mono font-bold text-lg tabular-nums text-emerald-700 dark:text-emerald-400">
            {stats.worldCount}
          </div>
          <div className="text-slate-600 dark:text-slate-400">World Villages</div>
        </div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
          <div className="font-mono font-bold text-lg tabular-nums text-emerald-700 dark:text-emerald-400">
            {stats.customCount}
          </div>
          <div className="text-slate-600 dark:text-slate-400">
            Added Villages {isCloudSynced ? '(Cloud Synced)' : '(Local)'}
          </div>
        </div>
      </div>

      {/* Add Village Form */}
      {showAddForm && (
        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="p-4 sm:p-5 rounded-2xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/20 space-y-4"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="font-display font-semibold text-sm sm:text-base flex items-center gap-2 text-emerald-900 dark:text-emerald-200">
              <Sparkles className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              Add Any Village (J&amp;K, India, or Worldwide)
            </div>
            <span className="text-[11px] text-slate-500">
              {isCloudSynced ? 'Synced to your verified Firestore profile' : 'Saved locally (Sign in to sync across devices)'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs sm:text-sm">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Village / Town Name *
              </label>
              <input
                type="text"
                required
                maxLength={80}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Drodhu, Bhaderwah, Kathua, Shirakawa..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Block / Tehsil / Sub-district
              </label>
              <input
                type="text"
                maxLength={80}
                value={blockOrTehsil}
                onChange={(e) => setBlockOrTehsil(e.target.value)}
                placeholder="e.g., Chinta, Billawar, Hiranagar"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                District / County *
              </label>
              <input
                type="text"
                required
                maxLength={80}
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="e.g., Doda, Kathua, Baramulla"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                State / Province *
              </label>
              <input
                type="text"
                required
                maxLength={80}
                value={stateOrProvince}
                onChange={(e) => setStateOrProvince(e.target.value)}
                placeholder="e.g., Jammu & Kashmir, Himachal Pradesh"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Country *
              </label>
              <input
                type="text"
                required
                maxLength={80}
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="e.g., India, Japan, Switzerland"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Region *
              </label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value as VillageRegion)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              >
                {VILLAGE_REGIONS.map((reg) => (
                  <option key={reg} value={reg}>
                    {reg}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Approx. Population (Optional)
              </label>
              <input
                type="text"
                maxLength={40}
                value={populationApprox}
                onChange={(e) => setPopulationApprox(e.target.value)}
                placeholder="e.g., ~2,400"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Village Highlights / Crops / Notes
              </label>
              <input
                type="text"
                maxLength={300}
                value={highlights}
                onChange={(e) => setHighlights(e.target.value)}
                placeholder="e.g., Famous for organic rajmash, maize, sheep farming & mountain springs"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
              />
            </div>
          </div>

          {formError && (
            <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">{formError}</p>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={setAsActive}
                onChange={(e) => setSetAsActive(e.target.checked)}
                className="w-4 h-4 accent-emerald-700"
              />
              Set as my active GRAM GYAN village location right after saving
            </label>

            <button
              type="submit"
              disabled={submitting}
              className="min-h-[40px] px-5 py-2 rounded-xl bg-emerald-700 text-white text-xs sm:text-sm font-medium hover:bg-emerald-800 disabled:opacity-50 inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              {submitting ? 'Saving Village...' : 'Save Village to Directory'}
            </button>
          </div>
        </form>
      )}

      {savedNotice && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{savedNotice}</span>
        </div>
      )}

      {/* Search & Region Filter Controls */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search any village (Bhaderwah, Kathua, Drodhu, Japan, Switzerland, country...)"
              className="w-full min-h-[42px] pl-10 pr-9 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear village search"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {QUICK_SEARCH_CHIPS.map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() => {
                  setSelectedRegion('All');
                  setSearchQuery((prev) => (prev.toLowerCase() === chip.toLowerCase() ? '' : chip));
                }}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                  searchQuery.toLowerCase() === chip.toLowerCase()
                    ? 'bg-emerald-700 text-white border-emerald-700'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-emerald-600'
                }`}
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* Region Filter Tabs */}
        <div className="flex flex-wrap gap-1.5">
          {(['All', ...VILLAGE_REGIONS, 'Custom'] as const).map((tab) => {
            const label = tab === 'All' ? 'All World Villages' : tab === 'Custom' ? `Added Villages (${stats.customCount})` : tab;
            const active = selectedRegion === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setSelectedRegion(tab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-emerald-700 text-white border-emerald-700'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Filtered Villages Grid */}
      {visibleVillages.length === 0 ? (
        <div className="p-6 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-2">
          <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
            No matching village found for “{searchQuery || selectedRegion}”.
          </p>
          <p className="text-xs text-slate-500">
            Want to list this village? Tap “Add Your Village” above and save it to the global directory!
          </p>
          {!showAddForm && (
            <button
              type="button"
              onClick={() => {
                if (searchQuery.trim()) setName(searchQuery.trim().slice(0, 80));
                setShowAddForm(true);
              }}
              className="mt-1 px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 inline-flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Add “{searchQuery.trim() || 'New Village'}” Now
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {visibleVillages.map((village) => {
              const isActive =
                currentLocation.panchayat.toLowerCase() === village.name.toLowerCase() ||
                (currentLocation.district.toLowerCase() === village.district.toLowerCase() &&
                  currentLocation.panchayat.toLowerCase() === village.blockOrTehsil.toLowerCase());

              return (
                <div
                  key={village.id}
                  className={`p-4 rounded-xl border flex flex-col justify-between gap-3 transition-colors ${
                    isActive
                      ? 'border-emerald-600 bg-emerald-50/40 dark:bg-emerald-950/20'
                      : 'border-slate-200 dark:border-slate-800 hover:border-emerald-500/60'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                          <MapPin className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                          <span className="truncate">{village.name}</span>
                        </div>
                        <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 mt-0.5">
                          {village.region} · {village.country}
                        </p>
                      </div>

                      {village.isCustom && (
                        <button
                          type="button"
                          onClick={() => void onDeleteCustomVillage(village.id)}
                          aria-label={`Delete custom village ${village.name}`}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {village.blockOrTehsil} · {village.district} District · {village.stateOrProvince}
                      {village.populationApprox ? ` · Pop. ${village.populationApprox}` : ''}
                    </p>

                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                      {village.highlights}
                    </p>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-medium text-slate-500">
                      {village.isCustom ? 'Citizen Added' : 'Verified Directory'}
                    </span>
                    <button
                      type="button"
                      onClick={() => onSelectVillage(village)}
                      className={`min-h-[34px] px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        isActive
                          ? 'bg-emerald-700 text-white'
                          : 'border border-emerald-700 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                      }`}
                    >
                      {isActive ? 'Active Location' : 'Set Active Location'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {!searchQuery.trim() && selectedRegion === 'All' && filteredVillages.length > 24 && (
            <div className="flex justify-center pt-1">
              <button
                type="button"
                onClick={() => setShowAllRows((prev) => !prev)}
                className="min-h-[40px] px-5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {showAllRows
                  ? 'Show Fewer Villages'
                  : `Show All ${filteredVillages.length} World & India Villages`}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};
