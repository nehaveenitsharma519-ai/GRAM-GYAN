import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  History,
  ImagePlus,
  Loader2,
  RefreshCw,
  ScanLine,
  ShieldAlert,
  Sparkles,
  Sprout,
  StopCircle,
  SwitchCamera,
  Trash2,
  Upload,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { LANGUAGES } from '../data/translations';
import { CropDetectionResult, CropScanHistoryItem, LanguageCode } from '../types/gramGyan';

const SCAN_HISTORY_STORAGE_KEY = 'gg_crop_scans_v1';

const DETECTOR_OUTPUT_LANGUAGES = [
  { id: 'auto', label: 'App Language' },
  { id: 'English (India)', label: 'English (India)' },
  { id: 'Hindi', label: 'Hindi (हिन्दी)' },
  { id: 'Urdu', label: 'Urdu (اردو)' },
  { id: 'Dogri', label: 'Dogri (डोगरी)' },
  { id: 'Kashmiri', label: 'Kashmiri (کٲشُر)' },
  { id: 'Marathi', label: 'Marathi (मराठी)' },
  { id: 'Kannada', label: 'Kannada (ಕನ್ನಡ)' },
  { id: 'Punjabi', label: 'Punjabi (ਪੰਜਾਬੀ)' },
  { id: 'Tamil', label: 'Tamil (தமிழ்)' },
  { id: 'Telugu', label: 'Telugu (తెలుగు)' },
];

interface CropDetectorCameraProps {
  language: LanguageCode;
  district: string;
  isOffline: boolean;
}

function readScanHistory(): CropScanHistoryItem[] {
  try {
    const raw = localStorage.getItem(SCAN_HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function compressImageDataUrl(
  sourceDataUrl: string,
  maxDimension = 1280,
  quality = 0.86
): Promise<{ dataUrl: string; base64: string; mimeType: string }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > maxDimension || height > maxDimension) {
        if (width >= height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, width);
      canvas.height = Math.max(1, height);
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Unable to initialize image processor.'));
        return;
      }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const outUrl = canvas.toDataURL('image/jpeg', quality);
      const base64 = outUrl.split(',')[1] ?? '';
      resolve({ dataUrl: outUrl, base64, mimeType: 'image/jpeg' });
    };
    img.onerror = () => reject(new Error('Could not decode selected photo.'));
    img.src = sourceDataUrl;
  });
}

export const CropDetectorCamera: React.FC<CropDetectorCameraProps> = ({
  language,
  district,
  isOffline,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);

  const [capturedImage, setCapturedImage] = useState<{
    dataUrl: string;
    base64: string;
    mimeType: string;
  } | null>(null);
  const [userNote, setUserNote] = useState('');
  const [outputLang, setOutputLang] = useState('auto');

  const [analyzing, setAnalyzing] = useState(false);
  const [detectError, setDetectError] = useState<string | null>(null);
  const [result, setResult] = useState<CropDetectionResult | null>(null);
  const [scanHistory, setScanHistory] = useState<CropScanHistoryItem[]>(readScanHistory);
  const [speaking, setSpeaking] = useState(false);

  const resolvedLanguage =
    outputLang === 'auto'
      ? LANGUAGES.find((l) => l.code === language)?.name || 'English (India)'
      : outputLang;

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  }, []);

  const stopSpeech = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeaking(false);
  }, []);

  useEffect(() => {
    return () => {
      stopCamera();
      stopSpeech();
    };
  }, [stopCamera, stopSpeech]);

  useEffect(() => {
    try {
      localStorage.setItem(SCAN_HISTORY_STORAGE_KEY, JSON.stringify(scanHistory));
    } catch {
      // ignore storage quota errors
    }
  }, [scanHistory]);

  const startCamera = useCallback(
    async (facingMode: 'environment' | 'user' = cameraFacing) => {
      setCameraError(null);
      setDetectError(null);

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError(
          'Live webcam API is unavailable in this browser. Please tap "Take / Upload Photo" below.'
        );
        return;
      }

      stopCamera();
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
        streamRef.current = stream;
        setCameraActive(true);
        setCapturedImage(null);
        // Attach stream once video element mounts
        requestAnimationFrame(() => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            void videoRef.current.play().catch(() => {
              // Autoplay fallback handled by muted + playsInline
            });
          }
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : '';
        if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('notallowed')) {
          setCameraError(
            'Camera permission was denied. Allow camera access in your browser bar or use "Take / Upload Photo".'
          );
        } else {
          setCameraError(
            'Could not open live camera on this device. Use "Take / Upload Photo" to capture or upload a leaf/crop image.'
          );
        }
      }
    },
    [cameraFacing, stopCamera]
  );

  const handleToggleFacing = () => {
    const nextFacing = cameraFacing === 'environment' ? 'user' : 'environment';
    setCameraFacing(nextFacing);
    if (cameraActive) {
      void startCamera(nextFacing);
    }
  };

  const analyzeImage = useCallback(
    async (payload: { dataUrl: string; base64: string; mimeType: string }) => {
      if (isOffline) {
        setDetectError(
          'Offline Mode is active. Switch off Offline Mode in the header to run live AI crop detection.'
        );
        return;
      }

      setAnalyzing(true);
      setDetectError(null);
      stopSpeech();

      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 38000);
      try {
        const res = await fetch('/api/crop-detect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            imageBase64: payload.base64,
            mimeType: payload.mimeType,
            language: resolvedLanguage,
            district,
            userNote,
          }),
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          throw new Error(data.error || 'Unable to analyze crop photo right now.');
        }

        const detection = data as CropDetectionResult;
        setResult(detection);

        if (detection.isPlantOrCrop) {
          const item: CropScanHistoryItem = {
            id: `scan-${Date.now()}`,
            scannedAt: new Date().toLocaleString([], {
              day: '2-digit',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit',
            }),
            district,
            result: detection,
          };
          setScanHistory((prev) => [item, ...prev].slice(0, 10));
        }
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          setDetectError('Analysis took too long. Please retake in clearer light and try again.');
        } else {
          setDetectError(err instanceof Error ? err.message : 'Unable to reach AI Crop Detector.');
        }
      } finally {
        window.clearTimeout(timeoutId);
        setAnalyzing(false);
      }
    },
    [district, isOffline, resolvedLanguage, stopSpeech, userNote]
  );

  const captureFromCamera = useCallback(async () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0 || video.videoHeight === 0) {
      setCameraError('Camera stream is warming up. Please wait a moment and tap Capture again.');
      return;
    }

    const maxDim = 1280;
    let w = video.videoWidth;
    let h = video.videoHeight;
    if (w > maxDim || h > maxDim) {
      if (w >= h) {
        h = Math.round((h * maxDim) / w);
        w = maxDim;
      } else {
        w = Math.round((w * maxDim) / h);
        h = maxDim;
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, w, h);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.86);
    const base64 = dataUrl.split(',')[1] ?? '';
    const nextPhoto = { dataUrl, base64, mimeType: 'image/jpeg' };

    stopCamera();
    setCapturedImage(nextPhoto);
    await analyzeImage(nextPhoto);
  }, [analyzeImage, stopCamera]);

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setCameraError(null);
    setDetectError(null);
    stopCamera();

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const rawDataUrl = String(reader.result || '');
        const compressed = await compressImageDataUrl(rawDataUrl);
        setCapturedImage(compressed);
        await analyzeImage(compressed);
      } catch (err) {
        setDetectError(err instanceof Error ? err.message : 'Could not read image file.');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSpeakSummary = async () => {
    if (!result?.spokenSummary) return;
    if (speaking) {
      stopSpeech();
      return;
    }

    setSpeaking(true);
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: result.spokenSummary,
          language: resolvedLanguage,
          gender: 'female',
          voiceName: 'Kore',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.audioBase64) {
        const binary = atob(data.audioBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audioRef.current = audio;
        audio.onended = () => {
          URL.revokeObjectURL(url);
          setSpeaking(false);
        };
        audio.onerror = () => {
          URL.revokeObjectURL(url);
          setSpeaking(false);
        };
        await audio.play();
        return;
      }
    } catch {
      // Fallback to browser SpeechSynthesis below
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const utter = new SpeechSynthesisUtterance(result.spokenSummary);
      utter.onend = () => setSpeaking(false);
      utter.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(utter);
    } else {
      setSpeaking(false);
    }
  };

  const statusTone =
    result?.healthStatus === 'Healthy'
      ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-200 dark:border-emerald-900'
      : result?.healthStatus === 'Pest / Disease Alert'
        ? 'bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-200 dark:border-rose-900'
        : result?.healthStatus === 'Unclear Image'
          ? 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
          : 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-200 dark:border-amber-900';

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="space-y-1 max-w-2xl">
          <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 text-xs font-semibold">
            <Sparkles className="w-4 h-4" />
            High-Level Multimodal AI Vision · {district} Field Context
          </div>
          <h3 className="font-display font-bold text-xl sm:text-2xl text-slate-900 dark:text-slate-100">
            AI Crop &amp; Disease Detector (Live Camera)
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Point your camera at any leaf, crop, fruit, vegetable, or seed sample to identify the crop, spot fungal/pest/nutrient issues early, and receive organic &amp; KVK-aligned care steps.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={outputLang}
            onChange={(e) => setOutputLang(e.target.value)}
            aria-label="Select diagnosis output language"
            className="min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs font-medium"
          >
            {DETECTOR_OUTPUT_LANGUAGES.map((l) => (
              <option key={l.id} value={l.id}>
                {l.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Hidden File Inputs for Gallery Upload & Mobile Native Camera */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        onChange={(e) => void handleFileSelected(e)}
        className="hidden"
      />
      <input
        ref={nativeCameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={(e) => void handleFileSelected(e)}
        className="hidden"
      />

      {/* Camera / Upload & Diagnosis 2-Column Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left: Live Camera Viewfinder & Controls */}
        <div className="lg:col-span-5 space-y-3">
          <div className="relative aspect-[4/3] w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 flex items-center justify-center">
            {cameraActive ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                {/* Crisp Corner Reticle Overlay */}
                <div className="pointer-events-none absolute inset-6 border border-emerald-400/40 rounded-xl">
                  <div className="absolute -top-0.5 -left-0.5 w-5 h-5 border-t-2 border-l-2 border-emerald-400 rounded-tl-md" />
                  <div className="absolute -top-0.5 -right-0.5 w-5 h-5 border-t-2 border-r-2 border-emerald-400 rounded-tr-md" />
                  <div className="absolute -bottom-0.5 -left-0.5 w-5 h-5 border-b-2 border-l-2 border-emerald-400 rounded-bl-md" />
                  <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 border-b-2 border-r-2 border-emerald-400 rounded-br-md" />
                </div>
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={handleToggleFacing}
                    className="px-3 py-1.5 rounded-lg bg-slate-900/80 text-white text-xs font-medium inline-flex items-center gap-1.5 hover:bg-slate-900"
                  >
                    <SwitchCamera className="w-3.5 h-3.5" />
                    Flip Camera
                  </button>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-3 py-1.5 rounded-lg bg-rose-600/90 text-white text-xs font-medium inline-flex items-center gap-1.5 hover:bg-rose-700"
                  >
                    <StopCircle className="w-3.5 h-3.5" />
                    Stop
                  </button>
                </div>
              </>
            ) : capturedImage ? (
              <>
                <img
                  src={capturedImage.dataUrl}
                  alt="Captured crop sample"
                  className="w-full h-full object-cover"
                />
                {analyzing && (
                  <div className="absolute inset-0 bg-slate-950/65 backdrop-blur-[2px] flex flex-col items-center justify-center gap-2 text-white p-4 text-center">
                    <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
                    <div className="text-sm font-semibold">Running High-Level AI Crop Analysis...</div>
                    <div className="text-xs text-slate-300">
                      Checking species, leaf lesions, pests &amp; nutrient health
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="p-6 text-center space-y-3 text-slate-300">
                <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <ScanLine className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-white">Ready to Scan Any Crop</p>
                  <p className="text-xs text-slate-400">
                    Tap Start Live Camera, take a photo with your mobile camera, or upload an image from your gallery.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Symptom Context Input */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
              Optional Field Observation (helps AI accuracy)
            </label>
            <input
              type="text"
              maxLength={300}
              value={userNote}
              onChange={(e) => setUserNote(e.target.value)}
              placeholder="e.g., Brown spots appeared after rain on lower leaves..."
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          {/* Primary Action Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {cameraActive ? (
              <button
                type="button"
                onClick={() => void captureFromCamera()}
                disabled={analyzing}
                className="sm:col-span-2 min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-700 text-white text-sm font-semibold hover:bg-emerald-800 disabled:opacity-50 inline-flex items-center justify-center gap-2 transition-colors shadow-sm"
              >
                <Camera className="w-4 h-4" />
                Capture &amp; Detect Crop
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void startCamera(cameraFacing)}
                disabled={analyzing}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-700 text-white text-xs sm:text-sm font-semibold hover:bg-emerald-800 disabled:opacity-50 inline-flex items-center justify-center gap-2 transition-colors"
              >
                <Camera className="w-4 h-4" />
                Start Live Camera
              </button>
            )}

            <button
              type="button"
              onClick={() => nativeCameraInputRef.current?.click()}
              disabled={analyzing}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-emerald-700 text-emerald-700 dark:text-emerald-400 text-xs sm:text-sm font-medium hover:bg-emerald-50 dark:hover:bg-emerald-950/40 disabled:opacity-50 inline-flex items-center justify-center gap-1.5 transition-colors"
            >
              <ImagePlus className="w-4 h-4" />
              Mobile Camera Photo
            </button>

            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              disabled={analyzing}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 inline-flex items-center justify-center gap-1.5 transition-colors"
            >
              <Upload className="w-4 h-4" />
              Upload Image
            </button>

            {capturedImage && !cameraActive && (
              <button
                type="button"
                onClick={() => void analyzeImage(capturedImage)}
                disabled={analyzing}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-700 text-white text-xs sm:text-sm font-medium hover:bg-slate-800 disabled:opacity-50 inline-flex items-center justify-center gap-1.5 transition-colors"
              >
                <RefreshCw className={`w-4 h-4 ${analyzing ? 'animate-spin' : ''}`} />
                Re-Analyze Photo
              </button>
            )}
          </div>

          {cameraError && (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{cameraError}</span>
            </div>
          )}

          {detectError && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-800 dark:text-rose-200 flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{detectError}</span>
            </div>
          )}
        </div>

        {/* Right: Structured High-Level AI Analysis Report */}
        <div className="lg:col-span-7 space-y-4">
          {!result ? (
            <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 p-6 space-y-4 bg-slate-50/60 dark:bg-slate-800/30">
              <div className="flex items-center gap-2 font-display font-semibold text-base">
                <Sprout className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
                What the High-Level AI Crop Detector Evaluates
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600 dark:text-slate-400">
                <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    1. Crop &amp; Growth Stage ID
                  </div>
                  <p>Identifies Indian &amp; Himalayan crops (Apple, Rajmash, Wheat, Paddy, Maize, Mustard, Vegetables, Seeds) + regional names.</p>
                </div>
                <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    2. Disease, Pest &amp; Nutrient Scan
                  </div>
                  <p>Spots Apple Scab, Alternaria, Rust, Blight, Aphids, Nitrogen/Zinc/Iron deficiencies, and visual leaf lesions.</p>
                </div>
                <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    3. Organic &amp; Safe KVK Actions
                  </div>
                  <p>Provides immediate pruning, field hygiene, and bio-control guidance with KVK Helpline 1800-180-1551 verification.</p>
                </div>
                <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    4. Voice Read-Aloud in Regional Languages
                  </div>
                  <p>Listen to your diagnosis hands-free in Hindi, English, Urdu, Dogri, Kashmiri, Marathi, Kannada, and more.</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 bg-slate-50/40 dark:bg-slate-800/30">
              {/* Top Diagnosis Banner */}
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2.5 py-1 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 ${statusTone}`}>
                      {result.healthStatus === 'Healthy' ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5" />
                      )}
                      {result.healthStatus}
                    </span>
                    {result.severity !== 'None' && (
                      <span className="px-2.5 py-1 rounded-lg bg-slate-200/70 dark:bg-slate-800 text-xs font-medium">
                        Severity: {result.severity}
                      </span>
                    )}
                    <span className="font-mono text-xs text-slate-500 tabular-nums">
                      {result.confidencePercent}% Confidence
                    </span>
                  </div>

                  <h4 className="font-display font-bold text-xl text-slate-900 dark:text-slate-100 pt-1">
                    {result.cropName}
                    {result.localName ? (
                      <span className="text-sm font-medium text-emerald-700 dark:text-emerald-400 ml-2">
                        ({result.localName})
                      </span>
                    ) : null}
                  </h4>
                  <p className="text-xs text-slate-500">
                    Stage / Variety Clue: {result.varietyOrStage}
                  </p>
                </div>

                {result.spokenSummary && (
                  <button
                    type="button"
                    onClick={() => void handleSpeakSummary()}
                    className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-medium inline-flex items-center gap-1.5 transition-colors shrink-0 ${
                      speaking
                        ? 'bg-rose-600 text-white hover:bg-rose-700'
                        : 'bg-emerald-700 text-white hover:bg-emerald-800'
                    }`}
                  >
                    {speaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    {speaking ? 'Stop Voice' : 'Listen Diagnosis'}
                  </button>
                )}
              </div>

              {/* Primary Finding */}
              <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                  Detected Issue / Condition
                </div>
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  {result.detectedIssue}
                </div>
                {result.spokenSummary && (
                  <p className="text-xs text-slate-600 dark:text-slate-400 pt-1 leading-relaxed">
                    {result.spokenSummary}
                  </p>
                )}
              </div>

              {/* Symptoms & Immediate Organic Actions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Visual Clues Observed
                  </div>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc pl-4">
                    {result.visualSymptoms.map((s, idx) => (
                      <li key={idx}>{s}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Immediate &amp; Organic Field Actions
                  </div>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc pl-4">
                    {result.organicAndImmediateActions.map((act, idx) => (
                      <li key={idx}>{act}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Soil / Nutrition & Harvest / Seed Tip */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Nutrient &amp; Irrigation Care
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {result.recommendedFertilizerOrCare}
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Seed &amp; Harvest Guidance
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {result.estimatedHarvestOrSeedTip}
                  </p>
                </div>
              </div>

              {/* KVK Verification Notice */}
              <div className="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-xs text-amber-900 dark:text-amber-200">
                <span className="font-semibold">KVK &amp; Scientific Guidance:</span>{' '}
                {result.chemicalAndKvkGuidance}
              </div>
            </div>
          )}

          {/* Recent Field Scans History */}
          {scanHistory.length > 0 && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                  Recent Field Scans ({scanHistory.length})
                </span>
                <button
                  type="button"
                  onClick={() => setScanHistory([])}
                  className="text-[11px] text-slate-500 hover:text-rose-600 inline-flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  Clear
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {scanHistory.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setResult(item.result)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:border-emerald-600 text-left text-xs transition-colors"
                  >
                    <span className="font-semibold text-slate-900 dark:text-slate-100">
                      {item.result.cropName}
                    </span>
                    <span className="text-slate-500 ml-1.5">
                      · {item.result.healthStatus} ({item.scannedAt})
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
