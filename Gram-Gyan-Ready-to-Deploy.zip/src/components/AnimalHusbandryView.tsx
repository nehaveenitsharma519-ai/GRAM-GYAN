import React, { useMemo, useState } from 'react';
import {
  Building2,
  Calculator,
  Calendar,
  ExternalLink,
  HeartPulse,
  MapPin,
  Phone,
  Search,
  ShieldCheck,
  Sprout,
} from 'lucide-react';
import {
  ANIMAL_HUSBANDRY_SCHEMES,
  ANIMAL_SCHEME_META,
  LIVESTOCK_BREEDS_GUIDE,
  LIVESTOCK_VACCINATION_SCHEDULE,
  LivestockSchemeFocus,
  VETERINARY_CENTRES,
} from '../data/animalHusbandryData';
import { GovernmentScheme } from '../types/gramGyan';

interface AnimalHusbandryViewProps {
  schemes?: GovernmentScheme[];
  district: string;
  savedSchemeIds: string[];
  onToggleSaveScheme: (id: string) => void;
}

const FOCUS_FILTERS: ('All' | LivestockSchemeFocus)[] = [
  'All',
  'Sheep & Goat',
  'Dairy & Cattle',
  'Credit & Insurance',
  'Poultry & Fodder',
  'Health & Breeding',
];

const UNIT_PRESETS = [
  { id: 'dorper-ram', label: 'Dorper Breeding Ram + 20 Ewes Mutton Unit', costInLakhs: 2.5, subsidyRate: 0.5, maxSubsidyInLakhs: 1.25 },
  { id: 'nlm-sheep-100', label: 'NLM Commercial Sheep/Goat Unit (100 Females + 5 Males)', costInLakhs: 20, subsidyRate: 0.5, maxSubsidyInLakhs: 10 },
  { id: 'nlm-sheep-500', label: 'NLM Large Breeder Farm (500 Ewes/Does + 25 Rams/Bucks)', costInLakhs: 100, subsidyRate: 0.5, maxSubsidyInLakhs: 50 },
  { id: 'isds-mini', label: 'ISDS / HADP Mini Sheep/Goat Unit (25 Ewes + 1 Ram)', costInLakhs: 3.5, subsidyRate: 0.5, maxSubsidyInLakhs: 1.75 },
  { id: 'idds-dairy-2', label: 'IDDS Dairy Unit (2 High-Yield Cows / Buffaloes)', costInLakhs: 3.0, subsidyRate: 0.5, maxSubsidyInLakhs: 1.5 },
  { id: 'nlm-poultry', label: 'NLM Rural Poultry Mother Unit (1,000 Birds + Hatchery)', costInLakhs: 50, subsidyRate: 0.5, maxSubsidyInLakhs: 25 },
  { id: 'nlm-fodder', label: 'NLM Fodder Silage & Baling Processing Unit', costInLakhs: 80, subsidyRate: 0.5, maxSubsidyInLakhs: 40 },
];

export const AnimalHusbandryView: React.FC<AnimalHusbandryViewProps> = ({
  schemes,
  district,
  savedSchemeIds,
  onToggleSaveScheme,
}) => {
  const [activeTab, setActiveTab] = useState<'schemes' | 'health' | 'breeds' | 'centres'>('schemes');
  const [focusFilter, setFocusFilter] = useState<'All' | LivestockSchemeFocus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [presetId, setPresetId] = useState(UNIT_PRESETS[0].id);
  const [customProjectLakhs, setCustomProjectLakhs] = useState(UNIT_PRESETS[0].costInLakhs);

  // Merge any dynamic admin-added Animal & Sheep Husbandry schemes with canonical ones
  const allAnimalSchemes = useMemo(() => {
    const dynamic = (schemes ?? []).filter(
      (s) => s.category === 'Animal & Sheep Husbandry' && s.status !== 'Draft'
    );
    const mergedMap = new Map<string, GovernmentScheme>();
    ANIMAL_HUSBANDRY_SCHEMES.forEach((s) => mergedMap.set(s.id, s));
    dynamic.forEach((s) => mergedMap.set(s.id, s));
    return Array.from(mergedMap.values());
  }, [schemes]);

  const filteredSchemes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allAnimalSchemes.filter((sch) => {
      const meta = ANIMAL_SCHEME_META[sch.id];
      if (focusFilter !== 'All' && meta?.focus !== focusFilter) return false;
      if (q) {
        const hay = `${sch.title} ${sch.department} ${sch.benefitSummary} ${meta?.subsidyHighlight ?? ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [allAnimalSchemes, focusFilter, searchQuery]);

  const activePreset = UNIT_PRESETS.find((p) => p.id === presetId) ?? UNIT_PRESETS[0];
  const calculatedSubsidy = Math.min(
    activePreset.maxSubsidyInLakhs,
    customProjectLakhs * activePreset.subsidyRate
  );
  const farmerAndBankShare = Math.max(0, customProjectLakhs - calculatedSubsidy);

  return (
    <div className="space-y-6">
      {/* Department Overview Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1.5 max-w-3xl">
            <div className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              Department of Animal &amp; Sheep Husbandry (J&amp;K &amp; DAHD India)
            </div>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-slate-900 dark:text-slate-100">
              Animal &amp; Sheep Husbandry Department — Schemes, Health &amp; Subsidies
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Complete guide to NLM 50% subsidies, J&amp;K Sheep Husbandry (ISDS), Dairy (IDDS), HADP mutton/wool missions, KCC livestock loans, free vaccination drives, and 1962 Mobile Vet assistance in {district} and across India.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs space-y-1 shrink-0">
            <div className="font-semibold text-rose-800 dark:text-rose-200 inline-flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5" /> Veterinary Emergency Helpline
            </div>
            <div className="font-mono font-bold text-lg text-rose-700 dark:text-rose-300 tabular-nums">
              1962 <span className="text-xs font-sans font-normal">(Toll-Free MVU Van)</span>
            </div>
            <div className="text-[11px] text-rose-700/80 dark:text-rose-300/80">
              Free Mobile Vet Doctor &amp; Vaccination Support
            </div>
          </div>
        </div>

        {/* Two Department Wings Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-1">
            <div className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100 inline-flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-emerald-700" />
              Directorate of Animal Husbandry (Dairy, Cattle, Poultry &amp; Fodder)
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Handles crossbreeding (Artificial Insemination / Sex-Sorted Semen), dairy farm subsidies (IDDS, NLM, RGM), poultry development, Pashu Aadhaar 12-digit tagging, and disease control across Veterinary Hospitals &amp; Dispensaries.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-1">
            <div className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100 inline-flex items-center gap-1.5">
              <Sprout className="w-4 h-4 text-emerald-700" />
              Directorate of Sheep Husbandry (Mutton, Fine Wool &amp; Pastoralist Support)
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Dedicated to sheep &amp; goat farmers, Chopans, Gaddis, and Bakerwals — operating Sheep Extension Centres (SECs), distributing latest Dorper, Merino &amp; Rambouillet breeding rams, machine wool shearing, dipping vats, and high-altitude migration healthcare.
            </p>
          </div>
        </div>

        {/* Sub-navigation Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
          {[
            { id: 'schemes', label: `All Schemes & Subsidies (${allAnimalSchemes.length})` },
            { id: 'health', label: 'Free Vaccination & Care Calendar' },
            { id: 'breeds', label: 'Recommended Breeds & Yields' },
            { id: 'centres', label: 'Vet Hospitals, SECs & Portals' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: All Schemes & Subsidy Estimator */}
      {activeTab === 'schemes' && (
        <div className="space-y-6">
          {/* Interactive Subsidy Estimator */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2 font-display font-bold text-base text-slate-900 dark:text-slate-100">
              <Calculator className="w-4 h-4 text-emerald-700" />
              Livestock &amp; Sheep Unit Subsidy Estimator (NLM / IDDS / ISDS)
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              <label className="space-y-1 text-xs md:col-span-2">
                <span className="font-medium text-slate-600 dark:text-slate-400">Choose Unit Template</span>
                <select
                  value={presetId}
                  onChange={(e) => {
                    const next = UNIT_PRESETS.find((p) => p.id === e.target.value) ?? UNIT_PRESETS[0];
                    setPresetId(next.id);
                    setCustomProjectLakhs(next.costInLakhs);
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs sm:text-sm"
                >
                  {UNIT_PRESETS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1 text-xs">
                <span className="font-medium text-slate-600 dark:text-slate-400">
                  Total Project Outlay (₹ Lakhs)
                </span>
                <input
                  type="number"
                  min={1}
                  max={200}
                  step={0.5}
                  value={customProjectLakhs}
                  onChange={(e) => setCustomProjectLakhs(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 font-mono text-sm"
                />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                <div className="text-[11px] text-slate-500">Total Unit Cost</div>
                <div className="font-mono font-bold text-lg text-slate-900 dark:text-slate-100 tabular-nums">
                  ₹{customProjectLakhs.toFixed(2)} Lakh
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900">
                <div className="text-[11px] text-emerald-700 dark:text-emerald-400">
                  Estimated Govt. Subsidy (50% up to cap)
                </div>
                <div className="font-mono font-bold text-lg text-emerald-700 dark:text-emerald-400 tabular-nums">
                  ₹{calculatedSubsidy.toFixed(2)} Lakh
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                <div className="text-[11px] text-slate-500">Bank Loan + Beneficiary Margin</div>
                <div className="font-mono font-bold text-lg text-slate-900 dark:text-slate-100 tabular-nums">
                  ₹{farmerAndBankShare.toFixed(2)} Lakh
                </div>
              </div>
            </div>
          </div>

          {/* Search & Focus Filter */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              {FOCUS_FILTERS.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setFocusFilter(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
                    focusFilter === cat
                      ? 'bg-emerald-700 text-white'
                      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-emerald-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <label className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Dorper Ram, NLM, ISDS, IDDS, KCC, HADP..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </label>
          </div>

          {/* Schemes Cards Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {filteredSchemes.map((sch) => {
              const isSaved = savedSchemeIds.includes(sch.id);
              const meta = ANIMAL_SCHEME_META[sch.id];
              return (
                <div
                  key={sch.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                          {meta?.isLatest && (
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 font-semibold">
                              Latest 2026
                            </span>
                          )}
                          {meta && (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-medium">
                              {meta.implementingWing}
                            </span>
                          )}
                          <span className="text-slate-500">{sch.geography}</span>
                        </div>
                        <h3 className="font-display font-bold text-lg text-slate-900 dark:text-slate-100">
                          {sch.title}
                        </h3>
                        <p className="text-xs text-slate-500">{sch.department}</p>
                      </div>

                      <button
                        type="button"
                        onClick={() => onToggleSaveScheme(sch.id)}
                        className={`min-h-[36px] px-3 rounded-xl border text-xs font-medium whitespace-nowrap shrink-0 ${
                          isSaved
                            ? 'bg-emerald-700 text-white border-emerald-700'
                            : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        {isSaved ? 'Saved' : 'Save Guide'}
                      </button>
                    </div>

                    {meta && (
                      <div className="px-3 py-2 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900 text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                        Key Benefit: {meta.subsidyHighlight}
                      </div>
                    )}

                    <p className="text-sm text-slate-700 dark:text-slate-300">{sch.benefitSummary}</p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1.5">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">Eligibility</div>
                        <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc pl-4">
                          {sch.eligibility.map((e, i) => (
                            <li key={i}>{e}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="space-y-1.5">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">
                          Required Documents
                        </div>
                        <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc pl-4">
                          {sch.documentsRequired.map((d, i) => (
                            <li key={i}>{d}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">How to Apply</div>
                      <ol className="space-y-1 text-slate-600 dark:text-slate-400 list-decimal pl-4">
                        {sch.applicationSteps.map((step, i) => (
                          <li key={i}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>

                  <div className="flex items-center justify-between flex-wrap gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <span className="text-slate-500">Status: {sch.deadline}</span>
                    <a
                      href={sch.officialUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 text-white font-medium hover:bg-emerald-800"
                    >
                      {sch.officialPortalName}
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: Free Vaccination & Seasonal Care Calendar */}
      {activeTab === 'health' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-2">
            <div className="space-y-0.5">
              <h3 className="font-display font-bold text-lg flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-700" />
                Free Govt. Livestock Vaccination &amp; Deworming Calendar
              </h3>
              <p className="text-xs text-slate-500">
                Keep your cattle, sheep &amp; goats protected before monsoon, extreme cold, and highland Dhok migration.
              </p>
            </div>
            <span className="font-mono text-xs font-semibold text-rose-700 dark:text-rose-400">
              Vet Helpline: 1962
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-medium">Disease / Treatment</th>
                  <th className="py-3 px-4 font-medium">Animals Covered</th>
                  <th className="py-3 px-4 font-medium">Timing &amp; Frequency</th>
                  <th className="py-3 px-4 font-medium">Symptoms &amp; Govt. Free Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {LIVESTOCK_VACCINATION_SCHEDULE.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-slate-100">
                      {item.disease}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">{item.species}</td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-emerald-700 dark:text-emerald-400">
                        {item.seasonTiming}
                      </div>
                      <div className="text-[11px] text-slate-500">{item.frequency}</div>
                    </td>
                    <td className="py-3.5 px-4 space-y-1">
                      <div className="text-slate-600 dark:text-slate-300">{item.symptomsAndImpact}</div>
                      <div className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400">
                        {item.govtSupport}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Recommended Breeds & Livestock Yields */}
      {activeTab === 'breeds' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {LIVESTOCK_BREEDS_GUIDE.map((breed) => (
            <div
              key={breed.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3"
            >
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="px-2.5 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-semibold">
                  {breed.species}
                </span>
                <span className="text-slate-500">{breed.originRegion}</span>
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900 dark:text-slate-100">
                {breed.breedName}
              </h3>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 text-xs font-medium text-slate-800 dark:text-slate-200">
                Expected Yield: {breed.keyYield}
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                <span className="font-semibold text-slate-800 dark:text-slate-200">Best Suited For: </span>
                {breed.bestSuitedFor}
              </p>
              <p className="text-xs text-emerald-700 dark:text-emerald-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                Tip: {breed.managementTip}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* TAB 4: Vet Hospitals, SECs & Official Department Portals */}
      {activeTab === 'centres' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {VETERINARY_CENTRES.map((centre) => (
              <div
                key={centre.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400">
                      {centre.wing}
                    </div>
                    <h3 className="font-display font-bold text-base text-slate-900 dark:text-slate-100 mt-0.5">
                      {centre.name}
                    </h3>
                  </div>
                  <span className="text-xs text-slate-500 inline-flex items-center gap-1 shrink-0">
                    <MapPin className="w-3.5 h-3.5" /> {centre.district}
                  </span>
                </div>

                <p className="text-xs text-slate-500">
                  Location: {centre.blockLocation} · Timings: {centre.timing}
                </p>

                <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                  {centre.services.map((srv, idx) => (
                    <li key={idx}>{srv}</li>
                  ))}
                </ul>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="inline-flex items-center gap-1 font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                    <HeartPulse className="w-3.5 h-3.5" /> {centre.contact}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="font-display font-semibold text-base">Official Department &amp; Scheme Portals</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              {[
                { name: 'National Livestock Mission (NLM)', url: 'https://nlm.udyamimitra.in' },
                { name: 'Sheep Husbandry Dept., Jammu', url: 'https://jksheephusbandryjammu.nic.in' },
                { name: 'Sheep Husbandry Dept., Kashmir', url: 'https://dshkashmir.nic.in' },
                { name: 'Animal Husbandry Dept., J&K', url: 'https://animalhusbandryjammu.nic.in' },
                { name: 'DAHD Govt. of India', url: 'https://dahd.gov.in' },
                { name: 'HADP Kisan Sathi J&K', url: 'https://hadp.jk.gov.in' },
              ].map((portal) => (
                <a
                  key={portal.url}
                  href={portal.url}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-600 flex items-center justify-between gap-2 font-medium text-slate-800 dark:text-slate-200"
                >
                  <span className="truncate">{portal.name}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
