import React, { useEffect, useRef, useState } from 'react';
import {
  Bot,
  Globe,
  Loader2,
  MessageSquare,
  Mic,
  MicOff,
  RotateCcw,
  Send,
  User,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  CHATBOT_ROLES,
  CHAT_VOICE_LANGUAGES,
  CHAT_VOICE_PERSONAS,
  ChatVoicePersonaId,
  useChat,
} from '../contexts/ChatContext';
import { useSpeechToText } from '../hooks/useSpeechToText';
import { LanguageCode } from '../types/gramGyan';

interface GeminiChatbotDrawerProps {
  language: LanguageCode;
  district: string;
}

export const GeminiChatbotDrawer: React.FC<GeminiChatbotDrawerProps> = ({ district }) => {
  const {
    messages,
    activeRoleId,
    activeRole,
    isDrawerOpen,
    isOffline,
    loading,
    errorMsg,
    autoRead,
    voiceGender,
    voicePersona,
    voiceLanguageId,
    activeVoiceLanguage,
    speechRate,
    speakingMsgId,
    ttsLoadingMsgId,
    setIsDrawerOpen,
    setActiveRoleId,
    setAutoRead,
    setVoiceGender,
    setVoicePersona,
    setVoiceLanguageId,
    setSpeechRate,
    speakMessage,
    stopSpeaking,
    sendMessage,
    retryLastMessage,
    clearHistory,
  } = useChat();

  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement | null>(null);

  const {
    isListening,
    isTranscribing,
    voiceError,
    toggleRecording,
    stopRecording,
    dismissVoiceError,
  } = useSpeechToText({
    languageName: activeVoiceLanguage.apiLanguage,
    speechLang: activeVoiceLanguage.speechLang,
    isOffline,
    onTranscript: (transcript) => {
      setInput((prev) => (prev ? `${prev.trim()} ${transcript}` : transcript));
    },
  });

  useEffect(() => {
    if (isDrawerOpen) {
      endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [isDrawerOpen, messages.length, loading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const text = input;
    setInput('');
    await sendMessage(text);
  };

  const displayError = errorMsg || voiceError;

  return (
    <>
      {/* Floating Chat Trigger (stays clear of mobile bottom nav) */}
      {!isDrawerOpen && (
        <button
          type="button"
          onClick={() => setIsDrawerOpen(true)}
          aria-label="Open Gemini Rural Chatbot"
          className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-40 min-h-[48px] px-4 py-2.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-lg flex items-center gap-2 text-sm font-medium transition-colors"
        >
          <MessageSquare className="w-4 h-4" />
          <span>Gram Chat</span>
          {messages.length > 0 && (
            <span className="font-mono text-[11px] bg-emerald-900/60 px-1.5 py-0.5 rounded-md tabular-nums">
              {messages.length}
            </span>
          )}
        </button>
      )}

      {/* Multi-turn Chat Window */}
      {isDrawerOpen && (
        <div
          role="dialog"
          aria-modal="false"
          aria-label="GRAM GYAN Gemini Chatbot"
          className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-50 w-[calc(100vw-2rem)] sm:w-[440px] h-[590px] max-h-[calc(100vh-6.5rem)] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-4 py-3 bg-emerald-700 text-white flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h3 className="font-display font-bold text-sm truncate">
                  {activeRole.label}
                </h3>
                <p className="text-[11px] text-emerald-100 truncate">
                  {district} · {activeVoiceLanguage.apiLanguage} · {voicePersona}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              {messages.length > 0 && (
                <button
                  type="button"
                  onClick={clearHistory}
                  title="New chat"
                  aria-label="Clear chat history"
                  className="p-1.5 rounded-lg hover:bg-white/15 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  stopSpeaking();
                  stopRecording();
                  setIsDrawerOpen(false);
                }}
                aria-label="Close chat"
                className="p-1.5 rounded-lg hover:bg-white/15 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Role Selector Strip */}
          <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50 flex items-center gap-1.5 overflow-x-auto shrink-0">
            {CHATBOT_ROLES.map((role) => (
              <button
                key={role.id}
                type="button"
                onClick={() => setActiveRoleId(role.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
                  activeRoleId === role.id
                    ? 'bg-emerald-700 text-white'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-emerald-600'
                }`}
              >
                {role.label}
              </button>
            ))}
          </div>

          {/* Multi-Language Voice, Gender, Persona & Auto-Read Bar */}
          <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-1.5 text-[11px] shrink-0">
            <div className="flex items-center justify-between gap-2">
              <label className="flex items-center gap-1.5 min-w-0 flex-1">
                <Globe className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
                <select
                  aria-label="Gram Chat voice language"
                  value={voiceLanguageId}
                  onChange={(e) => setVoiceLanguageId(e.target.value)}
                  className="w-full px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-[11px] font-medium truncate"
                >
                  {CHAT_VOICE_LANGUAGES.map((vLang) => (
                    <option key={vLang.id} value={vLang.id}>
                      {vLang.label}
                    </option>
                  ))}
                </select>
              </label>

              <button
                type="button"
                onClick={() => setAutoRead(!autoRead)}
                aria-pressed={autoRead}
                className={`px-2.5 py-1 rounded-lg font-medium inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
                  autoRead
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-transparent'
                }`}
              >
                {autoRead ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                Auto-Read: {autoRead ? 'On' : 'Off'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-1.5">
              <div className="flex items-center p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => setVoiceGender('female')}
                  className={`px-2 py-1 rounded-md font-medium transition-colors whitespace-nowrap ${
                    voiceGender === 'female'
                      ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Female
                </button>
                <button
                  type="button"
                  onClick={() => setVoiceGender('male')}
                  className={`px-2 py-1 rounded-md font-medium transition-colors whitespace-nowrap ${
                    voiceGender === 'male'
                      ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Male
                </button>
              </div>

              <select
                aria-label="Natural voice tone"
                value={voicePersona}
                onChange={(e) => setVoicePersona(e.target.value as ChatVoicePersonaId)}
                className="flex-1 min-w-0 px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] truncate"
              >
                {CHAT_VOICE_PERSONAS.map((persona) => (
                  <option key={persona.id} value={persona.id}>
                    {persona.label}
                  </option>
                ))}
              </select>

              <select
                aria-label="Speech reading speed"
                value={speechRate}
                onChange={(e) => setSpeechRate(Number(e.target.value))}
                className="px-1.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[10px] shrink-0"
              >
                <option value={0.85}>0.85×</option>
                <option value={1.0}>1.0×</option>
                <option value={1.15}>1.15×</option>
              </select>
            </div>
          </div>

          {/* Scrollable Message Thread */}
          <div
            className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-slate-50/40 dark:bg-slate-950/20"
            role="log"
            aria-live="polite"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col justify-center space-y-3 px-1">
                <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Namaste! I am {activeRole.label}.
                  </div>
                  <p>
                    Tap the mic button to speak, or type your question. Choose Hindi, English, Marathi, Kannada, Tamil, Telugu &amp; more above.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <p className="text-[11px] font-medium text-slate-500">Suggested questions:</p>
                  {activeRole.starterPrompts.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => void sendMessage(prompt)}
                      className="w-full text-left px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-emerald-600 text-xs text-slate-700 dark:text-slate-200 transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((msg) => {
                const isUser = msg.role === 'user';
                const isPlaying = speakingMsgId === msg.id;
                const isVoiceLoading = ttsLoadingMsgId === msg.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isUser && (
                      <div className="w-6 h-6 rounded-md bg-emerald-700 text-white flex items-center justify-center shrink-0 mt-0.5">
                        <Bot className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div
                      className={`rounded-2xl px-3.5 py-2.5 max-w-[82%] text-xs sm:text-[13px] leading-relaxed space-y-1.5 ${
                        isUser
                          ? 'bg-emerald-700 text-white rounded-br-sm'
                          : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-sm'
                      }`}
                    >
                      <p className="whitespace-pre-line">{msg.text}</p>
                      <div className="flex items-center justify-between gap-2 text-[10px] opacity-85">
                        <span className="font-mono tabular-nums">{msg.timestamp}</span>
                        {!isUser && (
                          <div className="flex items-center gap-2">
                            {isVoiceLoading ? (
                              <button
                                type="button"
                                onClick={stopSpeaking}
                                className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium"
                              >
                                <Loader2 className="w-3 h-3 animate-spin" /> Loading voice...
                              </button>
                            ) : isPlaying ? (
                              <button
                                type="button"
                                onClick={stopSpeaking}
                                className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium hover:underline"
                              >
                                <VolumeX className="w-3 h-3" /> Stop
                              </button>
                            ) : (
                              <>
                                <button
                                  type="button"
                                  onClick={() => speakMessage(msg.id, msg.text, 'female')}
                                  className="inline-flex items-center gap-0.5 text-emerald-700 dark:text-emerald-400 hover:underline"
                                  title={`Listen in clear ${activeVoiceLanguage.apiLanguage} Female voice`}
                                >
                                  <Volume2 className="w-3 h-3" /> Female
                                </button>
                                <button
                                  type="button"
                                  onClick={() => speakMessage(msg.id, msg.text, 'male')}
                                  className="inline-flex items-center gap-0.5 text-slate-600 dark:text-slate-300 hover:underline"
                                  title={`Listen in clear ${activeVoiceLanguage.apiLanguage} Male voice`}
                                >
                                  <Volume2 className="w-3 h-3" /> Male
                                </button>
                              </>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                    {isUser && (
                      <div className="w-6 h-6 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-0.5">
                        <User className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                );
              })
            )}

            {loading && (
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                <span>Thinking...</span>
              </div>
            )}

            <div ref={endRef} />
          </div>

          {displayError && (
            <div className="mx-3 mt-2 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-[11px] text-rose-800 dark:text-rose-200 flex items-center justify-between gap-2 shrink-0">
              <span className="flex-1">{displayError}</span>
              {errorMsg && messages[messages.length - 1]?.role === 'user' ? (
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => void retryLastMessage()}
                  className="px-2.5 py-1 rounded-lg bg-rose-700 text-white font-medium hover:bg-rose-800 whitespace-nowrap shrink-0"
                >
                  Retry
                </button>
              ) : (
                <button
                  type="button"
                  onClick={dismissVoiceError}
                  aria-label="Dismiss error"
                  className="p-1 text-rose-700 dark:text-rose-300 hover:opacity-80 shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}

          {/* Voice Status Bar */}
          {(isListening || isTranscribing) && (
            <div className="px-3 py-1.5 bg-amber-50 dark:bg-amber-950/50 border-t border-amber-200 dark:border-amber-900 text-[11px] text-amber-800 dark:text-amber-200 flex items-center justify-between gap-2 shrink-0">
              <span className="inline-flex items-center gap-1.5 font-medium">
                {isTranscribing ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Transcribing your {activeVoiceLanguage.apiLanguage} speech...
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse" />
                    Listening in {activeVoiceLanguage.apiLanguage}... Tap mic to finish
                  </>
                )}
              </span>
              {isListening && (
                <button
                  type="button"
                  onClick={stopRecording}
                  className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-medium hover:bg-rose-700"
                >
                  Done
                </button>
              )}
            </div>
          )}

          {/* Input with Mic (Speech-to-Text) & Send */}
          <form
            onSubmit={handleSubmit}
            className="p-2.5 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2 shrink-0"
          >
            <button
              type="button"
              onClick={() => void toggleRecording()}
              disabled={loading || isTranscribing}
              aria-label={isListening ? 'Stop voice recording' : 'Speak your question'}
              title={isListening ? 'Tap to finish speaking' : `Speak in ${activeVoiceLanguage.apiLanguage}`}
              className={`min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center transition-colors shrink-0 ${
                isListening
                  ? 'bg-rose-600 text-white hover:bg-rose-700'
                  : isTranscribing
                    ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {isTranscribing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isListening ? (
                <MicOff className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>

            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask any question in ${activeVoiceLanguage.apiLanguage}...`}
              className="flex-1 min-h-[40px] px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
            <button
              type="submit"
              disabled={isTranscribing || !input.trim()}
              aria-label="Send message"
              className="min-h-[40px] min-w-[40px] rounded-xl bg-emerald-700 text-white hover:bg-emerald-800 disabled:opacity-50 flex items-center justify-center transition-colors shrink-0"
            >
              {loading && !input.trim() ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </button>
          </form>
        </div>
      )}
    </>
  );
};
