import React, { useMemo, useState } from 'react';
import { BookCheck, Clock, Plus } from 'lucide-react';
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { WeeklyReadingStat } from '../types/gramGyan';

interface ReadingAnalyticsProps {
  stats: WeeklyReadingStat[];
  finishedBookIds: string[];
  isCloudSynced: boolean;
  onLogQuickSession: (minutes: number) => void;
}

interface TooltipPayloadEntry {
  name?: string;
  value?: number;
  color?: string;
  payload?: WeeklyReadingStat & { avgDailyMinutes: number };
}

const CustomChartTooltip: React.FC<{
  active?: boolean;
  payload?: TooltipPayloadEntry[];
  label?: string;
  metricMode: 'weekly' | 'daily_avg';
}> = ({ active, payload, label, metricMode }) => {
  if (!active || !payload || payload.length === 0) return null;
  const row = payload[0]?.payload;
  if (!row) return null;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 shadow-lg text-xs space-y-1.5">
      <div className="font-display font-semibold text-slate-900 dark:text-slate-100">
        Week of {label}
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-slate-600 dark:text-slate-400">Books Finished</span>
        <span className="font-mono font-semibold tabular-nums text-emerald-700 dark:text-emerald-400">
          {row.booksFinished}
        </span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-slate-600 dark:text-slate-400">
          {metricMode === 'weekly' ? 'Total Reading Time' : 'Avg Daily Reading'}
        </span>
        <span className="font-mono font-semibold tabular-nums text-amber-600 dark:text-amber-400">
          {metricMode === 'weekly' ? `${row.minutesRead} min` : `${row.avgDailyMinutes} min/day`}
        </span>
      </div>
      <div className="flex items-center justify-between gap-4 pt-1 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
        <span>Reading Sessions</span>
        <span className="font-mono tabular-nums">{row.sessionsCount}</span>
      </div>
    </div>
  );
};

export const ReadingAnalytics: React.FC<ReadingAnalyticsProps> = ({
  stats,
  finishedBookIds,
  isCloudSynced,
  onLogQuickSession,
}) => {
  const [metricMode, setMetricMode] = useState<'weekly' | 'daily_avg'>('weekly');

  const chartData = useMemo(() => {
    return stats.map((s) => ({
      ...s,
      avgDailyMinutes: Math.round(s.minutesRead / 7),
    }));
  }, [stats]);

  const summary = useMemo(() => {
    if (stats.length === 0) {
      return { totalBooks: 0, avgWeeklyMinutes: 0, avgDailyMinutes: 0, thisWeekMinutes: 0 };
    }
    const totalBooks = stats.reduce((acc, s) => acc + s.booksFinished, 0);
    const totalMinutes = stats.reduce((acc, s) => acc + s.minutesRead, 0);
    const avgWeeklyMinutes = Math.round(totalMinutes / stats.length);
    const avgDailyMinutes = Math.round(avgWeeklyMinutes / 7);
    const thisWeekMinutes = stats[stats.length - 1]?.minutesRead ?? 0;
    return { totalBooks, avgWeeklyMinutes, avgDailyMinutes, thisWeekMinutes };
  }, [stats]);

  const formatHoursMinutes = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    if (h === 0) return `${m}m`;
    return `${h}h ${m}m`;
  };

  return (
    <section
      aria-label="Reading Analytics"
      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5"
    >
      {/* Header Row */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="space-y-1">
          <h3 className="font-display font-bold text-lg text-slate-900 dark:text-slate-100">
            Reading Analytics
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Weekly books finished and reading time tracked automatically in the Digital Library ·{' '}
            {isCloudSynced ? 'Synced to your account' : 'Saved locally on this device'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs">
            <button
              type="button"
              onClick={() => setMetricMode('weekly')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                metricMode === 'weekly'
                  ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Weekly Total (min)
            </button>
            <button
              type="button"
              onClick={() => setMetricMode('daily_avg')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                metricMode === 'daily_avg'
                  ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Daily Avg (min/day)
            </button>
          </div>

          <button
            type="button"
            onClick={() => onLogQuickSession(15)}
            className="min-h-[36px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-600 text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
            Log +15m Reading
          </button>
        </div>
      </div>

      {/* Summary Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <BookCheck className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
            Books Finished (6 wks)
          </div>
          <div className="text-2xl font-display font-bold font-mono tabular-nums mt-1 text-slate-900 dark:text-slate-100">
            {summary.totalBooks}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5 font-mono tabular-nums">
            {finishedBookIds.length} library titles completed
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            Avg Reading / Week
          </div>
          <div className="text-2xl font-display font-bold font-mono tabular-nums mt-1 text-slate-900 dark:text-slate-100">
            {formatHoursMinutes(summary.avgWeeklyMinutes)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5 font-mono tabular-nums">
            {summary.avgWeeklyMinutes} min / week average
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-xs text-slate-500">Avg Reading / Day</div>
          <div className="text-2xl font-display font-bold font-mono tabular-nums mt-1 text-slate-900 dark:text-slate-100">
            {summary.avgDailyMinutes}m
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Daily habit pace</div>
        </div>

        <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-xs text-slate-500">This Week So Far</div>
          <div className="text-2xl font-display font-bold font-mono tabular-nums mt-1 text-emerald-700 dark:text-emerald-400">
            {formatHoursMinutes(summary.thisWeekMinutes)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5 font-mono tabular-nums">
            {stats[stats.length - 1]?.booksFinished ?? 0} books finished this week
          </div>
        </div>
      </div>

      {/* Recharts Visual Progress Chart */}
      {chartData.length === 0 ? (
        <div className="h-64 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center p-6 space-y-2">
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
            No reading sessions logged yet
          </p>
          <p className="text-xs text-slate-500 max-w-sm">
            Open any book in the Digital Library or tap “Log +15m Reading” above to start tracking your weekly progress.
          </p>
        </div>
      ) : (
        <div className="w-full min-w-0 h-72 pt-2">
          <ResponsiveContainer width="100%" height={280} minWidth={0}>
            <ComposedChart data={chartData} margin={{ top: 10, right: 12, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.2} vertical={false} />
              <XAxis
                dataKey="weekLabel"
                tick={{ fontSize: 12, fill: '#64748b' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                yAxisId="left"
                allowDecimals={false}
                tick={{ fontSize: 12, fill: '#64748b' }}
                axisLine={false}
                tickLine={false}
                label={{
                  value: 'Books',
                  angle: -90,
                  position: 'insideLeft',
                  offset: 18,
                  style: { fontSize: 11, fill: '#64748b' },
                }}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tick={{ fontSize: 12, fill: '#64748b' }}
                axisLine={false}
                tickLine={false}
                label={{
                  value: metricMode === 'weekly' ? 'Minutes' : 'Min/Day',
                  angle: 90,
                  position: 'insideRight',
                  offset: 16,
                  style: { fontSize: 11, fill: '#64748b' },
                }}
              />
              <Tooltip content={<CustomChartTooltip metricMode={metricMode} />} />
              <Legend
                wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }}
                iconType="circle"
              />
              <Bar
                yAxisId="left"
                dataKey="booksFinished"
                name="Books Finished"
                fill="#15803d"
                radius={[6, 6, 0, 0]}
                maxBarSize={36}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey={metricMode === 'weekly' ? 'minutesRead' : 'avgDailyMinutes'}
                name={metricMode === 'weekly' ? 'Reading Time (min/week)' : 'Avg Reading Time (min/day)'}
                stroke="#d97706"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#d97706', strokeWidth: 2, stroke: '#ffffff' }}
                activeDot={{ r: 6 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
};
