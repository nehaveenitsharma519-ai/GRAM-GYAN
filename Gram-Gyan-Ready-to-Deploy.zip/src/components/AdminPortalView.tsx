import React, { useState } from 'react';
import { CheckCircle2, FilePlus2, Users } from 'lucide-react';
import { YEAR_ONE_TARGETS } from '../data/gramGyanData';
import {
  ContentStatus,
  GovernmentScheme,
  GrievanceTicket,
  JobNotification,
  LibraryResource,
  PanchayatNotice,
} from '../types/gramGyan';

const ADMIN_ROLES = [
  'Super Admin',
  'State Admin',
  'District Admin',
  'Block Admin',
  'Panchayat Contributor',
  'Content Editor',
  'Agriculture Expert',
  'Health Reviewer',
  'Job Editor',
  'Support Team',
] as const;

interface AdminPortalViewProps {
  books: LibraryResource[];
  schemes: GovernmentScheme[];
  jobs: JobNotification[];
  notices: PanchayatNotice[];
  grievances: GrievanceTicket[];
  onUpdateItemStatus: (
    kind: 'book' | 'scheme' | 'job' | 'notice',
    id: string,
    status: ContentStatus
  ) => void;
  onAddScheme: (scheme: GovernmentScheme) => void;
  onAddJob: (job: JobNotification) => void;
  onAddNotice: (notice: PanchayatNotice) => void;
  onUpdateGrievanceStatus: (id: string, status: GrievanceTicket['status']) => void;
}

export const AdminPortalView: React.FC<AdminPortalViewProps> = ({
  books,
  schemes,
  jobs,
  notices,
  grievances,
  onUpdateItemStatus,
  onAddScheme,
  onAddJob,
  onAddNotice,
  onUpdateGrievanceStatus,
}) => {
  const [selectedRole, setSelectedRole] = useState<(typeof ADMIN_ROLES)[number]>('Super Admin');
  const [activeTab, setActiveTab] = useState<'pipeline' | 'publish' | 'analytics' | 'support'>('pipeline');

  // Publish form state
  const [publishType, setPublishType] = useState<'scheme' | 'job' | 'notice'>('notice');
  const [title, setTitle] = useState('');
  const [orgOrDept, setOrgOrDept] = useState('');
  const [district, setDistrict] = useState('Bhaderwah');
  const [summary, setSummary] = useState('');
  const [officialUrl, setOfficialUrl] = useState('https://jk.gov.in');
  const [deadline, setDeadline] = useState('31 Dec 2026');
  const [publishSuccess, setPublishSuccess] = useState<string | null>(null);

  const expiredCount =
    jobs.filter((j) => j.status === 'Expired').length +
    schemes.filter((s) => s.status === 'Expired').length;
  const reviewCount =
    books.filter((b) => b.status === 'Under Review').length +
    schemes.filter((s) => s.status === 'Under Review').length +
    jobs.filter((j) => j.status === 'Under Review').length;

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !summary.trim()) return;

    const today = '20 Nov 2026';
    if (publishType === 'scheme') {
      onAddScheme({
        id: `sch-${Date.now()}`,
        title: title.trim(),
        department: orgOrDept.trim() || 'Rural Development Dept., J&K',
        geography: `${district} & J&K`,
        benefitSummary: summary.trim(),
        eligibility: ['Resident & Domicile of J&K', 'Verify documents at CSC / JanSugam'],
        documentsRequired: ['Aadhaar Card', 'Domicile Certificate', 'Bank Passbook'],
        applicationSteps: ['Verify details on official portal', 'Submit application at nearest CSC'],
        officialPortalName: 'Official Portal',
        officialUrl: officialUrl.trim() || 'https://jansugam.jk.gov.in',
        deadline: deadline.trim(),
        lastVerified: today,
        status: 'Verified',
        category: 'Housing & Livelihood',
      });
    } else if (publishType === 'job') {
      onAddJob({
        id: `job-${Date.now()}`,
        title: title.trim(),
        organization: orgOrDept.trim() || 'JKSSB / District Administration',
        location: `${district}, J&K`,
        qualification: summary.trim(),
        vacancies: 'Notified Posts',
        closingDate: deadline.trim(),
        officialPortal: 'Official Recruitment Portal',
        officialUrl: officialUrl.trim() || 'https://jkssb.nic.in',
        lastVerified: today,
        status: 'Verified',
        type: 'Government',
      });
    } else {
      onAddNotice({
        id: `pan-${Date.now()}`,
        title: title.trim(),
        panchayat: 'Pilot Panchayat',
        block: district,
        district,
        date: today,
        category: 'Public Notice',
        summary: summary.trim(),
        issuedBy: orgOrDept.trim() || `${selectedRole} Office`,
        status: 'Verified',
      });
    }

    setPublishSuccess(`Published "${title.trim()}" directly to the live Citizen App.`);
    setTitle('');
    setSummary('');
  };

  const statuses: ContentStatus[] = ['Draft', 'Under Review', 'Verified', 'Expired'];

  return (
    <div className="space-y-6">
      {/* Control Centre Top Workspace Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display font-bold text-2xl">GRAM GYAN Control Centre</h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Product 2: Role-based administration, 4-stage content verification (`Draft` → `Under Review` → `Verified` → `Expired`), and citizen support resolution.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-500">Active Role:</label>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value as (typeof ADMIN_ROLES)[number])}
              className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium"
            >
              {ADMIN_ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Summary KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="text-xs text-slate-500">Verified Items Live</div>
            <div className="text-2xl font-display font-bold font-mono tabular-nums mt-1">
              {books.filter((b) => b.status === 'Verified').length +
                schemes.filter((s) => s.status === 'Verified').length +
                jobs.filter((j) => j.status === 'Verified').length +
                notices.filter((n) => n.status === 'Verified').length}
            </div>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="text-xs text-slate-500">Flagged Expired</div>
            <div className="text-2xl font-display font-bold font-mono tabular-nums text-rose-600 mt-1">
              {expiredCount}
            </div>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="text-xs text-slate-500">Under Review</div>
            <div className="text-2xl font-display font-bold font-mono tabular-nums text-amber-600 mt-1">
              {reviewCount}
            </div>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="text-xs text-slate-500">Open Support Tickets</div>
            <div className="text-2xl font-display font-bold font-mono tabular-nums mt-1">
              {grievances.filter((g) => g.status !== 'Resolved').length}
            </div>
          </div>
        </div>

        {/* Admin Sub-Tabs */}
        <div className="flex flex-wrap gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
          {[
            { id: 'pipeline', label: 'Verification Pipeline' },
            { id: 'publish', label: 'Publish Content' },
            { id: 'analytics', label: 'Year-1 KPIs & Pilot' },
            { id: 'support', label: `Support Queue (${grievances.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'pipeline' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-display font-semibold text-base">
              Content Verification & Expiry Registry ({selectedRole} View)
            </h3>
            <span className="text-xs text-slate-500">Update status to immediately sync Citizen App</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-medium">Type</th>
                  <th className="py-3 px-4 font-medium">Title</th>
                  <th className="py-3 px-4 font-medium">Last Verified</th>
                  <th className="py-3 px-4 font-medium">Status Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {[
                  ...jobs.map((j) => ({ kind: 'job' as const, id: j.id, label: 'Job Vacancy', title: j.title, verified: j.lastVerified, status: j.status })),
                  ...schemes.map((s) => ({ kind: 'scheme' as const, id: s.id, label: 'Gov Scheme', title: s.title, verified: s.lastVerified, status: s.status })),
                  ...books.slice(0, 5).map((b) => ({ kind: 'book' as const, id: b.id, label: 'Library Book', title: b.title, verified: b.lastVerified, status: b.status })),
                  ...notices.map((n) => ({ kind: 'notice' as const, id: n.id, label: 'Panchayat Notice', title: n.title, verified: n.date, status: n.status })),
                ].map((row) => (
                  <tr key={row.kind + row.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 text-xs text-slate-500">{row.label}</td>
                    <td className="py-3 px-4 font-medium">{row.title}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-xs text-slate-500">{row.verified}</td>
                    <td className="py-3 px-4">
                      <select
                        value={row.status}
                        onChange={(e) => onUpdateItemStatus(row.kind, row.id, e.target.value as ContentStatus)}
                        aria-label={`Change verification status for ${row.title}`}
                        className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-xs font-medium"
                      >
                        {statuses.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'publish' && (
        <form
          onSubmit={handlePublish}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 max-w-2xl"
        >
          <div className="flex items-center gap-2 font-display font-semibold text-lg">
            <FilePlus2 className="w-5 h-5 text-emerald-700" />
            Publish Verified Content to Citizen App
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <label className="block text-xs font-medium mb-1">Content Type</label>
              <select
                value={publishType}
                onChange={(e) => setPublishType(e.target.value as typeof publishType)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60"
              >
                <option value="notice">Panchayat Notice</option>
                <option value="scheme">Government Scheme</option>
                <option value="job">Job Notification</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">District Focus</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60"
              >
                <option value="Bhaderwah">Bhaderwah</option>
                <option value="Doda">Doda</option>
                <option value="Baramulla">Baramulla</option>
                <option value="Srinagar">Srinagar</option>
                <option value="Jammu">Jammu</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Title / Headline</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Block Level Kisan Credit Card Camp"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Department / Issuing Authority</label>
              <input
                type="text"
                value={orgOrDept}
                onChange={(e) => setOrgOrDept(e.target.value)}
                placeholder="e.g., Dept. of Horticulture, Baramulla"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Official Source URL</label>
              <input
                type="url"
                value={officialUrl}
                onChange={(e) => setOfficialUrl(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Closing Date / Schedule</label>
            <input
              type="text"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Details / Eligibility Summary</label>
            <textarea
              rows={3}
              required
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="Write simple, verified instructions for citizens..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
            />
          </div>

          {publishSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              {publishSuccess}
            </div>
          )}

          <button
            type="submit"
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-700 text-white text-sm font-medium hover:bg-emerald-800"
          >
            Verify & Publish Immediately
          </button>
        </form>
      )}

      {activeTab === 'analytics' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {YEAR_ONE_TARGETS.map((kpi) => (
              <div key={kpi.label} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2">
                <div className="text-xs text-slate-500">{kpi.label}</div>
                <div className="flex items-baseline justify-between">
                  <span className="text-2xl font-display font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                    {kpi.current}
                  </span>
                  <span className="text-xs font-mono tabular-nums text-slate-500">
                    Target: {kpi.target}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500">{kpi.unit}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'support' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-display font-semibold text-base flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-700" />
            Citizen Support & Content Correction Queue
          </h3>
          {grievances.length === 0 ? (
            <p className="text-sm text-slate-500">No citizen support tickets submitted yet.</p>
          ) : (
            <div className="space-y-3">
              {grievances.map((g) => (
                <div key={g.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <p className="text-xs text-slate-500">
                      {g.citizenName} · {g.district} · {g.category} · {g.submittedAt}
                    </p>
                    <p className="text-sm">{g.message}</p>
                  </div>
                  <select
                    value={g.status}
                    onChange={(e) => onUpdateGrievanceStatus(g.id, e.target.value as GrievanceTicket['status'])}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-xs font-medium shrink-0"
                  >
                    <option value="Open">Open</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
