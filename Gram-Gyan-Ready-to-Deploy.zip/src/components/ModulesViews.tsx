import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Bookmark,
  BookOpen,
  Calculator,
  Check,
  CloudRain,
  Download,
  ExternalLink,
  FileCheck,
  HeartPulse,
  MapPin,
  Phone,
  Scale,
  Search,
  ShieldAlert,
  ShieldCheck,
  Train,
  Volume2,
} from 'lucide-react';
import {
  CERTIFICATE_GUIDES,
  CROP_ADVISORIES,
  EDUCATION_QUIZ,
  HEALTH_CENTRES,
  LIBRARY_CATEGORIES,
  LOCAL_LISTINGS,
  MANDI_PRICES,
  SPOKEN_ENGLISH_LESSONS,
  TRANSPORT_ROUTES,
  WEATHER_FORECASTS,
} from '../data/gramGyanData';
import {
  GovernmentScheme,
  JobNotification,
  LanguageCode,
  LibraryResource,
  ModuleId,
  NewsItem,
  PanchayatNotice,
  UserLocation,
  VillageEntry,
} from '../types/gramGyan';
import { AiAssistantPanel } from './AiAssistantPanel';
import { AnimalHusbandryView } from './AnimalHusbandryView';
import { BookCoverArt } from './BookCoverArt';
import { CropDetectorCamera } from './CropDetectorCamera';
import { CropMarketExchange } from './CropMarketExchange';
import { NewVillageDraft, VillageDirectoryPanel } from './VillageDirectoryPanel';

interface ModulesViewsProps {
  activeModule: ModuleId;
  language: LanguageCode;
  district: string;
  isOffline: boolean;
  lowDataMode: boolean;
  books: LibraryResource[];
  schemes: GovernmentScheme[];
  jobs: JobNotification[];
  notices: PanchayatNotice[];
  news: NewsItem[];
  bookmarkedBookIds: string[];
  downloadedBookIds: string[];
  savedSchemeIds: string[];
  textScale: 'normal' | 'large' | 'xlarge';
  onLanguageChange: (lang: LanguageCode) => void;
  onOpenBook: (book: LibraryResource) => void;
  onToggleBookmark: (bookId: string) => void;
  onToggleDownload: (bookId: string) => void;
  onToggleSaveScheme: (schemeId: string) => void;
  onTextScaleChange: (scale: 'normal' | 'large' | 'xlarge') => void;
  onSelectModule?: (moduleId: ModuleId) => void;
  villages: VillageEntry[];
  currentLocation: UserLocation;
  isCloudSynced: boolean;
  onSelectVillage: (village: VillageEntry) => void;
  onAddVillage: (draft: NewVillageDraft, setAsActive: boolean) => Promise<void>;
  onDeleteCustomVillage: (villageId: string) => Promise<void>;
}

export const ModulesViews: React.FC<ModulesViewsProps> = ({
  activeModule,
  language,
  district,
  isOffline,
  lowDataMode,
  books,
  schemes,
  jobs,
  notices,
  news,
  bookmarkedBookIds,
  downloadedBookIds,
  savedSchemeIds,
  textScale,
  onLanguageChange,
  onOpenBook,
  onToggleBookmark,
  onToggleDownload,
  onToggleSaveScheme,
  onTextScaleChange,
  onSelectModule,
  villages,
  currentLocation,
  isCloudSynced,
  onSelectVillage,
  onAddVillage,
  onDeleteCustomVillage,
}) => {
  const [libraryCategory, setLibraryCategory] = useState<string>('All');
  const [librarySearch, setLibrarySearch] = useState('');
  const [schemeCategory, setSchemeCategory] = useState<string>('All');
  const [jobTypeFilter, setJobTypeFilter] = useState<string>('All');
  const [marketFilter, setMarketFilter] = useState<string>('All');

  // Education quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});

  // Business loan EMI calculator
  const [loanAmount, setLoanAmount] = useState(100000);
  const [loanMonths, setLoanMonths] = useState(24);
  const [interestRate, setInterestRate] = useState(5);

  // Banking UPI safety check
  const [upiChoice, setUpiChoice] = useState<'pin' | 'decline' | null>(null);

  // RTI quick helper
  const [rtiTopic, setRtiTopic] = useState('MGNREGA Muster Roll & Panchayat Road Work');

  const verifiedBooks = useMemo(() => {
    return books.filter((b) => b.status === 'Verified' || b.status === 'Under Review');
  }, [books]);

  const filteredBooks = useMemo(() => {
    return verifiedBooks.filter((b) => {
      if (isOffline && !downloadedBookIds.includes(b.id)) return false;
      if (libraryCategory !== 'All' && b.category !== libraryCategory) return false;
      const q = librarySearch.trim().toLowerCase();
      if (!q) return true;
      return (
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q) ||
        b.language.toLowerCase().includes(q)
      );
    });
  }, [verifiedBooks, isOffline, downloadedBookIds, libraryCategory, librarySearch]);

  const speakEnglish = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-IN';
    u.rate = 0.88;
    window.speechSynthesis.speak(u);
  };

  // EMI Formula
  const monthlyEmi = useMemo(() => {
    const r = interestRate / 12 / 100;
    if (r === 0) return Math.round(loanAmount / loanMonths);
    const factor = Math.pow(1 + r, loanMonths);
    return Math.round((loanAmount * r * factor) / (factor - 1));
  }, [loanAmount, loanMonths, interestRate]);

  if (activeModule === 'ai_assistant') {
    return (
      <AiAssistantPanel
        language={language}
        district={district}
        isOffline={isOffline}
        onLanguageChange={onLanguageChange}
      />
    );
  }

  if (activeModule === 'animal_husbandry') {
    return (
      <AnimalHusbandryView
        schemes={schemes}
        district={district}
        savedSchemeIds={savedSchemeIds}
        onToggleSaveScheme={onToggleSaveScheme}
      />
    );
  }

  if (activeModule === 'library') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="space-y-1">
              <h2 className="font-display font-bold text-2xl text-slate-900 dark:text-slate-100">
                Digital Library — The Heart of GRAM GYAN
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                15 categories of open-access & licensed books, textbooks, newspapers, and Dogri/Kashmiri/Urdu/Hindi literature with offline reading and read-aloud audio.
              </p>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              {downloadedBookIds.length} downloaded · {bookmarkedBookIds.length} bookmarked
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={librarySearch}
                onChange={(e) => setLibrarySearch(e.target.value)}
                placeholder="Search books, NCERT/JKBOSE guides, Dogri/Kashmiri literature..."
                className="w-full min-h-[44px] pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <select
              value={libraryCategory}
              onChange={(e) => setLibraryCategory(e.target.value)}
              aria-label="Filter library by category"
              className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="All">All 15 Categories</option>
              {LIBRARY_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>

        {filteredBooks.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-2">
            <BookOpen className="w-8 h-8 mx-auto text-slate-400" />
            <p className="font-medium text-slate-800 dark:text-slate-200">
              {isOffline
                ? 'No books downloaded for offline reading yet.'
                : 'No resources matched your filter.'}
            </p>
            <p className="text-xs text-slate-500">
              {isOffline
                ? 'Switch back online briefly and tap Download on any book to keep it available offline.'
                : 'Try clearing the search query or selecting All 15 Categories.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredBooks.map((book) => {
              const isSaved = bookmarkedBookIds.includes(book.id);
              const isDl = downloadedBookIds.includes(book.id);
              return (
                <div
                  key={book.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-3">
                    {!lowDataMode && <BookCoverArt book={book} compact />}
                    <div className="space-y-1.5">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {book.category} · {book.language} · Verified {book.lastVerified}
                      </p>
                      <h3 className="font-display font-semibold text-base text-slate-900 dark:text-slate-100 leading-snug">
                        {book.title}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                        {book.summary}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Source: {book.source} · {book.copyrightStatus}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => onOpenBook(book)}
                      className="flex-1 min-h-[40px] px-3 py-2 rounded-xl bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 transition-colors"
                    >
                      Read / Listen
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleBookmark(book.id)}
                      aria-label={isSaved ? 'Remove bookmark' : 'Bookmark resource'}
                      className={`min-h-[40px] min-w-[40px] rounded-xl border flex items-center justify-center transition-colors ${
                        isSaved
                          ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-400 text-amber-700 dark:text-amber-400'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleDownload(book.id)}
                      aria-label={isDl ? 'Downloaded offline' : 'Download for offline reading'}
                      className={`min-h-[40px] px-2.5 rounded-xl border text-xs font-medium inline-flex items-center gap-1 transition-colors ${
                        isDl
                          ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-700 dark:text-emerald-400'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {isDl ? <Check className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
                      <span className="font-mono tabular-nums">
                        {lowDataMode ? book.lowDataSizeKb : book.sizeKb}KB
                      </span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  if (activeModule === 'education') {
    const score = EDUCATION_QUIZ.reduce((acc, q) => (quizAnswers[q.id] === q.correctIndex ? acc + 1 : acc), 0);
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Education Centre — JKBOSE, NCERT & Quizzes</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Official school curriculum portals (DIKSHA & JKBOSE), scholarship links, and interactive practice quizzes for rural students.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="https://diksha.gov.in"
              target="_blank"
              rel="noreferrer"
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-600 transition-colors space-y-1"
            >
              <div className="font-semibold text-sm flex items-center justify-between">
                DIKSHA National Portal <ExternalLink className="w-4 h-4 text-emerald-700" />
              </div>
              <p className="text-xs text-slate-500">Class 1–12 textbooks, QR lessons & state boards</p>
            </a>
            <a
              href="https://jkbose.nic.in"
              target="_blank"
              rel="noreferrer"
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-600 transition-colors space-y-1"
            >
              <div className="font-semibold text-sm flex items-center justify-between">
                JKBOSE Official Portal <ExternalLink className="w-4 h-4 text-emerald-700" />
              </div>
              <p className="text-xs text-slate-500">J&K Class 10 & 12 syllabus, date sheets & results</p>
            </a>
            <a
              href="https://scholarships.gov.in"
              target="_blank"
              rel="noreferrer"
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-600 transition-colors space-y-1"
            >
              <div className="font-semibold text-sm flex items-center justify-between">
                National Scholarship Portal <ExternalLink className="w-4 h-4 text-emerald-700" />
              </div>
              <p className="text-xs text-slate-500">Pre-Matric, Post-Matric & JK merit scholarships</p>
            </a>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="font-display font-semibold text-lg">Daily Knowledge Practice Quiz</h3>
              <p className="text-xs text-slate-500">Tap an option to check your answer immediately</p>
            </div>
            <div className="text-sm font-mono font-semibold tabular-nums text-emerald-700 dark:text-emerald-400">
              Score: {score} / {EDUCATION_QUIZ.length}
            </div>
          </div>

          <div className="space-y-5">
            {EDUCATION_QUIZ.map((q, idx) => {
              const selected = quizAnswers[q.id];
              return (
                <div key={q.id} className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <div className="text-xs text-slate-500">
                    Question {idx + 1} · {q.subject}
                  </div>
                  <p className="font-medium text-sm sm:text-base">{q.question}</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = selected === optIdx;
                      const isCorrect = optIdx === q.correctIndex;
                      let btnClass =
                        'border-slate-200 dark:border-slate-700 hover:border-emerald-600 text-slate-800 dark:text-slate-200';
                      if (selected !== undefined) {
                        if (isCorrect) {
                          btnClass = 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200';
                        } else if (isSelected) {
                          btnClass = 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200';
                        }
                      }
                      return (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => setQuizAnswers((prev) => ({ ...prev, [q.id]: optIdx }))}
                          className={`min-h-[44px] px-4 py-2.5 rounded-xl border text-left text-xs sm:text-sm font-medium transition-colors ${btnClass}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {selected !== undefined && (
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Explanation: {q.explanation}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  if (activeModule === 'career') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Career & Competitive Exam Preparation</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Structured study roadmaps and official portals for JKSSB, JKPSC, UPSC, SSC, Banking, and Defence examinations.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { exam: 'JKSSB (Patwari / VLW / Junior Assistant)', syllabus: 'General English, J&K GK & Reorganization Act, Quantitative Aptitude, Basic Computers', url: 'https://jkssb.nic.in' },
              { exam: 'JKPSC (JKAS / Gazetted Services)', syllabus: 'Indian Polity, History, Geography, J&K Economy, Essay & Ethics', url: 'https://jkpsc.nic.in' },
              { exam: 'SSC & Banking (CGL / CHSL / IBPS)', syllabus: 'Reasoning, Numerical Ability, English Comprehension, Financial Awareness', url: 'https://ssc.gov.in' },
              { exam: 'Agniveer & Defence Services', syllabus: 'General Science, Mathematics, Physical Fitness Standards & NCC Bonus', url: 'https://joinindianarmy.nic.in' },
              { exam: 'UPSC Civil Services & NDA', syllabus: 'NCERT Foundation (Class 6–12), Current Affairs (PIB), CSAT Practice', url: 'https://upsc.gov.in' },
            ].map((item) => (
              <div key={item.exam} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <h3 className="font-display font-semibold text-base">{item.exam}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">{item.syllabus}</p>
                <a
                  href={item.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
                >
                  Official Exam Portal <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (activeModule === 'skills') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Skill Development & Spoken English</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Practice everyday spoken English with audio playback, basic computer skills, and rural entrepreneurship modules.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SPOKEN_ENGLISH_LESSONS.map((lesson) => (
              <div key={lesson.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">{lesson.topic}</span>
                  <button
                    type="button"
                    onClick={() => speakEnglish(lesson.english)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-emerald-700" />
                    Listen
                  </button>
                </div>
                <p className="font-semibold text-sm sm:text-base">{lesson.english}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">{lesson.hindi}</p>
                <p className="text-[11px] text-slate-500">{lesson.tip}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { title: 'Digital Literacy & CSC Basics', desc: 'Typing, DigiLocker PDF download, email & online form safety.' },
            { title: 'Solar & Cold-Storage Maintenance', desc: 'Vocational skills aligned with J&K horticulture & rural power.' },
            { title: 'Tailoring, Food Processing & Packaging', desc: 'Vocational training links via Skill India Digital Hub (SIDH).' },
          ].map((track) => (
            <div key={track.title} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
              <h3 className="font-display font-semibold text-sm">{track.title}</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400">{track.desc}</p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'schemes') {
    const categories = [
      'All',
      'Farmers',
      'Animal & Sheep Husbandry',
      'Health',
      'Women & Child',
      'Senior Citizen',
      'Education',
      'Housing & Livelihood',
    ];
    const visibleSchemes = schemes.filter(
      (s) => s.status !== 'Draft' && (schemeCategory === 'All' || s.category === schemeCategory)
    );
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="space-y-1">
            <h2 className="font-display font-bold text-2xl">Government Schemes — Eligibility & Official Portals</h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Important: GRAM GYAN provides verified informational guidance and checklists. Official applications and approvals happen only on authorised Government portals or your nearest CSC.
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSchemeCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  schemeCategory === cat
                    ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {visibleSchemes.map((sch) => {
            const isSaved = savedSchemeIds.includes(sch.id);
            return (
              <div
                key={sch.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {sch.department} · {sch.geography} · Verified {sch.lastVerified}
                    </p>
                    <h3 className="font-display font-bold text-lg">{sch.title}</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleSaveScheme(sch.id)}
                    className={`min-h-[40px] px-3 rounded-xl border text-xs font-medium whitespace-nowrap ${
                      isSaved
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    {isSaved ? 'Saved' : 'Save Guide'}
                  </button>
                </div>

                <p className="text-sm text-slate-700 dark:text-slate-300">{sch.benefitSummary}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1.5">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">Eligibility</div>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc pl-4">
                      {sch.eligibility.map((e, i) => (
                        <li key={i}>{e}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="space-y-1.5">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">Required Documents</div>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400 list-disc pl-4">
                      {sch.documentsRequired.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">How to Apply</div>
                  <ol className="space-y-1 text-slate-600 dark:text-slate-400 list-decimal pl-4">
                    {sch.applicationSteps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ol>
                </div>

                <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <span className="text-slate-500">Deadline: {sch.deadline}</span>
                  <a
                    href={sch.officialUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 text-white font-medium hover:bg-emerald-800"
                  >
                    {sch.officialPortalName}
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (activeModule === 'panchayat') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
          <h2 className="font-display font-bold text-2xl">Panchayat Connect — Verified Village Notices</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Gram Sabha schedules, MGNREGA rural development works, Jal Jeevan Mission updates, and block contacts.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {notices
            .filter((n) => n.status === 'Verified')
            .map((notice) => (
              <div
                key={notice.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3"
              >
                <p className="text-xs text-slate-500">
                  {notice.category} · {notice.district} · {notice.date}
                </p>
                <h3 className="font-display font-semibold text-base">{notice.title}</h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">{notice.summary}</p>
                <p className="text-xs text-emerald-700 dark:text-emerald-400 font-medium pt-2 border-t border-slate-100 dark:border-slate-800">
                  {notice.panchayat} ({notice.block} Block) · Issued by {notice.issuedBy}
                </p>
              </div>
            ))}
        </div>

        <VillageDirectoryPanel
          villages={villages}
          currentLocation={currentLocation}
          isCloudSynced={isCloudSynced}
          onSelectVillage={onSelectVillage}
          onAddVillage={onAddVillage}
          onDeleteCustomVillage={onDeleteCustomVillage}
        />
      </div>
    );
  }

  if (activeModule === 'documents') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
          <h2 className="font-display font-bold text-2xl">Citizen Document Guide</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Step-by-step checklists for J&K Domicile, Income, Category (SC/ST/RBA/OBC/EWS), Birth & Death certificates via JanSugam & DigiLocker.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {CERTIFICATE_GUIDES.map((doc) => (
            <div key={doc.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
              <div>
                <p className="text-xs text-slate-500">
                  {doc.issuingAuthority} · {doc.processingTime}
                </p>
                <h3 className="font-display font-bold text-lg mt-1">{doc.name}</h3>
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="font-semibold">Required Documents</div>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400">
                  {doc.documents.map((d, i) => (
                    <li key={i}>{d}</li>
                  ))}
                </ul>
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="font-semibold">Application Steps</div>
                <ol className="list-decimal pl-4 space-y-1 text-slate-600 dark:text-slate-400">
                  {doc.steps.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <span className="text-slate-500">Fee: {doc.fee}</span>
                <a
                  href={doc.portalUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
                >
                  {doc.portalName} <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'rights') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Rights & Legal Awareness</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Free legal aid, Right to Information (RTI), consumer grievance portals, and rural citizen protections.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
              <div className="font-semibold flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-emerald-700" /> NALSA Free Legal Aid
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Women, children, senior citizens, and low-income citizens get free lawyer support through District Legal Services Authority.
              </p>
              <p className="font-mono text-xs font-semibold">Helpline: 15100</p>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
              <div className="font-semibold flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-700" /> Consumer Rights Helpline
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Report defective goods, overcharging, or unfair digital marketplace practices to National Consumer Helpline.
              </p>
              <p className="font-mono text-xs font-semibold">Helpline: 1915</p>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
              <div className="font-semibold flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-emerald-700" /> J&K Grievance Redressal
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Track civic complaints directly with district offices via JK-IGRAMS or CPGRAMS.
              </p>
              <a
                href="https://pgportal.gov.in"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:underline"
              >
                CPGRAMS Portal <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-3">
          <h3 className="font-display font-semibold text-lg">Simple RTI Application Draft Preview</h3>
          <input
            type="text"
            value={rtiTopic}
            onChange={(e) => setRtiTopic(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
            placeholder="Enter public record topic..."
          />
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs font-mono leading-relaxed whitespace-pre-line">
            {`To,\nThe Public Information Officer (PIO),\nBlock Development Office / Tehsil Office, ${district}\n\nSubject: Application under Section 6(1) of the RTI Act, 2005\n\nSir/Madam,\nPlease provide certified copies / inspection details regarding: ${rtiTopic}.\nI am enclosing the prescribed ₹10 fee (or BPL exemption copy). Kindly reply within 30 days.`}
          </div>
        </div>
      </div>
    );
  }

  if (activeModule === 'farming') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
          <h2 className="font-display font-bold text-2xl">
            Farmer Connect — AI Crop Camera, All-India Crops, Certified Seeds &amp; Mandi Exchange
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Scan any crop leaf or plant with live camera AI detection, track 64 All-India crop market prices across 8 categories, explore 43 certified seed varieties with market &amp; Govt. subsidised rates, and view verified SKUAST / KVK advisories. Kisan Call Centre:{' '}
            <span className="font-mono font-semibold">1800-180-1551</span>.
          </p>
        </div>

        {/* High-Level AI Crop, Pest & Disease Detector with Live Camera */}
        <CropDetectorCamera language={language} district={district} isOffline={isOffline} />

        {/* All-India Crop Stock Market & Market Price Board */}
        <CropMarketExchange />

        {/* Direct Link to Animal & Sheep Husbandry Department */}
        {onSelectModule && (
          <div className="bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="font-display font-bold text-base text-slate-900 dark:text-slate-100">
                  Animal &amp; Sheep Husbandry Department
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                  Explore NLM 50% subsidies, ISDS Sheep/Goat &amp; IDDS Dairy units, HADP training, KCC Livestock loans, vaccination calendar &amp; 1962 Mobile Vet Helpline.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onSelectModule('animal_husbandry')}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs sm:text-sm font-medium hover:bg-emerald-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
            >
              Open Animal &amp; Sheep Dept.
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Regional J&K Pilot Mandi Summary */}

        {/* Mandi Prices Table */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-2">
            <h3 className="font-display font-semibold text-base">AGMARKNET Mandi Rates (Jammu & Kashmir)</h3>
            <a
              href="https://agmarknet.gov.in"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
            >
              AGMARKNET Live Portal <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-medium">Commodity</th>
                  <th className="py-3 px-4 font-medium">Mandi / District</th>
                  <th className="py-3 px-4 font-medium text-right">Min</th>
                  <th className="py-3 px-4 font-medium text-right">Max</th>
                  <th className="py-3 px-4 font-medium text-right">Modal</th>
                  <th className="py-3 px-4 font-medium text-right">Updated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {MANDI_PRICES.map((m) => (
                  <tr key={m.commodity + m.mandi} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-medium">
                      {m.commodity}
                      <span className="block text-[11px] text-slate-500 font-normal">{m.variety}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {m.mandi} ({m.district})
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">₹{m.minPrice.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">₹{m.maxPrice.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                      ₹{m.modalPrice.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 text-right text-xs text-slate-500 font-mono tabular-nums">{m.updatedAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Crop Advisories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {CROP_ADVISORIES.map((adv) => (
            <div key={adv.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
              <p className="text-xs text-slate-500">
                {adv.district} · {adv.season} · Verified {adv.lastVerified}
              </p>
              <h3 className="font-display font-semibold text-base">{adv.crop}</h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">{adv.advisory}</p>
              <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                {adv.actionChecklist.map((c, i) => (
                  <li key={i}>{c}</li>
                ))}
              </ul>
              <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
                Source: {adv.source}
              </p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'business') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Business Centre — SHGs, Rural MSMEs & Loan Planner</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Small-business opportunities in J&K (apple grading, honey, walnut processing, woollen crafts, eco-homestays) and an interactive micro-loan EMI estimator.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            <div className="space-y-4 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="font-display font-semibold text-base flex items-center gap-2">
                <Calculator className="w-4 h-4 text-emerald-700" />
                Rural Micro-Enterprise EMI Estimator (Mudra / PMEGP / Vishwakarma)
              </div>
              <div className="space-y-3 text-xs sm:text-sm">
                <label className="block space-y-1">
                  <span className="flex justify-between">
                    <span>Loan Amount</span>
                    <span className="font-mono font-semibold tabular-nums">₹{loanAmount.toLocaleString('en-IN')}</span>
                  </span>
                  <input
                    type="range"
                    min={25000}
                    max={500000}
                    step={25000}
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(Number(e.target.value))}
                    className="w-full accent-emerald-700"
                  />
                </label>

                <label className="block space-y-1">
                  <span className="flex justify-between">
                    <span>Tenure (Months)</span>
                    <span className="font-mono font-semibold tabular-nums">{loanMonths} months</span>
                  </span>
                  <input
                    type="range"
                    min={6}
                    max={60}
                    step={6}
                    value={loanMonths}
                    onChange={(e) => setLoanMonths(Number(e.target.value))}
                    className="w-full accent-emerald-700"
                  />
                </label>

                <label className="block space-y-1">
                  <span className="flex justify-between">
                    <span>Annual Interest Rate</span>
                    <span className="font-mono font-semibold tabular-nums">{interestRate}%</span>
                  </span>
                  <input
                    type="range"
                    min={4}
                    max={14}
                    step={0.5}
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full accent-emerald-700"
                  />
                </label>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Estimated Monthly EMI</span>
                  <span className="text-2xl font-display font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                    ₹{monthlyEmi.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {[
                { title: 'JKRLM UMEED Self-Help Groups', desc: 'Revolving fund & bank linkage for women collectives producing Bhaderwah rajmash, spices, and handicrafts.' },
                { title: 'PMEGP & JKREGP Subsidy Units', desc: 'Up to 35% margin-money subsidy in rural areas for cold storage, dairy, bakery, and carpentry.' },
                { title: 'ONDC & GeM Seller Onboarding', desc: 'List GI-tagged Kashmiri saffron, walnut woodcraft, and Basohli art directly with national buyers.' },
              ].map((idea) => (
                <div key={idea.title} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
                  <h3 className="font-display font-semibold text-sm">{idea.title}</h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400">{idea.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeModule === 'jobs') {
    const types = ['All', 'Government', 'Apprenticeship', 'Defence'];
    const visibleJobs = jobs.filter((j) => jobTypeFilter === 'All' || j.type === jobTypeFilter);
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="font-display font-bold text-2xl">Employment Exchange — Verified Vacancies</h2>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                JKSSB, JKPSC, NHM J&K, National Career Service & Defence openings with automatic expiry review.
              </p>
            </div>
            <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {types.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setJobTypeFilter(t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                    jobTypeFilter === t ? 'bg-white dark:bg-slate-950 text-emerald-700 shadow-sm' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {visibleJobs.map((job) => (
            <div
              key={job.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <p className="text-xs text-slate-500">
                  {job.organization} · {job.type} · Closing: <span className="font-mono tabular-nums">{job.closingDate}</span> ·{' '}
                  <span className={job.status === 'Expired' ? 'text-rose-600 font-semibold' : 'text-emerald-700 font-semibold'}>
                    {job.status}
                  </span>
                </p>
                <h3 className="font-display font-semibold text-lg">{job.title}</h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                  {job.qualification} · {job.vacancies} · {job.location}
                </p>
              </div>
              <a
                href={job.officialUrl}
                target="_blank"
                rel="noreferrer"
                className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              >
                {job.officialPortal}
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'banking') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Banking, UPI Safety & Financial Literacy</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Learn safe digital payments, Jan Dhan savings, low-cost life/accident insurance, and cyber fraud helpline <span className="font-mono font-semibold">1930</span>.
          </p>

          <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <h3 className="font-display font-semibold text-base">Interactive Safety Check: Someone sends a ₹5,000 "Lottery Collect Request" on UPI</h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              They ask you to tap "Pay" and enter your 4-digit UPI PIN so ₹5,000 gets credited to your account. What should you do?
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setUpiChoice('pin')}
                className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs sm:text-sm font-medium hover:border-rose-500"
              >
                Enter my UPI PIN to receive money
              </button>
              <button
                type="button"
                onClick={() => setUpiChoice('decline')}
                className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs sm:text-sm font-medium hover:border-emerald-600"
              >
                Decline immediately & never share PIN
              </button>
            </div>
            {upiChoice === 'pin' && (
              <p className="text-xs text-rose-700 dark:text-rose-400 font-medium">
                Danger! Entering your UPI PIN always DEDUCTS money from your bank account. You never enter a PIN to receive money.
              </p>
            )}
            {upiChoice === 'decline' && (
              <p className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">
                Correct! Declining unknown collect requests keeps your savings safe. Report fraud calls to 1930.
              </p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs sm:text-sm">
            {[
              { title: 'PMSBY Accident Insurance', cost: '₹20 / year', cover: '₹2 Lakh accidental death & disability cover (Age 18–70)' },
              { title: 'PMJJBY Life Insurance', cost: '₹436 / year', cover: '₹2 Lakh life cover via bank auto-debit (Age 18–50)' },
              { title: 'Atal Pension Yojana (APY)', cost: 'From ₹42 / mo', cover: 'Guaranteed ₹1,000–₹5,000 monthly pension after age 60' },
            ].map((plan) => (
              <div key={plan.title} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-semibold">{plan.title}</div>
                <div className="font-mono text-emerald-700 dark:text-emerald-400 font-semibold">{plan.cost}</div>
                <p className="text-xs text-slate-600 dark:text-slate-400">{plan.cover}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (activeModule === 'health') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Health & Wellness — Emergency Contacts & Hospitals</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Ambulance Emergency', num: '108' },
              { label: 'Maternal / Child', num: '102' },
              { label: 'Unified Emergency', num: '112' },
              { label: 'Tele-MANAS Mental Health', num: '14416' },
            ].map((sos) => (
              <div key={sos.num} className="p-4 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/60 dark:bg-rose-950/30 space-y-1">
                <div className="text-xs text-slate-600 dark:text-slate-300">{sos.label}</div>
                <div className="text-2xl font-display font-bold font-mono tabular-nums text-rose-700 dark:text-rose-400">
                  {sos.num}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {HEALTH_CENTRES.map((hc) => (
            <div key={hc.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2.5">
              <p className="text-xs text-slate-500">
                {hc.type} · {hc.district} ({hc.block} Block) · {hc.timing}
              </p>
              <h3 className="font-display font-semibold text-base flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-rose-600 shrink-0" />
                {hc.name}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400">Services: {hc.services.join(' · ')}</p>
              <div className="text-xs font-mono font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5 pt-1">
                <Phone className="w-3.5 h-3.5" /> {hc.phone}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'weather') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
          <h2 className="font-display font-bold text-2xl">Weather & IMD District Alerts</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            District weather forecasts, frost warnings, and orchard advisories sourced from India Meteorological Department (IMD).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {WEATHER_FORECASTS.map((w) => (
            <div key={w.district} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500">{w.source} · {w.updatedAt}</p>
                  <h3 className="font-display font-bold text-xl mt-0.5">{w.district} District</h3>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-display font-bold font-mono tabular-nums">{w.tempC}°C</div>
                  <div className="text-xs text-slate-500">{w.condition}</div>
                </div>
              </div>
              <div className="flex gap-4 text-xs text-slate-600 dark:text-slate-400 font-mono tabular-nums">
                <span>Humidity: {w.humidity}</span>
                <span>Rain/Snow Prob: {w.rainChance}</span>
              </div>
              <div className={`p-3 rounded-xl text-xs space-y-1 ${
                w.alertLevel === 'Advisory'
                  ? 'bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200'
                  : 'bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700'
              }`}>
                <div className="font-semibold flex items-center gap-1.5">
                  {w.alertLevel === 'Advisory' ? <AlertTriangle className="w-3.5 h-3.5" /> : <CloudRain className="w-3.5 h-3.5" />}
                  {w.alertLevel}: {w.alertMessage}
                </div>
                <p>Farmer Tip: {w.farmerTip}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'transport') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
          <h2 className="font-display font-bold text-2xl">Transport Directory — JKSRTC, Trains & Local Shuttles</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Rural bus timings, Northern Railway DEMU/Express routes, estimated fares, and enquiry numbers (Railway Helpline: <span className="font-mono font-semibold">139</span>).
          </p>
        </div>

        <div className="space-y-3">
          {TRANSPORT_ROUTES.map((tr) => (
            <div key={tr.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <p className="text-xs text-slate-500">{tr.mode} · {tr.district} District</p>
                <h3 className="font-display font-semibold text-base flex items-center gap-2">
                  <Train className="w-4 h-4 text-emerald-700 shrink-0" />
                  {tr.routeName}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">Timings: {tr.schedule}</p>
              </div>
              <div className="text-left sm:text-right text-xs space-y-1 shrink-0">
                <div className="font-mono font-semibold text-emerald-700 dark:text-emerald-400">{tr.fareEstimate}</div>
                <div className="font-mono text-slate-500">Helpline: {tr.helpline}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'marketplace') {
    const categories = ['All', 'CSC Centre', 'Women SHG', 'Mechanic', 'Agri & Seed Shop', 'Electrician & Plumber', 'Homestay'];
    const filtered = LOCAL_LISTINGS.filter((item) => marketFilter === 'All' || item.category === marketFilter);
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Local Marketplace & Village Services Directory</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Verified local CSC centres, mechanics, electricians, seed stores, rural homestays, and Women SHG artisan groups.
          </p>
          <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setMarketFilter(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                  marketFilter === cat ? 'bg-white dark:bg-slate-950 text-emerald-700 shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((item) => (
            <div key={item.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2.5">
              <p className="text-xs text-slate-500">{item.category} · {item.district}</p>
              <h3 className="font-display font-semibold text-base">{item.name}</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400">{item.description}</p>
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" /> {item.village}
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400">{item.contact}</span>
                <span className="text-slate-500">{item.verifiedBy}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'news') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
          <h2 className="font-display font-bold text-2xl">News & Verified Information</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            District, J&K state, and national public updates sourced strictly from PIB, DIPR J&K, and district information offices.
          </p>
        </div>

        <div className="space-y-4">
          {news.map((item) => (
            <article key={item.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2">
              <p className="text-xs text-slate-500">
                {item.scope} {item.district ? `· ${item.district}` : ''} · {item.source} · {item.publishedAt}
              </p>
              <h3 className="font-display font-semibold text-lg">{item.headline}</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">{item.summary}</p>
              <a
                href={item.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline pt-1"
              >
                Read Official Source <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </article>
          ))}
        </div>
      </div>
    );
  }

  if (activeModule === 'women_child') {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="font-display font-bold text-2xl">Women & Child Development</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Empowerment programmes, maternal & child nutrition, Ladli Beti, LIC Bima Sakhi, UMEED Self-Help Groups, and 181 Women Helpline.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { title: 'Ladli Beti (J&K)', desc: '₹1,000/month deposited for eligible newborn girls yielding ~₹6.5 lakh at age 21.', helpline: 'Social Welfare / Anganwadi' },
              { title: 'Bima Sakhi & UMEED SHGs', desc: 'Stipend-backed rural women insurance agent training and interest-subvented SHG livelihood loans.', helpline: 'JKRLM Block Office' },
              { title: 'Women & Child Helplines', desc: '24x7 emergency assistance for women in distress and child protection.', helpline: 'Women: 181 · Childline: 1098' },
            ].map((card) => (
              <div key={card.title} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <h3 className="font-display font-semibold text-base">{card.title}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">{card.desc}</p>
                <p className="text-xs font-mono font-semibold text-emerald-700 dark:text-emerald-400">{card.helpline}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // senior_citizen
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display font-bold text-2xl">Senior Citizen Corner</h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Old-age pension assistance, Ayushman Vaya Vandana health care (70+), Elderline <span className="font-mono font-semibold">14567</span>, and comfortable large-text reading controls.
            </p>
          </div>
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            {(['normal', 'large', 'xlarge'] as const).map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => onTextScaleChange(sz)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${
                  textScale === sz ? 'bg-white dark:bg-slate-950 text-emerald-700 shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {sz === 'xlarge' ? 'Extra Large' : sz} Text
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
            <h3 className="font-display font-semibold text-base">National Elderline Helpline</h3>
            <p className="text-2xl font-mono font-bold text-emerald-700 dark:text-emerald-400">14567</p>
            <p className="text-xs text-slate-600 dark:text-slate-400">Free toll-free guidance for pensions, legal aid, and health support.</p>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
            <h3 className="font-display font-semibold text-base">J&K Integrated Old Age Pension</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">Monthly pension for citizens 60+ under Priority/BPL category via JanSugam or CSC.</p>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
            <h3 className="font-display font-semibold text-base">Ayushman Vaya Vandana (70+)</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">Additional ₹5 lakh cashless hospital cover for all senior citizens aged 70+ regardless of income.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
