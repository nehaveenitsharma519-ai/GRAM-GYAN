import React, { useEffect, useRef, useState } from 'react';
import {
  Bot,
  Globe,
  Loader2,
  Mic,
  MicOff,
  RotateCcw,
  Send,
  ShieldCheck,
  User,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  CHATBOT_ROLES,
  CHAT_VOICE_LANGUAGES,
  CHAT_VOICE_PERSONAS,
  ChatVoicePersonaId,
  useChat,
} from '../contexts/ChatContext';
import { LANGUAGES } from '../data/translations';
import { useSpeechToText } from '../hooks/useSpeechToText';
import { LanguageCode } from '../types/gramGyan';

interface AiAssistantPanelProps {
  language: LanguageCode;
  district: string;
  isOffline: boolean;
  onLanguageChange: (lang: LanguageCode) => void;
}

export const AiAssistantPanel: React.FC<AiAssistantPanelProps> = ({
  language,
  district,
  isOffline,
  onLanguageChange,
}) => {
  const {
    messages,
    activeRoleId,
    activeRole,
    loading,
    errorMsg,
    autoRead,
    voiceGender,
    voicePersona,
    voiceLanguageId,
    activeVoiceLanguage,
    speechRate,
    speakingMsgId,
    ttsLoadingMsgId,
    setActiveRoleId,
    setAutoRead,
    setVoiceGender,
    setVoicePersona,
    setVoiceLanguageId,
    setSpeechRate,
    speakMessage,
    stopSpeaking,
    sendMessage,
    retryLastMessage,
    clearHistory,
  } = useChat();

  const [query, setQuery] = useState('');
  const threadEndRef = useRef<HTMLDivElement | null>(null);

  const {
    isListening,
    isTranscribing,
    voiceError,
    toggleRecording,
  } = useSpeechToText({
    languageName: activeVoiceLanguage.apiLanguage,
    speechLang: activeVoiceLanguage.speechLang,
    isOffline,
    onTranscript: (transcript) => {
      setQuery((prev) => (prev ? `${prev.trim()} ${transcript}` : transcript));
    },
  });

  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, loading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    const text = query;
    setQuery('');
    await sendMessage(text);
  };

  const displayError = errorMsg || voiceError;

  return (
    <div className="space-y-5">
      {/* Assistant Header, Roles & Language Controls */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <h2 className="font-display font-bold text-2xl text-slate-900 dark:text-slate-100">
              AI Village Chatbot ({activeRole.label})
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Multi-turn conversation with speech-to-text input and clear, natural Gemini voices across Hindi, English, Marathi, Kannada &amp; regional languages for {district}.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              {LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => onLanguageChange(l.code)}
                  className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                    language === l.code
                      ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  {l.nativeLabel}
                </button>
              ))}
            </div>

            {messages.length > 0 && (
              <button
                type="button"
                onClick={clearHistory}
                className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                New Chat
              </button>
            )}
          </div>
        </div>

        {/* Chatbot Role / System Instruction Switcher */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Select Chatbot Role (System Persona):
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {CHATBOT_ROLES.map((role) => {
              const selected = activeRoleId === role.id;
              return (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => setActiveRoleId(role.id)}
                  className={`p-3 rounded-xl border text-left transition-colors ${
                    selected
                      ? 'border-emerald-700 bg-emerald-50/70 dark:bg-emerald-950/40 dark:border-emerald-500'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-display font-semibold text-xs text-slate-900 dark:text-slate-100">
                      {role.label}
                    </span>
                    <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400">
                      {role.modelLabel === 'gemini-3.1-flash-lite' ? 'Fast' : 'Standard'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 line-clamp-1">
                    {role.subtitle}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Multi-Language Natural Voice & Auto-Read Settings */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <label className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
              <Globe className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
              <select
                aria-label="Chatbot voice language"
                value={voiceLanguageId}
                onChange={(e) => setVoiceLanguageId(e.target.value)}
                className="bg-transparent text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none"
              >
                {CHAT_VOICE_LANGUAGES.map((vLang) => (
                  <option key={vLang.id} value={vLang.id}>
                    {vLang.label}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={() => setAutoRead(!autoRead)}
              aria-pressed={autoRead}
              className={`px-3 py-1.5 rounded-xl font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                autoRead
                  ? 'bg-emerald-700 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {autoRead ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              Auto-Read: {autoRead ? 'On' : 'Off'}
            </button>

            <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setVoiceGender('female')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  voiceGender === 'female'
                    ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Female Voice
              </button>
              <button
                type="button"
                onClick={() => setVoiceGender('male')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  voiceGender === 'male'
                    ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Male Voice
              </button>
            </div>

            <select
              aria-label="Natural voice tone preset"
              value={voicePersona}
              onChange={(e) => setVoicePersona(e.target.value as ChatVoicePersonaId)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-200"
            >
              {CHAT_VOICE_PERSONAS.map((persona) => (
                <option key={persona.id} value={persona.id}>
                  {persona.label}
                </option>
              ))}
            </select>

            <select
              aria-label="Voice reading speed"
              value={speechRate}
              onChange={(e) => setSpeechRate(Number(e.target.value))}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-700 dark:text-slate-200"
            >
              <option value={0.85}>Speed 0.85×</option>
              <option value={1.0}>Speed 1.0×</option>
              <option value={1.15}>Speed 1.15×</option>
            </select>
          </div>
        </div>

        {/* Verified Guidance Safety Note */}
        <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-900 dark:text-emerald-200">
          <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-700 dark:text-emerald-400" />
          <p>
            Verified Guidance Rule: GRAM GYAN never fabricates schemes, vacancies, or medical prescriptions. Always verify final applications on official portals (JanSugam, UMANG, DigiLocker) or your CSC.
          </p>
        </div>
      </div>

      {/* Scrollable Multi-Turn Conversation Thread */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex flex-col">
        <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span className="font-medium text-slate-700 dark:text-slate-200">
            Conversation Thread · {activeRole.label} · {activeVoiceLanguage.apiLanguage}
          </span>
          <span className="font-mono tabular-nums">{messages.length} messages</span>
        </div>

        <div
          className="h-[420px] sm:h-[460px] overflow-y-auto p-4 sm:p-5 space-y-4 bg-slate-50/50 dark:bg-slate-950/30"
          role="log"
          aria-live="polite"
        >
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 flex items-center justify-center">
                <Bot className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                  Start a conversation with {activeRole.label}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  {activeRole.subtitle}. Tap Speak to dictate in {activeVoiceLanguage.apiLanguage}, or click a prompt below.
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-2 pt-1">
                {activeRole.starterPrompts.map((sample) => (
                  <button
                    key={sample}
                    type="button"
                    onClick={() => void sendMessage(sample)}
                    className="text-left px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-emerald-600 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors"
                  >
                    {sample}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isUser = msg.role === 'user';
              const roleMeta = CHATBOT_ROLES.find((r) => r.id === msg.roleId);
              const isPlaying = speakingMsgId === msg.id;
              const isVoiceLoading = ttsLoadingMsgId === msg.id;
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`rounded-2xl px-4 py-3 max-w-[85%] sm:max-w-[75%] space-y-2 ${
                      isUser
                        ? 'bg-emerald-700 text-white rounded-br-sm'
                        : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 text-[11px] opacity-80">
                      <span className="font-medium">
                        {isUser ? 'You' : roleMeta?.label || 'Gram Sahayak'}
                      </span>
                      <span className="font-mono tabular-nums">{msg.timestamp}</span>
                    </div>

                    <p className="text-sm leading-relaxed whitespace-pre-line">{msg.text}</p>

                    {!isUser && (
                      <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100 dark:border-slate-800 flex-wrap">
                        <span className="font-mono text-[10px] text-slate-400">
                          {msg.modelUsed || 'gemini-4-hydrogen'}
                        </span>
                        <div className="flex items-center gap-1.5">
                          {isVoiceLoading ? (
                            <button
                              type="button"
                              onClick={stopSpeaking}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-emerald-700 dark:text-emerald-400"
                            >
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              Loading voice...
                            </button>
                          ) : isPlaying ? (
                            <button
                              type="button"
                              onClick={stopSpeaking}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-amber-600 dark:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                            >
                              <VolumeX className="w-3.5 h-3.5" />
                              Stop
                            </button>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => speakMessage(msg.id, msg.text, 'female')}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-emerald-700 dark:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                                Female
                              </button>
                              <button
                                type="button"
                                onClick={() => speakMessage(msg.id, msg.text, 'male')}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                                Male
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })
          )}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="px-4 py-3 rounded-2xl rounded-bl-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 inline-flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                {activeRole.label} is typing...
              </div>
            </div>
          )}

          <div ref={threadEndRef} />
        </div>

        {/* Starter Prompts Strip when active */}
        {messages.length > 0 && (
          <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2 overflow-x-auto">
            <span className="text-[11px] text-slate-400 shrink-0">Quick ask:</span>
            {activeRole.starterPrompts.map((sample) => (
              <button
                key={sample}
                type="button"
                disabled={loading}
                onClick={() => void sendMessage(sample)}
                className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-300 hover:border-emerald-600 whitespace-nowrap shrink-0"
              >
                {sample}
              </button>
            ))}
          </div>
        )}

        {displayError && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3">
            <span className="flex-1">{displayError}</span>
            {errorMsg && messages[messages.length - 1]?.role === 'user' && (
              <button
                type="button"
                disabled={loading}
                onClick={() => void retryLastMessage()}
                className="px-3 py-1.5 rounded-lg bg-rose-700 text-white font-medium hover:bg-rose-800 whitespace-nowrap shrink-0"
              >
                Retry
              </button>
            )}
          </div>
        )}

        {/* Composer */}
        <form
          onSubmit={handleSubmit}
          className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2"
        >
          <button
            type="button"
            onClick={() => void toggleRecording()}
            disabled={loading || isTranscribing}
            className={`min-h-[44px] min-w-[44px] px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs font-medium transition-colors ${
              isListening
                ? 'bg-rose-600 text-white hover:bg-rose-700'
                : isTranscribing
                  ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            aria-label={isListening ? 'Stop voice recording' : 'Speak your question'}
          >
            {isTranscribing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : isListening ? (
              <MicOff className="w-4 h-4" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">
              {isTranscribing ? 'Transcribing...' : isListening ? 'Stop' : 'Speak'}
            </span>
          </button>

          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Ask any question in ${activeVoiceLanguage.apiLanguage}...`}
            className="flex-1 min-h-[44px] px-3 bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
          />

          <button
            type="submit"
            disabled={isTranscribing || !query.trim()}
            className="min-h-[44px] px-5 rounded-xl bg-emerald-700 text-white text-sm font-medium hover:bg-emerald-800 disabled:opacity-50 inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            {loading && !query.trim() ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Send
          </button>
        </form>
      </div>
    </div>
  );
};
