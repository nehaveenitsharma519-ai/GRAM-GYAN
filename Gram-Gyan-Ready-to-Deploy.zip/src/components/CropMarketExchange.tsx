import React, { useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Calculator,
  Calendar,
  ExternalLink,
  Minus,
  Search,
  Sprout,
  Star,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { CROP_CATEGORIES, INDIAN_CROPS_MARKET } from '../data/indianCropsMarket';
import { getCropAgronomyInfo, INDIAN_SEEDS_CATALOGUE } from '../data/indianSeedsData';
import { CropCategory, CropStockItem, SeedCatalogueItem, SeedSeason } from '../types/gramGyan';

const WATCHLIST_STORAGE_KEY = 'gg_crop_watchlist_v1';

function readStoredWatchlist(): string[] {
  try {
    const raw = localStorage.getItem(WATCHLIST_STORAGE_KEY);
    if (!raw) return ['crp-rajmash', 'crp-apple', 'crp-wheat', 'crp-tomato'];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : ['crp-rajmash', 'crp-apple', 'crp-wheat'];
  } catch {
    return ['crp-rajmash', 'crp-apple', 'crp-wheat', 'crp-tomato'];
  }
}

function getChangeStats(crop: CropStockItem) {
  const diff = crop.currentPrice - crop.previousPrice;
  const pct = crop.previousPrice > 0 ? (diff / crop.previousPrice) * 100 : 0;
  const weekStart = crop.weeklySeries[0]?.price ?? crop.previousPrice;
  const weekDiff = crop.currentPrice - weekStart;
  const weekPct = weekStart > 0 ? (weekDiff / weekStart) * 100 : 0;
  const direction: 'up' | 'down' | 'flat' = diff > 0 ? 'up' : diff < 0 ? 'down' : 'flat';
  return { diff, pct, weekDiff, weekPct, direction };
}

function estimateSeedCost(seed: SeedCatalogueItem, acres: number): { market: number; subsidised: number | null; unitLabel: string } {
  const safeAcres = Math.max(0.5, acres);
  if (seed.priceUnit === '₹ / 10g Packet') {
    const packetsPerAcre = seed.id === 'seed-cotton-rch659' ? 2 : seed.id === 'seed-tomato-arka' ? 6 : seed.id === 'seed-chilli-teja' ? 9 : 18;
    const totalPkts = Math.ceil(packetsPerAcre * safeAcres);
    return {
      market: totalPkts * seed.marketPrice,
      subsidised: seed.subsidisedPrice ? totalPkts * seed.subsidisedPrice : null,
      unitLabel: `${totalPkts} pkts`,
    };
  }
  if (seed.priceUnit === '₹ / Quintal') {
    const qtls = Math.round((seed.seedRatePerAcreKg / 100) * safeAcres);
    return {
      market: qtls * seed.marketPrice,
      subsidised: seed.subsidisedPrice ? qtls * seed.subsidisedPrice : null,
      unitLabel: `${qtls} qtls`,
    };
  }
  if (seed.priceUnit === '₹ / Sapling') {
    const count = Math.round(seed.seedRatePerAcreKg * safeAcres);
    return {
      market: count * seed.marketPrice,
      subsidised: seed.subsidisedPrice ? count * seed.subsidisedPrice : null,
      unitLabel: `${count} plants`,
    };
  }
  const totalKg = Math.round(seed.seedRatePerAcreKg * safeAcres * 10) / 10;
  return {
    market: Math.round(totalKg * seed.marketPrice),
    subsidised: seed.subsidisedPrice ? Math.round(totalKg * seed.subsidisedPrice) : null,
    unitLabel: `${totalKg} kg`,
  };
}

const MiniSparkline: React.FC<{ series: { price: number }[]; direction: 'up' | 'down' | 'flat' }> = ({
  series,
  direction,
}) => {
  const values = series.map((s) => s.price);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const width = 68;
  const height = 22;
  const points = values
    .map((v, i) => {
      const x = (i / Math.max(1, values.length - 1)) * width;
      const y = height - ((v - min) / range) * (height - 4) - 2;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const stroke = direction === 'down' ? '#e11d48' : direction === 'up' ? '#059669' : '#64748b';

  return (
    <svg width={width} height={height} className="overflow-visible inline-block shrink-0" aria-hidden="true">
      <polyline fill="none" stroke={stroke} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" points={points} />
    </svg>
  );
};

export const CropMarketExchange: React.FC = () => {
  const [activeBoard, setActiveBoard] = useState<'crops' | 'seeds'>('crops');

  // Crop Stock Exchange state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | CropCategory>('All');
  const [selectedState, setSelectedState] = useState<string>('All India');
  const [trendFilter, setTrendFilter] = useState<'all' | 'up' | 'down' | 'watchlist'>('all');
  const [sortBy, setSortBy] = useState<'gainers' | 'losers' | 'price' | 'name'>('gainers');
  const [watchlistIds, setWatchlistIds] = useState<string[]>(readStoredWatchlist);
  const [selectedCropId, setSelectedCropId] = useState<string>(INDIAN_CROPS_MARKET[0].id);
  const [lotUnits, setLotUnits] = useState<number>(10);

  // Certified Seeds Directory state
  const [seedSearchQuery, setSeedSearchQuery] = useState('');
  const [seedCategory, setSeedCategory] = useState<'All' | CropCategory>('All');
  const [seedSeason, setSeedSeason] = useState<'All' | SeedSeason>('All');
  const [farmAcres, setFarmAcres] = useState<number>(2);

  const states = useMemo(() => {
    const uniq = Array.from(new Set(INDIAN_CROPS_MARKET.map((c) => c.state))).sort();
    return ['All India', ...uniq];
  }, []);

  const enrichedCrops = useMemo(
    () => INDIAN_CROPS_MARKET.map((c) => ({ ...c, ...getChangeStats(c) })),
    []
  );

  const marketSummary = useMemo(() => {
    const gainers = enrichedCrops.filter((c) => c.direction === 'up');
    const decliners = enrichedCrops.filter((c) => c.direction === 'down');
    const topGainers = [...gainers].sort((a, b) => b.pct - a.pct).slice(0, 3);
    const topLosers = [...decliners].sort((a, b) => a.pct - b.pct).slice(0, 3);
    return {
      total: enrichedCrops.length,
      upCount: gainers.length,
      downCount: decliners.length,
      flatCount: enrichedCrops.length - gainers.length - decliners.length,
      topGainers,
      topLosers,
    };
  }, [enrichedCrops]);

  const filteredCrops = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = enrichedCrops.filter((crop) => {
      if (selectedCategory !== 'All' && crop.category !== selectedCategory) return false;
      if (selectedState !== 'All India' && crop.state !== selectedState) return false;
      if (trendFilter === 'up' && crop.direction !== 'up') return false;
      if (trendFilter === 'down' && crop.direction !== 'down') return false;
      if (trendFilter === 'watchlist' && !watchlistIds.includes(crop.id)) return false;
      if (q) {
        const hay = `${crop.name} ${crop.localName} ${crop.symbol} ${crop.variety} ${crop.primaryMandi} ${crop.state}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    return list.sort((a, b) => {
      if (sortBy === 'gainers') return b.pct - a.pct;
      if (sortBy === 'losers') return a.pct - b.pct;
      if (sortBy === 'price') return b.currentPrice - a.currentPrice;
      return a.name.localeCompare(b.name);
    });
  }, [enrichedCrops, searchQuery, selectedCategory, selectedState, trendFilter, watchlistIds, sortBy]);

  const selectedCrop =
    enrichedCrops.find((c) => c.id === selectedCropId) ?? filteredCrops[0] ?? enrichedCrops[0];

  const selectedCropAgronomy = useMemo(() => getCropAgronomyInfo(selectedCrop), [selectedCrop]);

  const filteredSeeds = useMemo(() => {
    const q = seedSearchQuery.trim().toLowerCase();
    return INDIAN_SEEDS_CATALOGUE.filter((seed) => {
      if (seedCategory !== 'All' && seed.category !== seedCategory) return false;
      if (seedSeason !== 'All' && seed.season !== seedSeason) return false;
      if (!q) return true;
      const hay = `${seed.seedName} ${seed.cropName} ${seed.hindiName} ${seed.suitableRegions} ${seed.seedType} ${seed.category}`.toLowerCase();
      return hay.includes(q);
    });
  }, [seedSearchQuery, seedCategory, seedSeason]);

  const toggleWatchlist = (id: string) => {
    setWatchlistIds((prev) => {
      const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem(WATCHLIST_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore storage errors
      }
      return next;
    });
  };

  const openSeedBankForCrop = (crop: CropStockItem) => {
    const keyword = crop.name.split('(')[0].split('/')[0].trim();
    setSeedCategory(crop.category);
    setSeedSeason('All');
    setSeedSearchQuery(keyword);
    setActiveBoard('seeds');
  };

  const estimatedValue = Math.round(selectedCrop.currentPrice * Math.max(0, lotUnits));
  const estimatedDelta = Math.round(selectedCrop.diff * Math.max(0, lotUnits));

  return (
    <div className="space-y-6">
      {/* Primary Mode Switcher: Crop Stock Market vs Certified Seeds Catalogue */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveBoard('crops')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-medium inline-flex items-center gap-2 transition-colors ${
              activeBoard === 'crops'
                ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            All-India Crops &amp; Market Rates ({INDIAN_CROPS_MARKET.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveBoard('seeds')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-medium inline-flex items-center gap-2 transition-colors ${
              activeBoard === 'seeds'
                ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            <Sprout className="w-4 h-4" />
            Certified Seeds Price &amp; Sowing Guide ({INDIAN_SEEDS_CATALOGUE.length})
          </button>
        </div>

        <div className="flex items-center gap-3 text-xs px-1">
          <a
            href="https://sathi.dac.gov.in"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
          >
            SATHI Seeds <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="https://www.indiaseeds.com"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
          >
            NSC India <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="https://agmarknet.gov.in"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
          >
            AGMARKNET <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {activeBoard === 'crops' ? (
        <>
          {/* Market Overview KPIs & Direction Shortcuts */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <button
              type="button"
              onClick={() => setTrendFilter('all')}
              className={`p-4 rounded-2xl border text-left transition-colors ${
                trendFilter === 'all'
                  ? 'border-emerald-700 bg-emerald-50/70 dark:bg-emerald-950/30 dark:border-emerald-500'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
              }`}
            >
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">All-India Crop Index</div>
              <div className="font-display font-bold text-2xl text-slate-900 dark:text-slate-100 mt-1 tabular-nums">
                {marketSummary.total} Crops
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">{CROP_CATEGORIES.length} categories · Pan-India APMC</div>
            </button>

            <button
              type="button"
              onClick={() => setTrendFilter('up')}
              className={`p-4 rounded-2xl border text-left transition-colors ${
                trendFilter === 'up'
                  ? 'border-emerald-700 bg-emerald-50/80 dark:bg-emerald-950/40 dark:border-emerald-500'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-400'
              }`}
            >
              <div className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> Prices Increasing
              </div>
              <div className="font-display font-bold text-2xl text-emerald-700 dark:text-emerald-400 mt-1 tabular-nums">
                {marketSummary.upCount} Rising
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Tap to view gainers</div>
            </button>

            <button
              type="button"
              onClick={() => setTrendFilter('down')}
              className={`p-4 rounded-2xl border text-left transition-colors ${
                trendFilter === 'down'
                  ? 'border-rose-600 bg-rose-50/80 dark:bg-rose-950/40 dark:border-rose-500'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-rose-400'
              }`}
            >
              <div className="text-[11px] font-medium text-rose-600 dark:text-rose-400 flex items-center gap-1">
                <TrendingDown className="w-3.5 h-3.5" /> Prices Decreasing
              </div>
              <div className="font-display font-bold text-2xl text-rose-600 dark:text-rose-400 mt-1 tabular-nums">
                {marketSummary.downCount} Falling
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Tap to view decliners</div>
            </button>

            <button
              type="button"
              onClick={() => setTrendFilter('watchlist')}
              className={`p-4 rounded-2xl border text-left transition-colors ${
                trendFilter === 'watchlist'
                  ? 'border-amber-600 bg-amber-50/80 dark:bg-amber-950/40 dark:border-amber-500'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-amber-400'
              }`}
            >
              <div className="text-[11px] font-medium text-amber-700 dark:text-amber-400 flex items-center gap-1">
                <Star className="w-3.5 h-3.5" /> My Crop Watchlist
              </div>
              <div className="font-display font-bold text-2xl text-slate-900 dark:text-slate-100 mt-1 tabular-nums">
                {watchlistIds.length} Saved
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Track your farm harvest</div>
            </button>
          </div>

          {/* Top Gainers vs Top Decliners Ticker Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 inline-flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4" /> Top Increasing Crops Today (Gainers)
                </span>
                <span className="text-[11px] font-mono text-slate-400">24h Move</span>
              </div>
              <div className="space-y-2">
                {marketSummary.topGainers.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedCropId(item.id)}
                    className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/25 hover:bg-emerald-100/70 dark:hover:bg-emerald-950/50 flex items-center justify-between gap-2 text-left transition-colors"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {item.symbol} · {item.primaryMandi}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono text-xs font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                        ₹{item.currentPrice.toLocaleString('en-IN')}
                      </div>
                      <div className="font-mono text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 inline-flex items-center gap-0.5 tabular-nums">
                        <ArrowUpRight className="w-3 h-3" />+{item.pct.toFixed(1)}% (+₹{item.diff})
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-rose-600 dark:text-rose-400 inline-flex items-center gap-1.5">
                  <TrendingDown className="w-4 h-4" /> Top Decreasing Crops Today (Decliners)
                </span>
                <span className="text-[11px] font-mono text-slate-400">24h Move</span>
              </div>
              <div className="space-y-2">
                {marketSummary.topLosers.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedCropId(item.id)}
                    className="w-full px-3 py-2 rounded-xl bg-rose-50/60 dark:bg-rose-950/25 hover:bg-rose-100/70 dark:hover:bg-rose-950/50 flex items-center justify-between gap-2 text-left transition-colors"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {item.symbol} · {item.primaryMandi}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono text-xs font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                        ₹{item.currentPrice.toLocaleString('en-IN')}
                      </div>
                      <div className="font-mono text-[11px] font-semibold text-rose-600 dark:text-rose-400 inline-flex items-center gap-0.5 tabular-nums">
                        <ArrowDownRight className="w-3 h-3" />
                        {item.pct.toFixed(1)}% (₹{item.diff})
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Crop Stock Chart, Agronomy & Seed Info + Harvest Calculator Panel */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                    {selectedCrop.symbol}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    {selectedCrop.category} · {selectedCrop.state} · {selectedCropAgronomy.season}
                  </span>
                </div>
                <h3 className="font-display font-bold text-xl text-slate-900 dark:text-slate-100">
                  {selectedCrop.name}{' '}
                  <span className="text-sm font-normal text-slate-500 dark:text-slate-400">
                    ({selectedCrop.localName})
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Benchmark Hub: {selectedCrop.primaryMandi} · Market Grade: {selectedCrop.variety}
                </p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="font-mono font-bold text-2xl text-slate-900 dark:text-slate-100 tabular-nums">
                    ₹{selectedCrop.currentPrice.toLocaleString('en-IN')}
                    <span className="text-xs font-normal text-slate-500 ml-1">
                      /{selectedCrop.unit.replace('₹ / ', '')}
                    </span>
                  </div>
                  <div
                    className={`font-mono text-xs font-semibold inline-flex items-center gap-1 tabular-nums ${
                      selectedCrop.direction === 'up'
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : selectedCrop.direction === 'down'
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-slate-500'
                    }`}
                  >
                    {selectedCrop.direction === 'up' && <ArrowUpRight className="w-3.5 h-3.5" />}
                    {selectedCrop.direction === 'down' && <ArrowDownRight className="w-3.5 h-3.5" />}
                    {selectedCrop.direction === 'flat' && <Minus className="w-3.5 h-3.5" />}
                    24h: {selectedCrop.diff >= 0 ? '+' : ''}
                    ₹{selectedCrop.diff} ({selectedCrop.pct >= 0 ? '+' : ''}
                    {selectedCrop.pct.toFixed(1)}%) · 7d: {selectedCrop.weekPct >= 0 ? '+' : ''}
                    {selectedCrop.weekPct.toFixed(1)}%
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => toggleWatchlist(selectedCrop.id)}
                  aria-label="Toggle crop watchlist"
                  className={`p-2.5 rounded-xl border transition-colors ${
                    watchlistIds.includes(selectedCrop.id)
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-600'
                      : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-amber-500'
                  }`}
                >
                  <Star
                    className="w-4 h-4"
                    fill={watchlistIds.includes(selectedCrop.id) ? 'currentColor' : 'none'}
                  />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 items-center">
              <div className="lg:col-span-2 h-[220px] min-w-0">
                <ResponsiveContainer width="100%" height={220} minWidth={0}>
                  <AreaChart
                    data={selectedCrop.weeklySeries}
                    margin={{ top: 10, right: 12, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="cropTrendFill" x1="0" y1="0" x2="0" y2="1">
                        <stop
                          offset="5%"
                          stopColor={selectedCrop.direction === 'down' ? '#e11d48' : '#059669'}
                          stopOpacity={0.28}
                        />
                        <stop
                          offset="95%"
                          stopColor={selectedCrop.direction === 'down' ? '#e11d48' : '#059669'}
                          stopOpacity={0.02}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" opacity={0.35} />
                    <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                    <YAxis
                      domain={['auto', 'auto']}
                      tick={{ fontSize: 11 }}
                      width={56}
                      tickFormatter={(v) => `₹${Number(v).toLocaleString('en-IN')}`}
                    />
                    <Tooltip
                      formatter={(value) => [`₹${Number(value ?? 0).toLocaleString('en-IN')}`, 'Modal Price']}
                    />
                    <Area
                      type="monotone"
                      dataKey="price"
                      stroke={selectedCrop.direction === 'down' ? '#e11d48' : '#059669'}
                      strokeWidth={2.5}
                      fill="url(#cropTrendFill)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-xs">
                <div className="space-y-1">
                  <div className="font-semibold text-slate-800 dark:text-slate-100">Market Driver</div>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {selectedCrop.demandNote}
                  </p>
                </div>
                <div className="space-y-1">
                  <div className="font-semibold text-emerald-700 dark:text-emerald-400">Farmer Action Tip</div>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {selectedCrop.farmerAction}
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-medium text-slate-700 dark:text-slate-200">
                    <span className="inline-flex items-center gap-1">
                      <Calculator className="w-3.5 h-3.5 text-emerald-700" />
                      Harvest Lot Calculator
                    </span>
                    <span>
                      {selectedCrop.mspPrice
                        ? `MSP: ₹${selectedCrop.mspPrice.toLocaleString('en-IN')}`
                        : 'Market-Priced Crop'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={10000}
                      value={lotUnits}
                      onChange={(e) => setLotUnits(Math.max(0, Number(e.target.value)))}
                      aria-label="Harvest quantity"
                      className="w-20 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
                    />
                    <span className="text-[11px] text-slate-500">
                      × {selectedCrop.unit.replace('₹ / ', '')}
                    </span>
                    <div className="ml-auto text-right">
                      <div className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100 tabular-nums">
                        ₹{estimatedValue.toLocaleString('en-IN')}
                      </div>
                      <div
                        className={`font-mono text-[10px] tabular-nums ${
                          estimatedDelta >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-600'
                        }`}
                      >
                        {estimatedDelta >= 0 ? '+' : ''}₹{estimatedDelta.toLocaleString('en-IN')} vs yest
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Selected Crop Agronomy & Recommended Seed Information */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 inline-flex items-center gap-1.5">
                  <Sprout className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                  Crop Cultivation &amp; Recommended Seed Profile — {selectedCrop.name}
                </div>
                <button
                  type="button"
                  onClick={() => openSeedBankForCrop(selectedCrop)}
                  className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline inline-flex items-center gap-1"
                >
                  Open in Certified Seeds Directory <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/50 space-y-1">
                  <div className="text-[11px] text-slate-500">Sowing Season &amp; Window</div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{selectedCropAgronomy.season}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400">{selectedCropAgronomy.sowingWindow}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/50 space-y-1">
                  <div className="text-[11px] text-slate-500">Certified Seed Rate &amp; Price</div>
                  <div className="font-semibold text-emerald-700 dark:text-emerald-400">{selectedCropAgronomy.seedRatePerAcre}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400">{selectedCropAgronomy.seedPriceRange}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/50 space-y-1">
                  <div className="text-[11px] text-slate-500">Duration &amp; Soil Type</div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{selectedCropAgronomy.harvestDuration}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400">{selectedCropAgronomy.soilType}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/50 space-y-1">
                  <div className="text-[11px] text-slate-500">Top Seed Varieties &amp; Field Care</div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    {selectedCropAgronomy.recommendedSeeds.join(', ')}
                  </div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400">{selectedCropAgronomy.irrigationAndCare}</div>
                </div>
              </div>
            </div>
          </div>

          {/* All-India Crop Stock Exchange Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                    All-India Crop Market Prices &amp; Live Trend Exchange ({filteredCrops.length} of {INDIAN_CROPS_MARKET.length})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Click any crop row to view its 7-day trend chart, MSP comparison, seed rates &amp; harvest calculator.
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <a
                    href="https://enam.gov.in"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
                  >
                    e-NAM <ExternalLink className="w-3 h-3" />
                  </a>
                  <a
                    href="https://www.ncdex.com"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
                  >
                    NCDEX <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Search, State & Sort Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <label className="relative flex items-center">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search any Indian crop, Hindi name, or mandi..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </label>

                <select
                  aria-label="Filter by State"
                  value={selectedState}
                  onChange={(e) => setSelectedState(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs"
                >
                  {states.map((st) => (
                    <option key={st} value={st}>
                      State: {st}
                    </option>
                  ))}
                </select>

                <select
                  aria-label="Sort crop exchange table"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs"
                >
                  <option value="gainers">Sort: Price Increasing Most (%)</option>
                  <option value="losers">Sort: Price Decreasing Most (%)</option>
                  <option value="price">Sort: Highest Modal Rate (₹)</option>
                  <option value="name">Sort: Crop Name (A–Z)</option>
                </select>
              </div>

              {/* Category Filter Strip */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {(['All', ...CROP_CATEGORIES] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
                      selectedCategory === cat
                        ? 'bg-emerald-700 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400">
                  <tr>
                    <th className="py-3 px-3 font-medium w-9" aria-label="Watchlist" />
                    <th className="py-3 px-3 font-medium">Crop &amp; Symbol</th>
                    <th className="py-3 px-3 font-medium">Primary Mandi / State</th>
                    <th className="py-3 px-3 font-medium text-right">Range (Min–Max)</th>
                    <th className="py-3 px-3 font-medium text-right">Modal Rate</th>
                    <th className="py-3 px-3 font-medium text-right">MSP 25-26</th>
                    <th className="py-3 px-3 font-medium text-center">7d Graph</th>
                    <th className="py-3 px-3 font-medium text-right">Price Direction (24h)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredCrops.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-xs text-slate-500">
                        No crops match your current filters. Clear search or switch category to view all crops.
                      </td>
                    </tr>
                  ) : (
                    filteredCrops.map((crop) => {
                      const isSelected = crop.id === selectedCrop.id;
                      const isWatched = watchlistIds.includes(crop.id);
                      return (
                        <tr
                          key={crop.id}
                          onClick={() => setSelectedCropId(crop.id)}
                          className={`cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-emerald-50/70 dark:bg-emerald-950/30'
                              : 'hover:bg-slate-50/80 dark:hover:bg-slate-800/40'
                          }`}
                        >
                          <td className="py-3 px-3">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleWatchlist(crop.id);
                              }}
                              aria-label={`Bookmark ${crop.name}`}
                              className={
                                isWatched
                                  ? 'text-amber-500'
                                  : 'text-slate-300 dark:text-slate-600 hover:text-amber-500'
                              }
                            >
                              <Star className="w-4 h-4" fill={isWatched ? 'currentColor' : 'none'} />
                            </button>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-medium text-slate-900 dark:text-slate-100">
                              {crop.name}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                              <span className="font-mono font-semibold text-slate-600 dark:text-slate-300">
                                {crop.symbol}
                              </span>
                              <span>· {crop.localName}</span>
                            </div>
                          </td>
                          <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                            <div>{crop.primaryMandi}</div>
                            <div className="text-[11px] text-slate-400">{crop.state}</div>
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-xs text-slate-500 tabular-nums whitespace-nowrap">
                            ₹{crop.minPrice.toLocaleString('en-IN')} – ₹{crop.maxPrice.toLocaleString('en-IN')}
                          </td>
                          <td className="py-3 px-3 text-right font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums whitespace-nowrap">
                            ₹{crop.currentPrice.toLocaleString('en-IN')}
                            <span className="block text-[10px] font-normal text-slate-400">{crop.unit}</span>
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-xs tabular-nums whitespace-nowrap">
                            {crop.mspPrice ? `₹${crop.mspPrice.toLocaleString('en-IN')}` : 'Market'}
                          </td>
                          <td className="py-3 px-3 text-center">
                            <MiniSparkline series={crop.weeklySeries} direction={crop.direction} />
                          </td>
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-mono text-[11px] font-semibold tabular-nums ${
                                crop.direction === 'up'
                                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                                  : crop.direction === 'down'
                                    ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                              }`}
                            >
                              {crop.direction === 'up' && <ArrowUpRight className="w-3 h-3" />}
                              {crop.direction === 'down' && <ArrowDownRight className="w-3 h-3" />}
                              {crop.pct >= 0 ? '+' : ''}
                              {crop.pct.toFixed(1)}%
                              <span className="font-sans text-[10px] font-medium ml-0.5">
                                {crop.direction === 'up'
                                  ? 'Increasing'
                                  : crop.direction === 'down'
                                    ? 'Decreasing'
                                    : 'Steady'}
                              </span>
                            </span>
                            <div className="font-mono text-[10px] text-slate-400 mt-0.5 tabular-nums">
                              {crop.diff >= 0 ? '+' : ''}₹{crop.diff} vs yest
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* TAB 2: CERTIFIED SEEDS CATALOGUE, SUBSIDISED PRICES & SOWING INFORMATION */
        <div className="space-y-5">
          {/* Search, Season, Category & Acreage Seed Cost Estimator */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="space-y-1">
                <h3 className="font-display font-bold text-lg text-slate-900 dark:text-slate-100">
                  Certified Seeds Catalogue — Market &amp; Govt. Subsidised Rates
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                  Compare HYV, Hybrid (F1), Hill/GI heirloom, and tuber/sapling seed prices, seed rates per acre, maturity days, and NFSM/SMSP subsidy rates. Verify lot tags via{' '}
                  <a
                    href="https://sathi.dac.gov.in"
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-700 dark:text-emerald-400 font-medium hover:underline"
                  >
                    SATHI Portal
                  </a>{' '}
                  before sowing.
                </p>
              </div>

              <div className="flex items-center gap-2.5 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 rounded-xl px-3.5 py-2 text-xs">
                <Calculator className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                <span className="font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap">
                  Estimate Cost for:
                </span>
                <input
                  type="number"
                  min={0.5}
                  max={100}
                  step={0.5}
                  value={farmAcres}
                  onChange={(e) => setFarmAcres(Math.max(0.5, Number(e.target.value)))}
                  aria-label="Farm area in acres"
                  className="w-16 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs text-center font-semibold"
                />
                <span className="text-slate-600 dark:text-slate-300 font-medium">Acres</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              <label className="relative flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3" />
                <input
                  type="text"
                  value={seedSearchQuery}
                  onChange={(e) => setSeedSearchQuery(e.target.value)}
                  placeholder="Search variety (HD-3086, Pusa, Shalimar, Kufri, Berseem)..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </label>

              <select
                aria-label="Filter seeds by season"
                value={seedSeason}
                onChange={(e) => setSeedSeason(e.target.value as typeof seedSeason)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs"
              >
                <option value="All">Season: All Sowing Seasons</option>
                <option value="Rabi">Rabi (Oct–Dec Winter Sowing)</option>
                <option value="Kharif">Kharif (Jun–Jul Monsoon Sowing)</option>
                <option value="Zaid">Zaid (Feb–May Summer Catch Crop)</option>
                <option value="Perennial">Perennial / Orchard / Corms</option>
              </select>

              <select
                aria-label="Filter seeds by category"
                value={seedCategory}
                onChange={(e) => setSeedCategory(e.target.value as typeof seedCategory)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs"
              >
                <option value="All">Category: All 8 Crop Groups</option>
                {CROP_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Seed Catalogue Cards */}
          {filteredSeeds.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-2">
              <Sprout className="w-8 h-8 mx-auto text-slate-400" />
              <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                No seed varieties matched your filter.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSeedSearchQuery('');
                  setSeedCategory('All');
                  setSeedSeason('All');
                }}
                className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
              >
                Reset all seed filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filteredSeeds.map((seed) => {
                const cost = estimateSeedCost(seed, farmAcres);
                return (
                  <div
                    key={seed.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                            <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-medium inline-flex items-center gap-1">
                              <Calendar className="w-3 h-3" /> {seed.season}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
                              {seed.seedType}
                            </span>
                            <span className="text-slate-400">{seed.category}</span>
                          </div>
                          <h4 className="font-display font-bold text-base text-slate-900 dark:text-slate-100 leading-snug">
                            {seed.seedName}
                          </h4>
                          <p className="text-xs text-slate-600 dark:text-slate-400">
                            {seed.cropName} · <span className="text-slate-500">{seed.hindiName}</span>
                          </p>
                        </div>

                        <div className="text-right shrink-0">
                          <div className="font-mono font-bold text-base text-slate-900 dark:text-slate-100 tabular-nums">
                            ₹{seed.marketPrice.toLocaleString('en-IN')}
                          </div>
                          <div className="text-[10px] text-slate-500">{seed.priceUnit} (Market)</div>
                          {seed.subsidisedPrice !== null && (
                            <div className="mt-1 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-mono text-[11px] font-semibold tabular-nums">
                              Govt: ₹{seed.subsidisedPrice.toLocaleString('en-IN')}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3">
                        <div>
                          <span className="text-slate-500 block text-[11px]">Seed Rate per Acre</span>
                          <span className="font-medium text-slate-800 dark:text-slate-200">{seed.seedRateLabel}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Duration &amp; Expected Yield</span>
                          <span className="font-medium text-slate-800 dark:text-slate-200">
                            {seed.maturityDays} · {seed.expectedYieldPerAcre}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Best Regions</span>
                          <span className="text-slate-700 dark:text-slate-300">{seed.suitableRegions}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[11px]">Soil Requirement</span>
                          <span className="text-slate-700 dark:text-slate-300">{seed.soilRequirement}</span>
                        </div>
                      </div>

                      <div className="text-xs space-y-1">
                        <p className="text-slate-700 dark:text-slate-300">
                          <span className="font-semibold text-emerald-700 dark:text-emerald-400">Seed Treatment &amp; Tip: </span>
                          {seed.seedTreatment}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Where to Buy / Subsidy: {seed.procurementSource}
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="text-slate-500">
                        For <strong className="text-slate-800 dark:text-slate-200">{farmAcres} Acres</strong> ({cost.unitLabel} needed):
                      </span>
                      <div className="font-mono tabular-nums flex items-center gap-2">
                        <span className="text-slate-700 dark:text-slate-300">
                          Market ₹{cost.market.toLocaleString('en-IN')}
                        </span>
                        {cost.subsidised !== null && (
                          <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                            · Govt ₹{cost.subsidised.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
