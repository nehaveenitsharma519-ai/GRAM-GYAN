import React, { useState } from 'react';
import {
  Bookmark,
  CheckCircle2,
  Download,
  Globe2,
  HelpCircle,
  LogIn,
  LogOut,
  MailCheck,
  MapPin,
  Moon,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sun,
  Trash2,
  UserCheck,
  UserPlus,
  WifiOff,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { JK_DISTRICTS } from '../data/gramGyanData';
import { LANGUAGES } from '../data/translations';
import {
  GovernmentScheme,
  GrievanceTicket,
  LanguageCode,
  LibraryResource,
  UserLocation,
  VillageEntry,
  WeeklyReadingStat,
} from '../types/gramGyan';
import { ReadingAnalytics } from './ReadingAnalytics';

interface ProfileAndSetupViewProps {
  language: LanguageCode;
  location: UserLocation;
  darkMode: boolean;
  textScale: 'normal' | 'large' | 'xlarge';
  isOffline: boolean;
  lowDataMode: boolean;
  books: LibraryResource[];
  schemes: GovernmentScheme[];
  bookmarkedBookIds: string[];
  downloadedBookIds: string[];
  savedSchemeIds: string[];
  grievances: GrievanceTicket[];
  readingStats: WeeklyReadingStat[];
  finishedBookIds: string[];
  onLogReadingMinutes: (minutes: number) => void;
  onLanguageChange: (lang: LanguageCode) => void;
  onLocationChange: (loc: UserLocation) => void;
  onDarkModeChange: (dark: boolean) => void;
  onTextScaleChange: (scale: 'normal' | 'large' | 'xlarge') => void;
  onToggleOffline: () => void;
  onToggleLowData: () => void;
  onOpenBook: (book: LibraryResource) => void;
  onRemoveDownload: (bookId: string) => void;
  onSubmitGrievance: (category: string, message: string) => Promise<void>;
  onOpenAuth: (mode: 'login' | 'signup') => void;
  villages: VillageEntry[];
  onOpenVillageModal: (openAddForm?: boolean) => void;
  onSelectVillage: (village: VillageEntry) => void;
}

export const ProfileAndSetupView: React.FC<ProfileAndSetupViewProps> = ({
  language,
  location,
  darkMode,
  textScale,
  isOffline,
  lowDataMode,
  books,
  schemes,
  bookmarkedBookIds,
  downloadedBookIds,
  savedSchemeIds,
  grievances,
  readingStats,
  finishedBookIds,
  onLogReadingMinutes,
  onLanguageChange,
  onLocationChange,
  onDarkModeChange,
  onTextScaleChange,
  onToggleOffline,
  onToggleLowData,
  onOpenBook,
  onRemoveDownload,
  onSubmitGrievance,
  onOpenAuth,
  villages,
  onOpenVillageModal,
  onSelectVillage,
}) => {
  const { user, logout, resendVerificationEmail, refreshAuthUser, updatePrivateContact } = useAuth();
  const [grievanceCategory, setGrievanceCategory] = useState('Content Correction');
  const [grievanceMessage, setGrievanceMessage] = useState('');
  const [grievanceSaved, setGrievanceSaved] = useState(false);
  const [verifyMsg, setVerifyMsg] = useState<string | null>(null);
  const [phoneInput, setPhoneInput] = useState('');
  const [phoneSaved, setPhoneSaved] = useState(false);

  const districtInfo = JK_DISTRICTS[location.district];
  const districtNames = Array.from(
    new Set([...Object.keys(JK_DISTRICTS), ...villages.map((v) => v.district)])
  );
  const blocks = districtInfo
    ? districtInfo.blocks
    : Array.from(
        new Set([
          location.block,
          ...villages
            .filter((v) => v.district === location.district)
            .map((v) => v.blockOrTehsil),
        ].filter(Boolean))
      );
  const panchayats = districtInfo
    ? districtInfo.panchayats[location.block] ?? districtInfo.panchayats[blocks[0]] ?? [location.panchayat]
    : Array.from(
        new Set([
          location.panchayat,
          ...villages
            .filter((v) => v.district === location.district)
            .map((v) => v.name),
        ].filter(Boolean))
      );

  const downloadedBooks = books.filter((b) => downloadedBookIds.includes(b.id));
  const bookmarkedBooks = books.filter((b) => bookmarkedBookIds.includes(b.id));
  const savedSchemes = schemes.filter((s) => savedSchemeIds.includes(s.id));

  const handleGrievanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!grievanceMessage.trim()) return;
    await onSubmitGrievance(grievanceCategory, grievanceMessage.trim());
    setGrievanceMessage('');
    setGrievanceSaved(true);
    setTimeout(() => setGrievanceSaved(false), 4000);
  };

  const handleDistrictChange = (newDistrict: string) => {
    const info = JK_DISTRICTS[newDistrict];
    if (info) {
      const firstBlock = info.blocks[0];
      const firstPanchayat = info.panchayats[firstBlock]?.[0] ?? 'Main Panchayat';
      onLocationChange({
        state: 'Jammu & Kashmir',
        district: newDistrict,
        block: firstBlock,
        panchayat: firstPanchayat,
      });
      return;
    }
    const matchingVillage = villages.find((v) => v.district === newDistrict);
    if (matchingVillage) {
      onSelectVillage(matchingVillage);
    }
  };

  const handleBlockChange = (newBlock: string) => {
    const firstPanchayat = districtInfo?.panchayats[newBlock]?.[0]
      ?? villages.find((v) => v.blockOrTehsil === newBlock)?.name
      ?? location.panchayat;
    onLocationChange({
      ...location,
      block: newBlock,
      panchayat: firstPanchayat,
    });
  };

  return (
    <div className="space-y-6">
      {/* User Authentication & Account Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display font-bold text-2xl">Citizen Account & Preferences</h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              {user
                ? `Signed in as ${user.displayName || user.email} · ${user.emailVerified ? 'Verified Account (Cloud Sync Active)' : 'Email Verification Pending'}`
                : 'Currently browsing in Guest Mode. Sign up or log in to sync your bookmarks, notes, and village profile across devices.'}
            </p>
          </div>

          {user ? (
            <button
              type="button"
              onClick={() => void logout()}
              className="min-h-[44px] px-4 py-2 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-400 text-xs font-medium hover:bg-rose-50 dark:hover:bg-rose-950/40 inline-flex items-center gap-2 whitespace-nowrap"
            >
              <LogOut className="w-4 h-4" />
              Log Out
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onOpenAuth('login')}
                className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <LogIn className="w-4 h-4" />
                Log In
              </button>
              <button
                type="button"
                onClick={() => onOpenAuth('signup')}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <UserPlus className="w-4 h-4" />
                Sign Up
              </button>
            </div>
          )}
        </div>

        {user && !user.emailVerified && (
          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 space-y-2">
            <div className="font-semibold flex items-center gap-1.5">
              <MailCheck className="w-4 h-4" />
              Verify your email ({user.email}) to activate cloud sync and support ticket submission.
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={async () => {
                  await resendVerificationEmail();
                  setVerifyMsg('Verification link resent! Please check your inbox.');
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-700 text-white font-medium hover:bg-amber-800"
              >
                Resend Verification Email
              </button>
              <button
                type="button"
                onClick={async () => {
                  const ok = await refreshAuthUser();
                  setVerifyMsg(ok ? 'Email verified! Cloud sync is now active.' : 'Still awaiting verification — click the link in your email first.');
                }}
                className="px-3 py-1.5 rounded-lg border border-amber-400 font-medium inline-flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                I’ve Verified, Refresh
              </button>
            </div>
            {verifyMsg && <p className="font-medium">{verifyMsg}</p>}
          </div>
        )}

        {user && user.emailVerified && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-3 text-xs">
            <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-medium">
              <UserCheck className="w-4 h-4" />
              DPDP Privacy Protected · Isolated Private Contact
            </span>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await updatePrivateContact(phoneInput, true);
                setPhoneSaved(true);
                setTimeout(() => setPhoneSaved(false), 3000);
              }}
              className="flex items-center gap-2 ml-auto"
            >
              <input
                type="tel"
                maxLength={30}
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                placeholder="Update optional mobile (+91...)"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs"
              />
              <button
                type="submit"
                className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-700 text-white font-medium"
              >
                {phoneSaved ? 'Saved' : 'Save Contact'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Reading Analytics (Recharts Weekly Progress) */}
      <ReadingAnalytics
        stats={readingStats}
        finishedBookIds={finishedBookIds}
        isCloudSynced={Boolean(user && user.emailVerified)}
        onLogQuickSession={onLogReadingMinutes}
      />

      {/* Location & Language Setup (Screens 2 & 5) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-display font-bold text-lg flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-700" />
              Village &amp; Location Selection
            </h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onOpenVillageModal(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:border-emerald-600 inline-flex items-center gap-1"
              >
                <Globe2 className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                All Villages ({villages.length})
              </button>
              <button
                type="button"
                onClick={() => onOpenVillageModal(true)}
                className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 inline-flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Village
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">State / Region</label>
              <input
                type="text"
                readOnly
                value={location.state}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/60 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">District</label>
              <select
                value={location.district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
              >
                {districtNames.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Block / Tehsil</label>
              <select
                value={location.block}
                onChange={(e) => handleBlockChange(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
              >
                {blocks.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Panchayat / Village</label>
              <select
                value={location.panchayat}
                onChange={(e) => onLocationChange({ ...location, panchayat: e.target.value })}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
              >
                {panchayats.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Language & Accessibility Controls (Screens 2 & 24) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-display font-bold text-lg">Language, Accessibility & Data Saver</h3>

          <div className="space-y-1.5">
            <span className="text-xs font-medium text-slate-500">Preferred Language</span>
            <div className="flex flex-wrap gap-1.5">
              {LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => onLanguageChange(l.code)}
                  className={`min-h-[40px] px-3 py-1.5 rounded-xl border text-xs font-medium transition-colors ${
                    language === l.code
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {l.nativeLabel} ({l.name})
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="space-y-1.5">
              <span className="text-xs font-medium text-slate-500">Reading Text Size</span>
              <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs">
                {(['normal', 'large', 'xlarge'] as const).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => onTextScaleChange(sz)}
                    className={`flex-1 py-1.5 rounded-lg capitalize font-medium ${
                      textScale === sz ? 'bg-white dark:bg-slate-950 text-emerald-700 shadow-sm' : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {sz === 'xlarge' ? 'XL' : sz}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-medium text-slate-500">Appearance & Network</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => onDarkModeChange(!darkMode)}
                  className="flex-1 min-h-[38px] px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium inline-flex items-center justify-center gap-1.5"
                >
                  {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                  {darkMode ? 'Light' : 'Dark'}
                </button>
                <button
                  type="button"
                  onClick={onToggleOffline}
                  className={`flex-1 min-h-[38px] px-3 rounded-xl border text-xs font-medium inline-flex items-center justify-center gap-1.5 ${
                    isOffline
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <WifiOff className="w-3.5 h-3.5" />
                  {isOffline ? 'Offline' : 'Online'}
                </button>
              </div>
            </div>
          </div>

          <label className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs cursor-pointer">
            <span>Low-Data Saver Mode (hide decorative graphics, smaller book downloads)</span>
            <input
              type="checkbox"
              checked={lowDataMode}
              onChange={onToggleLowData}
              className="w-4 h-4 accent-emerald-700"
            />
          </label>
        </div>
      </div>

      {/* Offline Downloads & Saved Items (Screens 21 & 22) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-3">
          <h3 className="font-display font-bold text-lg flex items-center gap-2">
            <Download className="w-4 h-4 text-emerald-700" />
            Offline Library Downloads ({downloadedBooks.length})
          </h3>
          {downloadedBooks.length === 0 ? (
            <p className="text-xs text-slate-500">
              No books downloaded yet. Open the Digital Library and tap the download button on any book for offline reading.
            </p>
          ) : (
            <div className="space-y-2">
              {downloadedBooks.map((b) => (
                <div key={b.id} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => onOpenBook(b)}
                    className="text-left font-medium hover:text-emerald-700 truncate"
                  >
                    {b.title}
                  </button>
                  <button
                    type="button"
                    onClick={() => onRemoveDownload(b.id)}
                    aria-label={`Remove ${b.title} from offline downloads`}
                    className="p-1.5 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-3">
          <h3 className="font-display font-bold text-lg flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-emerald-700" />
            Saved Books ({bookmarkedBooks.length}) & Schemes ({savedSchemes.length})
          </h3>
          {bookmarkedBooks.length === 0 && savedSchemes.length === 0 ? (
            <p className="text-xs text-slate-500">
              Bookmark books or save government scheme guides for quick access from your Profile.
            </p>
          ) : (
            <div className="space-y-2 text-xs">
              {bookmarkedBooks.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => onOpenBook(b)}
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-left font-medium hover:border-emerald-600 block"
                >
                  Book: {b.title}
                </button>
              ))}
              {savedSchemes.map((s) => (
                <div key={s.id} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <div className="font-medium">Scheme: {s.title}</div>
                  <div className="text-slate-500 mt-0.5">{s.department}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Help Centre & Grievance Form (Screen 23) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="space-y-1">
          <h3 className="font-display font-bold text-lg flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-emerald-700" />
            Help Centre & Content Feedback
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Report an outdated notice, request a book in Dogri/Kashmiri/Urdu/Hindi, or submit a village service question.
          </p>
        </div>

        <form onSubmit={handleGrievanceSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <select
            value={grievanceCategory}
            onChange={(e) => setGrievanceCategory(e.target.value)}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
          >
            <option value="Content Correction">Content Correction / Outdated Link</option>
            <option value="Book Request">Book or Language Request</option>
            <option value="Scheme Assistance">Scheme / Document Guidance</option>
            <option value="Technical Support">Offline / Audio Technical Issue</option>
          </select>

          <input
            type="text"
            required
            maxLength={1500}
            value={grievanceMessage}
            onChange={(e) => setGrievanceMessage(e.target.value)}
            placeholder="Describe your request or feedback..."
            className="md:col-span-2 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm"
          />

          <div className="md:col-span-3 flex items-center justify-between flex-wrap gap-3">
            <span className="text-xs text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              Submissions appear in the Support Team queue ({grievances.length} logged).
            </span>
            <button
              type="submit"
              className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-700 text-white text-sm font-medium hover:bg-emerald-800"
            >
              Submit to Help Centre
            </button>
          </div>
        </form>

        {grievanceSaved && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            Thank you! Your request has been recorded for the Support Team.
          </div>
        )}
      </div>
    </div>
  );
};
