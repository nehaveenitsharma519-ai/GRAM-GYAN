import React from 'react';
import { ExternalLink, Landmark, MapPin, ShieldCheck, Users } from 'lucide-react';
import {
  JK_DISTRICTS,
  OFFICIAL_INTEGRATIONS,
  RURAL_INITIATIVES,
  YEAR_ONE_TARGETS,
} from '../data/gramGyanData';
import { UserLocation, VillageEntry } from '../types/gramGyan';
import { NewVillageDraft, VillageDirectoryPanel } from './VillageDirectoryPanel';

interface VillageCentresViewProps {
  villages: VillageEntry[];
  currentLocation: UserLocation;
  isCloudSynced: boolean;
  onSelectDistrict: (district: string) => void;
  onSelectVillage: (village: VillageEntry) => void;
  onAddVillage: (draft: NewVillageDraft, setAsActive: boolean) => Promise<void>;
  onDeleteCustomVillage: (villageId: string) => Promise<void>;
}

export const VillageCentresView: React.FC<VillageCentresViewProps> = ({
  villages,
  currentLocation,
  isCloudSynced,
  onSelectDistrict,
  onSelectVillage,
  onAddVillage,
  onDeleteCustomVillage,
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-2">
        <h2 className="font-display font-bold text-2xl">
          GRAM GYAN Digital Village Centres &amp; Global Village Directory
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Product 3: Physical digital access points at Panchayat Ghars, schools, and community libraries — anchored in Bhaderwah, Kathua, Drodhu, Doda, Baramulla &amp; expandable to any village across India and the world.
        </p>
      </div>

      {/* World & India Villages Directory + Add Village */}
      <VillageDirectoryPanel
        villages={villages}
        currentLocation={currentLocation}
        isCloudSynced={isCloudSynced}
        onSelectVillage={onSelectVillage}
        onAddVillage={onAddVillage}
        onDeleteCustomVillage={onDeleteCustomVillage}
      />

      {/* 5 Special Rural Initiatives */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {RURAL_INITIATIVES.map((item) => (
          <div
            key={item.code}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2.5"
          >
            <div className="text-xs font-mono font-semibold text-emerald-700 dark:text-emerald-400">
              Initiative {item.code}
            </div>
            <h3 className="font-display font-bold text-lg">{item.title}</h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">{item.summary}</p>
            <p className="text-xs font-medium text-slate-800 dark:text-slate-200 pt-2 border-t border-slate-100 dark:border-slate-800">
              {item.metric}
            </p>
          </div>
        ))}
      </div>

      {/* J&K Pilot Geography */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="space-y-1">
          <h3 className="font-display font-bold text-xl">Jammu &amp; Kashmir Pilot Geography</h3>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Pilot rural hubs across J&amp;K. Tap any hub to switch your app location context.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(['Bhaderwah', 'Doda', 'Baramulla'] as const).map((dist) => {
            const info = JK_DISTRICTS[dist];
            return (
              <div
                key={dist}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between gap-3"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 font-display font-semibold text-base">
                    <MapPin className="w-4 h-4 text-emerald-700" />
                    {dist} Hub
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">{info.pilotFocus}</p>
                  <p className="text-[11px] text-slate-500">
                    Blocks: {info.blocks.join(', ')}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onSelectDistrict(dist)}
                  className="min-h-[40px] px-3 py-2 rounded-xl border border-emerald-700 text-emerald-700 dark:text-emerald-400 text-xs font-medium hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                >
                  Set App Location to {dist}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Authoritative Government Integrations */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
          <Landmark className="w-4 h-4 text-emerald-700" />
          <h3 className="font-display font-semibold text-base">
            Authoritative Government & Public Data Integrations
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400">
              <tr>
                <th className="py-3 px-4 font-medium">Service Area</th>
                <th className="py-3 px-4 font-medium">Official Platform</th>
                <th className="py-3 px-4 font-medium">Role</th>
                <th className="py-3 px-4 font-medium text-right">Portal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {OFFICIAL_INTEGRATIONS.map((row) => (
                <tr key={row.source}>
                  <td className="py-3 px-4 font-medium">{row.requirement}</td>
                  <td className="py-3 px-4 text-emerald-700 dark:text-emerald-400 font-medium">{row.source}</td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{row.role}</td>
                  <td className="py-3 px-4 text-right">
                    <a
                      href={row.url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
                    >
                      Visit <ExternalLink className="w-3 h-3" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Year-One Impact Targets & Sustainability */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-display font-bold text-lg flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-700" />
            Year-One Impact Targets
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {YEAR_ONE_TARGETS.map((t) => (
              <div key={t.label} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="text-xl font-display font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                  {t.target}
                </div>
                <div className="text-xs font-medium mt-0.5">{t.label}</div>
                <div className="text-[11px] text-slate-500">{t.unit}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-3">
          <h3 className="font-display font-bold text-lg flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            Privacy, Security & Sustainability Principles
          </h3>
          <ul className="space-y-2 text-xs sm:text-sm text-slate-600 dark:text-slate-400 list-disc pl-4">
            <li>Essential citizen knowledge and scheme discovery remain 100% free with zero ads or user data sales.</li>
            <li>Aligned with India’s Digital Personal Data Protection (DPDP) Act 2023 & Rules 2025—minimal data collection and clear consent withdrawal.</li>
            <li>Never collects Aadhaar numbers, bank credentials, OTPs, or private health records.</li>
            <li>12-month phased implementation across Research, Prototype, Core Modules, AI/Voice, J&K Pilot, and Statewide Launch.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
