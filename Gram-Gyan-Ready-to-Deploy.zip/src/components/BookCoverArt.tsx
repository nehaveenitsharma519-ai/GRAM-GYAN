import React from 'react';
import { LibraryResource } from '../types/gramGyan';

interface BookCoverArtProps {
  book: LibraryResource;
  compact?: boolean;
}

const TONE_MAP: Record<LibraryResource['coverTone'], { bg: string; accent: string; ink: string; border: string }> = {
  forest: {
    bg: 'from-emerald-800 via-emerald-900 to-slate-900',
    accent: '#86efac',
    ink: 'text-emerald-50',
    border: 'border-emerald-700/50',
  },
  saffron: {
    bg: 'from-amber-700 via-orange-800 to-stone-900',
    accent: '#fde68a',
    ink: 'text-amber-50',
    border: 'border-amber-600/50',
  },
  slate: {
    bg: 'from-slate-800 via-slate-900 to-zinc-950',
    accent: '#93c5fd',
    ink: 'text-slate-50',
    border: 'border-slate-700/60',
  },
  sky: {
    bg: 'from-sky-800 via-cyan-900 to-slate-900',
    accent: '#bae6fd',
    ink: 'text-sky-50',
    border: 'border-sky-700/50',
  },
  amber: {
    bg: 'from-yellow-700 via-amber-800 to-stone-900',
    accent: '#fef08a',
    ink: 'text-amber-50',
    border: 'border-yellow-600/50',
  },
  rose: {
    bg: 'from-rose-800 via-rose-900 to-stone-950',
    accent: '#fecdd3',
    ink: 'text-rose-50',
    border: 'border-rose-700/50',
  },
};

export const BookCoverArt: React.FC<BookCoverArtProps> = ({ book, compact = false }) => {
  const tone = TONE_MAP[book.coverTone] ?? TONE_MAP.forest;

  return (
    <div
      className={`relative overflow-hidden rounded-xl bg-gradient-to-br ${tone.bg} ${tone.ink} border ${tone.border} ${
        compact ? 'h-36 p-3.5' : 'h-48 p-4'
      } flex flex-col justify-between select-none`}
      aria-hidden="true"
    >
      {/* Subtle geometric mountain & chinar motif */}
      <svg
        viewBox="0 0 240 160"
        className="absolute inset-0 h-full w-full opacity-20 pointer-events-none"
        preserveAspectRatio="none"
      >
        <path
          d="M0 135 L48 82 L88 112 L138 56 L195 108 L240 78 L240 160 L0 160 Z"
          fill={tone.accent}
        />
        <circle cx="195" cy="36" r="18" stroke={tone.accent} strokeWidth="1.5" fill="none" />
        <line x1="16" y1="22" x2="72" y2="22" stroke={tone.accent} strokeWidth="1.5" />
      </svg>

      <div className="relative z-10 flex items-center justify-between text-[11px] font-medium opacity-85">
        <span className="truncate max-w-[70%]">{book.format}</span>
        <span className="font-mono tabular-nums">{book.pages}p</span>
      </div>

      <div className="relative z-10 space-y-1">
        <div className={`font-display font-semibold leading-snug line-clamp-2 ${compact ? 'text-sm' : 'text-base'}`}>
          {book.title}
        </div>
        <div className="text-[11px] opacity-80 truncate">{book.author}</div>
      </div>
    </div>
  );
};
