import { useCallback, useEffect, useRef, useState } from 'react';

export type SpeechToTextStatus = 'idle' | 'recording' | 'transcribing';

interface BrowserSpeechRecognition {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface UseSpeechToTextOptions {
  languageName: string;
  speechLang: string;
  isOffline?: boolean;
  onTranscript: (text: string) => void;
}

function pickSupportedAudioMime(): string {
  if (typeof MediaRecorder === 'undefined') return 'audio/webm';
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4',
    'audio/ogg;codecs=opus',
    'audio/ogg',
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return '';
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      if (commaIdx === -1) {
        reject(new Error('Failed to encode audio clip.'));
        return;
      }
      resolve(result.slice(commaIdx + 1));
    };
    reader.onerror = () => reject(new Error('Failed to read recorded audio.'));
    reader.readAsDataURL(blob);
  });
}

export function useSpeechToText({
  languageName,
  speechLang,
  isOffline = false,
  onTranscript,
}: UseSpeechToTextOptions) {
  const [status, setStatus] = useState<SpeechToTextStatus>('idle');
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const maxTimerRef = useRef<number | null>(null);
  const recognitionRef = useRef<BrowserSpeechRecognition | null>(null);
  const cancelledRef = useRef(false);
  const onTranscriptRef = useRef(onTranscript);

  useEffect(() => {
    onTranscriptRef.current = onTranscript;
  }, [onTranscript]);

  const cleanupMedia = useCallback(() => {
    if (maxTimerRef.current !== null) {
      window.clearTimeout(maxTimerRef.current);
      maxTimerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    recorderRef.current = null;
    chunksRef.current = [];
  }, []);

  const stopRecording = useCallback(() => {
    if (recorderRef.current && recorderRef.current.state === 'recording') {
      recorderRef.current.stop();
      return;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore
      }
      recognitionRef.current = null;
      setStatus('idle');
    }
  }, []);

  useEffect(() => {
    return () => {
      cancelledRef.current = true;
      if (recorderRef.current && recorderRef.current.state === 'recording') {
        try {
          recorderRef.current.stop();
        } catch {
          // ignore
        }
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
      cleanupMedia();
    };
  }, [cleanupMedia]);

  const startBrowserFallback = useCallback(() => {
    const win = window as unknown as {
      SpeechRecognition?: new () => BrowserSpeechRecognition;
      webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
    };
    const RecognitionCtor = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!RecognitionCtor) {
      setVoiceError('Microphone speech-to-text is not supported in this browser.');
      setStatus('idle');
      return;
    }

    setVoiceError(null);
    const recognition = new RecognitionCtor();
    recognitionRef.current = recognition;
    recognition.lang = speechLang;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript?.trim() ?? '';
      if (transcript) {
        onTranscriptRef.current(transcript);
      }
    };
    recognition.onerror = (event) => {
      recognitionRef.current = null;
      setStatus('idle');
      if (event?.error !== 'aborted') {
        setVoiceError('Could not detect speech or microphone access was denied.');
      }
    };
    recognition.onend = () => {
      recognitionRef.current = null;
      setStatus('idle');
    };

    setStatus('recording');
    recognition.start();
  }, [speechLang]);

  const toggleRecording = useCallback(async () => {
    if (status === 'recording') {
      stopRecording();
      return;
    }
    if (status === 'transcribing') return;

    setVoiceError(null);
    cancelledRef.current = false;

    const canRecord =
      !isOffline &&
      typeof navigator !== 'undefined' &&
      Boolean(navigator.mediaDevices?.getUserMedia) &&
      typeof MediaRecorder !== 'undefined';

    if (!canRecord) {
      startBrowserFallback();
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (cancelledRef.current) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }

      streamRef.current = stream;
      const mimeType = pickSupportedAudioMime();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      recorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          chunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = () => {
        const recordedType = recorder.mimeType || mimeType || 'audio/webm';
        const recordedChunks = [...chunksRef.current];
        cleanupMedia();

        if (cancelledRef.current || recordedChunks.length === 0) {
          setStatus('idle');
          return;
        }

        const audioBlob = new Blob(recordedChunks, { type: recordedType });
        if (audioBlob.size < 400) {
          setVoiceError('Recording was too short. Hold and speak clearly, then tap stop.');
          setStatus('idle');
          return;
        }

        setStatus('transcribing');
        void (async () => {
          try {
            const audioBase64 = await blobToBase64(audioBlob);
            const res = await fetch('/api/stt', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                audioBase64,
                mimeType: recordedType.split(';')[0],
                language: languageName,
              }),
            });

            const data = await res.json().catch(() => ({}));
            if (!res.ok) {
              throw new Error(data.error || 'Could not transcribe voice input.');
            }

            const transcript = String(data.transcript || '').trim();
            if (!transcript) {
              setVoiceError('No clear speech detected. Please try speaking closer to the mic.');
            } else {
              onTranscriptRef.current(transcript);
            }
          } catch (err) {
            setVoiceError(
              err instanceof Error ? err.message : 'Unable to transcribe audio right now.'
            );
          } finally {
            setStatus('idle');
          }
        })();
      };

      recorder.start(250);
      setStatus('recording');

      // Safety cap at 45s per voice clip
      maxTimerRef.current = window.setTimeout(() => {
        if (recorderRef.current?.state === 'recording') {
          recorderRef.current.stop();
        }
      }, 45000);
    } catch {
      cleanupMedia();
      // Fall back to browser SpeechRecognition if MediaRecorder fails cleanly
      startBrowserFallback();
    }
  }, [status, isOffline, languageName, stopRecording, startBrowserFallback, cleanupMedia]);

  const dismissVoiceError = useCallback(() => setVoiceError(null), []);

  return {
    sttStatus: status,
    isListening: status === 'recording',
    isTranscribing: status === 'transcribing',
    voiceError,
    toggleRecording,
    stopRecording,
    dismissVoiceError,
  };
}
