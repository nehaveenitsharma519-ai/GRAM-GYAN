import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { LANGUAGES } from '../data/translations';
import { ChatbotMessage, ChatbotRoleId, LanguageCode } from '../types/gramGyan';

export type ChatVoiceGender = 'female' | 'male';
export type ChatVoicePersonaId = 'Kore' | 'Zephyr' | 'Charon' | 'Puck' | 'Fenrir';

export interface ChatVoicePersona {
  id: ChatVoicePersonaId;
  label: string;
  gender: ChatVoiceGender;
}

export const CHAT_VOICE_PERSONAS: ChatVoicePersona[] = [
  { id: 'Kore', label: 'Kore · Warm & Clear (Female)', gender: 'female' },
  { id: 'Zephyr', label: 'Zephyr · Bright & Gentle (Female)', gender: 'female' },
  { id: 'Charon', label: 'Charon · Calm & Clear (Male)', gender: 'male' },
  { id: 'Puck', label: 'Puck · Friendly & Upbeat (Male)', gender: 'male' },
  { id: 'Fenrir', label: 'Fenrir · Deep & Steady (Male)', gender: 'male' },
];

export interface ChatVoiceLanguage {
  id: string;
  label: string;
  apiLanguage: string;
  speechLang: string;
}

export const CHAT_VOICE_LANGUAGES: ChatVoiceLanguage[] = [
  { id: 'auto', label: 'App Language (Auto)', apiLanguage: 'Auto', speechLang: 'en-IN' },
  { id: 'hi', label: 'Hindi (हिन्दी)', apiLanguage: 'Hindi', speechLang: 'hi-IN' },
  { id: 'en', label: 'English (India)', apiLanguage: 'English (India)', speechLang: 'en-IN' },
  { id: 'mr', label: 'Marathi (मराठी)', apiLanguage: 'Marathi', speechLang: 'mr-IN' },
  { id: 'kn', label: 'Kannada (ಕನ್ನಡ)', apiLanguage: 'Kannada', speechLang: 'kn-IN' },
  { id: 'ta', label: 'Tamil (தமிழ்)', apiLanguage: 'Tamil', speechLang: 'ta-IN' },
  { id: 'te', label: 'Telugu (తెలుగు)', apiLanguage: 'Telugu', speechLang: 'te-IN' },
  { id: 'bn', label: 'Bengali (বাংলা)', apiLanguage: 'Bengali', speechLang: 'bn-IN' },
  { id: 'gu', label: 'Gujarati (ગુજરાતી)', apiLanguage: 'Gujarati', speechLang: 'gu-IN' },
  { id: 'pa', label: 'Punjabi (ਪੰਜਾਬੀ)', apiLanguage: 'Punjabi', speechLang: 'pa-IN' },
  { id: 'ml', label: 'Malayalam (മലയാളം)', apiLanguage: 'Malayalam', speechLang: 'ml-IN' },
  { id: 'ur', label: 'Urdu (اردو)', apiLanguage: 'Urdu', speechLang: 'ur-IN' },
  { id: 'doi', label: 'Dogri (डोगरी)', apiLanguage: 'Dogri', speechLang: 'hi-IN' },
  { id: 'ks', label: 'Kashmiri (کٲشُر)', apiLanguage: 'Kashmiri', speechLang: 'ur-IN' },
];

export interface ChatbotRoleInfo {
  id: ChatbotRoleId;
  label: string;
  subtitle: string;
  modelLabel: string;
  starterPrompts: string[];
}

export const CHATBOT_ROLES: ChatbotRoleInfo[] = [
  {
    id: 'gram_sahayak',
    label: 'Gram Sahayak',
    subtitle: 'Schemes, documents & Panchayat services',
    modelLabel: 'gemini-4-hydrogen',
    starterPrompts: [
      'Mujhe government pension ke liye apply karna hai.',
      'Ladli Beti scheme ke documents aur eligibility batao.',
      'Ayushman SEHAT card kaise aur kahan banega?',
    ],
  },
  {
    id: 'krishi_mitra',
    label: 'Krishi Mitra',
    subtitle: 'Crop care, apple orchards & mandi rates',
    modelLabel: 'gemini-4-hydrogen',
    starterPrompts: [
      'Apple ki fasal mein bimari lag gayi hai, kya karun?',
      'Baramulla aur Bhaderwah mandi ke rates kahan dekhein?',
      'Basmati aur maize ki buvai ke liye tip do.',
    ],
  },
  {
    id: 'shiksha_guru',
    label: 'Shiksha Guru',
    subtitle: 'Scholarships, JKSSB exams & Spoken English',
    modelLabel: 'gemini-4-hydrogen',
    starterPrompts: [
      'Mere bachche ke liye scholarship kaunsi hai?',
      'Mujhe JKSSB ki latest vacancy ki information chahiye.',
      'Teach me 5 simple Spoken English sentences for bank visits.',
    ],
  },
  {
    id: 'quick_help',
    label: 'Quick Help',
    subtitle: 'Fast helpline numbers & instant answers',
    modelLabel: 'gemini-3.1-flash-lite',
    starterPrompts: [
      'Give all emergency helpline numbers for Jammu & Kashmir.',
      'Mere gaon ke paas hospital kahan hai?',
      'Translate "Please verify my ration card" into Hindi and Marathi.',
    ],
  },
];

const CHAT_STORAGE_KEY = 'gg_gemini_chat_v1';
const ROLE_STORAGE_KEY = 'gg_gemini_chat_role_v1';
const AUTOREAD_STORAGE_KEY = 'gg_gemini_chat_autoread_v1';
const VOICE_GENDER_STORAGE_KEY = 'gg_gemini_chat_voice_gender_v1';
const VOICE_PERSONA_STORAGE_KEY = 'gg_gemini_chat_voice_persona_v1';
const VOICE_LANG_STORAGE_KEY = 'gg_gemini_chat_voice_lang_v1';
const SPEECH_RATE_STORAGE_KEY = 'gg_gemini_chat_speech_rate_v1';

const FEMALE_VOICE_HINTS = [
  'female',
  'woman',
  'heera',
  'kalpana',
  'swara',
  'neerja',
  'aditi',
  'raveena',
  'lekha',
  'veena',
  'samantha',
  'victoria',
  'karen',
  'zira',
  'aria',
  'jenny',
  'sonia',
  'google हिन्दी',
  'google uk english female',
];

const MALE_VOICE_HINTS = [
  'male',
  'man',
  'ravi',
  'hemant',
  'prabhat',
  'madhur',
  'salman',
  'daniel',
  'rishi',
  'alex',
  'david',
  'mark',
  'george',
  'ryan',
  'guy',
  'oliver',
  'google uk english male',
];

function selectBrowserVoiceFallback(
  voices: SpeechSynthesisVoice[],
  targetLang: string,
  gender: ChatVoiceGender
): { voice: SpeechSynthesisVoice | null; matchedGender: boolean } {
  if (!voices.length) return { voice: null, matchedGender: false };

  const langPrefix = targetLang.split('-')[0].toLowerCase();
  const localeMatches = voices.filter((v) => v.lang.toLowerCase().startsWith(langPrefix));
  const pool = localeMatches.length > 0 ? localeMatches : voices;

  const targetHints = gender === 'female' ? FEMALE_VOICE_HINTS : MALE_VOICE_HINTS;
  const oppositeHints = gender === 'female' ? MALE_VOICE_HINTS : FEMALE_VOICE_HINTS;

  const exactMatch = pool.find((v) => {
    const name = v.name.toLowerCase();
    return targetHints.some((hint) => name.includes(hint)) && !oppositeHints.some((opp) => name.includes(opp));
  });
  if (exactMatch) return { voice: exactMatch, matchedGender: true };

  return { voice: pool[0] ?? null, matchedGender: false };
}

function cleanSpeechText(raw: string): string {
  return raw
    .replace(/https?:\/\/\S+/gi, '')
    .replace(/\*\*/g, '')
    .replace(/[#_`]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function base64ToBlobUrl(base64: string, mimeType: string): string {
  const binaryStr = atob(base64);
  const len = binaryStr.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryStr.charCodeAt(i);
  }
  const blob = new Blob([bytes], { type: mimeType || 'audio/wav' });
  return URL.createObjectURL(blob);
}

interface ChatContextValue {
  messages: ChatbotMessage[];
  activeRoleId: ChatbotRoleId;
  activeRole: ChatbotRoleInfo;
  isDrawerOpen: boolean;
  isOffline: boolean;
  loading: boolean;
  errorMsg: string | null;
  autoRead: boolean;
  voiceGender: ChatVoiceGender;
  voicePersona: ChatVoicePersonaId;
  voiceLanguageId: string;
  activeVoiceLanguage: ChatVoiceLanguage;
  speechRate: number;
  speakingMsgId: string | null;
  ttsLoadingMsgId: string | null;
  setIsDrawerOpen: (open: boolean) => void;
  setActiveRoleId: (roleId: ChatbotRoleId) => void;
  setAutoRead: (enabled: boolean) => void;
  setVoiceGender: (gender: ChatVoiceGender) => void;
  setVoicePersona: (persona: ChatVoicePersonaId) => void;
  setVoiceLanguageId: (langId: string) => void;
  setSpeechRate: (rate: number) => void;
  speakMessage: (id: string, text: string, genderOverride?: ChatVoiceGender) => void;
  stopSpeaking: () => void;
  sendMessage: (text: string) => Promise<void>;
  retryLastMessage: () => Promise<void>;
  clearHistory: () => void;
  dismissError: () => void;
}

const ChatContext = createContext<ChatContextValue | null>(null);

function readStoredMessages(): ChatbotMessage[] {
  try {
    const raw = localStorage.getItem(CHAT_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(-40) : [];
  } catch {
    return [];
  }
}

function readStoredRole(): ChatbotRoleId {
  try {
    const raw = localStorage.getItem(ROLE_STORAGE_KEY) as ChatbotRoleId | null;
    if (raw && CHATBOT_ROLES.some((r) => r.id === raw)) return raw;
  } catch {
    // ignore
  }
  return 'gram_sahayak';
}

function readStoredAutoRead(): boolean {
  try {
    const raw = localStorage.getItem(AUTOREAD_STORAGE_KEY);
    if (raw !== null) return JSON.parse(raw) === true;
  } catch {
    // ignore
  }
  return true;
}

function readStoredVoiceGender(): ChatVoiceGender {
  try {
    const raw = localStorage.getItem(VOICE_GENDER_STORAGE_KEY);
    if (raw === 'male' || raw === 'female') return raw;
  } catch {
    // ignore
  }
  return 'female';
}

function readStoredVoicePersona(gender: ChatVoiceGender): ChatVoicePersonaId {
  try {
    const raw = localStorage.getItem(VOICE_PERSONA_STORAGE_KEY) as ChatVoicePersonaId | null;
    if (raw && CHAT_VOICE_PERSONAS.some((p) => p.id === raw)) return raw;
  } catch {
    // ignore
  }
  return gender === 'male' ? 'Charon' : 'Kore';
}

function readStoredVoiceLanguage(): string {
  try {
    const raw = localStorage.getItem(VOICE_LANG_STORAGE_KEY);
    if (raw && CHAT_VOICE_LANGUAGES.some((l) => l.id === raw)) return raw;
  } catch {
    // ignore
  }
  return 'auto';
}

function readStoredSpeechRate(): number {
  try {
    const raw = Number(localStorage.getItem(SPEECH_RATE_STORAGE_KEY));
    if (raw >= 0.75 && raw <= 1.5) return raw;
  } catch {
    // ignore
  }
  return 1.0;
}

export const ChatProvider: React.FC<{
  children: React.ReactNode;
  language: LanguageCode;
  district: string;
  isOffline: boolean;
}> = ({ children, language, district, isOffline }) => {
  const [messages, setMessages] = useState<ChatbotMessage[]>(readStoredMessages);
  const [activeRoleId, setActiveRoleIdState] = useState<ChatbotRoleId>(readStoredRole);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [autoRead, setAutoReadState] = useState<boolean>(readStoredAutoRead);
  const [voiceGender, setVoiceGenderState] = useState<ChatVoiceGender>(readStoredVoiceGender);
  const [voicePersona, setVoicePersonaState] = useState<ChatVoicePersonaId>(() =>
    readStoredVoicePersona(readStoredVoiceGender())
  );
  const [voiceLanguageId, setVoiceLanguageIdState] = useState<string>(readStoredVoiceLanguage);
  const [speechRate, setSpeechRateState] = useState<number>(readStoredSpeechRate);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [ttsLoadingMsgId, setTtsLoadingMsgId] = useState<string | null>(null);
  const [browserVoices, setBrowserVoices] = useState<SpeechSynthesisVoice[]>([]);

  const autoReadRef = useRef(autoRead);
  const voiceGenderRef = useRef(voiceGender);
  const voicePersonaRef = useRef(voicePersona);
  const speechRateRef = useRef(speechRate);
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const audioCacheRef = useRef<Map<string, string>>(new Map());
  const ttsAbortRef = useRef<AbortController | null>(null);
  const speakTokenRef = useRef(0);

  useEffect(() => {
    autoReadRef.current = autoRead;
  }, [autoRead]);
  useEffect(() => {
    voiceGenderRef.current = voiceGender;
  }, [voiceGender]);
  useEffect(() => {
    voicePersonaRef.current = voicePersona;
  }, [voicePersona]);
  useEffect(() => {
    speechRateRef.current = speechRate;
    if (audioElRef.current) {
      audioElRef.current.playbackRate = speechRate;
    }
  }, [speechRate]);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const synth = window.speechSynthesis;
      const loadVoices = () => {
        const v = synth.getVoices();
        if (v.length > 0) setBrowserVoices(v);
      };
      loadVoices();
      synth.onvoiceschanged = loadVoices;
      return () => {
        synth.onvoiceschanged = null;
      };
    }
    return undefined;
  }, []);

  useEffect(() => {
    const cache = audioCacheRef.current;
    return () => {
      ttsAbortRef.current?.abort();
      if (audioElRef.current) {
        audioElRef.current.pause();
        audioElRef.current = null;
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      cache.forEach((url) => URL.revokeObjectURL(url));
      cache.clear();
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages.slice(-40)));
    } catch {
      // ignore storage quota errors
    }
  }, [messages]);

  useEffect(() => {
    try {
      localStorage.setItem(ROLE_STORAGE_KEY, activeRoleId);
    } catch {
      // ignore
    }
  }, [activeRoleId]);

  const activeRole = CHATBOT_ROLES.find((r) => r.id === activeRoleId) ?? CHATBOT_ROLES[0];
  const appLangObj = LANGUAGES.find((l) => l.code === language) ?? LANGUAGES[0];
  const selectedVoiceLang =
    CHAT_VOICE_LANGUAGES.find((v) => v.id === voiceLanguageId) ?? CHAT_VOICE_LANGUAGES[0];

  const resolvedLanguageName =
    selectedVoiceLang.id === 'auto' ? appLangObj.name : selectedVoiceLang.apiLanguage;
  const resolvedSpeechLang =
    selectedVoiceLang.id === 'auto' ? appLangObj.speechLang : selectedVoiceLang.speechLang;

  const stopSpeaking = useCallback(() => {
    speakTokenRef.current += 1;
    ttsAbortRef.current?.abort();
    ttsAbortRef.current = null;
    if (audioElRef.current) {
      audioElRef.current.pause();
      audioElRef.current.currentTime = 0;
      audioElRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setTtsLoadingMsgId(null);
    setSpeakingMsgId(null);
  }, []);

  const speakWithBrowserFallback = useCallback(
    (id: string, cleaned: string, targetGender: ChatVoiceGender, token: number) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
      if (token !== speakTokenRef.current) return;

      const synth = window.speechSynthesis;
      synth.cancel();

      const utterance = new SpeechSynthesisUtterance(cleaned);
      utterance.lang = resolvedSpeechLang;

      const voicesNow = browserVoices.length > 0 ? browserVoices : synth.getVoices();
      const { voice, matchedGender } = selectBrowserVoiceFallback(
        voicesNow,
        resolvedSpeechLang,
        targetGender
      );

      if (voice) utterance.voice = voice;
      utterance.pitch = matchedGender
        ? targetGender === 'female'
          ? 1.04
          : 0.92
        : targetGender === 'female'
          ? 1.15
          : 0.82;
      utterance.rate = speechRateRef.current;

      utterance.onend = () => setSpeakingMsgId((cur) => (cur === id ? null : cur));
      utterance.onerror = () => setSpeakingMsgId((cur) => (cur === id ? null : cur));

      setSpeakingMsgId(id);
      synth.speak(utterance);
    },
    [browserVoices, resolvedSpeechLang]
  );

  const playBlobUrl = useCallback((id: string, blobUrl: string, token: number) => {
    if (token !== speakTokenRef.current) return;
    if (audioElRef.current) {
      audioElRef.current.pause();
    }
    const audio = new Audio(blobUrl);
    audio.playbackRate = speechRateRef.current;
    audioElRef.current = audio;

    audio.onended = () => {
      if (audioElRef.current === audio) {
        audioElRef.current = null;
      }
      setSpeakingMsgId((cur) => (cur === id ? null : cur));
    };
    audio.onerror = () => {
      if (audioElRef.current === audio) {
        audioElRef.current = null;
      }
      setSpeakingMsgId((cur) => (cur === id ? null : cur));
    };

    setSpeakingMsgId(id);
    void audio.play().catch(() => {
      setSpeakingMsgId((cur) => (cur === id ? null : cur));
    });
  }, []);

  const speakMessage = useCallback(
    (id: string, text: string, genderOverride?: ChatVoiceGender) => {
      if (!genderOverride && (speakingMsgId === id || ttsLoadingMsgId === id)) {
        stopSpeaking();
        return;
      }

      const cleaned = cleanSpeechText(text);
      if (!cleaned) return;

      stopSpeaking();
      const token = ++speakTokenRef.current;

      const targetGender = genderOverride ?? voiceGenderRef.current;
      const currentPersonaMeta = CHAT_VOICE_PERSONAS.find((p) => p.id === voicePersonaRef.current);
      const targetVoiceName: ChatVoicePersonaId =
        currentPersonaMeta?.gender === targetGender
          ? currentPersonaMeta.id
          : targetGender === 'male'
            ? 'Charon'
            : 'Kore';

      if (isOffline) {
        speakWithBrowserFallback(id, cleaned, targetGender, token);
        return;
      }

      const cacheKey = `${id}:${resolvedLanguageName}:${targetVoiceName}`;
      const cachedUrl = audioCacheRef.current.get(cacheKey);
      if (cachedUrl) {
        playBlobUrl(id, cachedUrl, token);
        return;
      }

      const controller = new AbortController();
      ttsAbortRef.current = controller;
      setTtsLoadingMsgId(id);

      void (async () => {
        try {
          const res = await fetch('/api/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              text: cleaned,
              language: resolvedLanguageName,
              gender: targetGender,
              voiceName: targetVoiceName,
            }),
          });

          const data = await res.json().catch(() => ({}));
          if (!res.ok || !data.audioBase64) {
            throw new Error(data.error || 'Neural TTS unavailable');
          }

          if (token !== speakTokenRef.current) return;

          const blobUrl = base64ToBlobUrl(data.audioBase64, data.mimeType || 'audio/wav');
          audioCacheRef.current.set(cacheKey, blobUrl);
          setTtsLoadingMsgId((cur) => (cur === id ? null : cur));
          playBlobUrl(id, blobUrl, token);
        } catch (err) {
          if (controller.signal.aborted || token !== speakTokenRef.current) return;
          setTtsLoadingMsgId((cur) => (cur === id ? null : cur));
          speakWithBrowserFallback(id, cleaned, targetGender, token);
        }
      })();
    },
    [
      speakingMsgId,
      ttsLoadingMsgId,
      stopSpeaking,
      isOffline,
      resolvedLanguageName,
      playBlobUrl,
      speakWithBrowserFallback,
    ]
  );

  const setAutoRead = useCallback(
    (enabled: boolean) => {
      setAutoReadState(enabled);
      try {
        localStorage.setItem(AUTOREAD_STORAGE_KEY, JSON.stringify(enabled));
      } catch {
        // ignore
      }
      if (!enabled) {
        stopSpeaking();
      }
    },
    [stopSpeaking]
  );

  const setVoiceGender = useCallback((gender: ChatVoiceGender) => {
    setVoiceGenderState(gender);
    try {
      localStorage.setItem(VOICE_GENDER_STORAGE_KEY, gender);
    } catch {
      // ignore
    }
    setVoicePersonaState((prev) => {
      const current = CHAT_VOICE_PERSONAS.find((p) => p.id === prev);
      if (current?.gender === gender) return prev;
      const next = gender === 'male' ? 'Charon' : 'Kore';
      try {
        localStorage.setItem(VOICE_PERSONA_STORAGE_KEY, next);
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const setVoicePersona = useCallback((persona: ChatVoicePersonaId) => {
    setVoicePersonaState(persona);
    try {
      localStorage.setItem(VOICE_PERSONA_STORAGE_KEY, persona);
    } catch {
      // ignore
    }
    const meta = CHAT_VOICE_PERSONAS.find((p) => p.id === persona);
    if (meta) {
      setVoiceGenderState(meta.gender);
      try {
        localStorage.setItem(VOICE_GENDER_STORAGE_KEY, meta.gender);
      } catch {
        // ignore
      }
    }
  }, []);

  const setVoiceLanguageId = useCallback((langId: string) => {
    if (!CHAT_VOICE_LANGUAGES.some((l) => l.id === langId)) return;
    setVoiceLanguageIdState(langId);
    try {
      localStorage.setItem(VOICE_LANG_STORAGE_KEY, langId);
    } catch {
      // ignore
    }
  }, []);

  const setSpeechRate = useCallback((rate: number) => {
    setSpeechRateState(rate);
    try {
      localStorage.setItem(SPEECH_RATE_STORAGE_KEY, String(rate));
    } catch {
      // ignore
    }
  }, []);

  const setActiveRoleId = useCallback((roleId: ChatbotRoleId) => {
    setActiveRoleIdState(roleId);
    setErrorMsg(null);
  }, []);

  const activeRequestRef = useRef(false);
  const pendingQueueRef = useRef<{ id: string; text: string; roleId: ChatbotRoleId }[]>([]);
  const messagesRef = useRef<ChatbotMessage[]>(messages);

  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  const clearHistory = useCallback(() => {
    stopSpeaking();
    pendingQueueRef.current = [];
    messagesRef.current = [];
    audioCacheRef.current.forEach((url) => URL.revokeObjectURL(url));
    audioCacheRef.current.clear();
    setMessages([]);
    setErrorMsg(null);
  }, [stopSpeaking]);

  const dismissError = useCallback(() => setErrorMsg(null), []);

  const requestReply = useCallback(
    async (
      targetMsgId: string,
      promptText: string,
      priorHistory: { role: 'user' | 'model'; text: string }[],
      targetRoleId: ChatbotRoleId
    ) => {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 42000);
      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            message: promptText,
            history: priorHistory,
            roleId: targetRoleId,
            language: resolvedLanguageName,
            district,
          }),
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          throw new Error(data.error || 'Unable to get a reply from Gemini right now.');
        }

        const replyText = String(data.reply || '').trim();
        if (!replyText) {
          throw new Error('Received an empty reply. Please tap Retry.');
        }

        const modelMsg: ChatbotMessage = {
          id: `mdl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          role: 'model',
          text: replyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          roleId: (data.roleId as ChatbotRoleId) || targetRoleId,
          modelUsed: data.modelUsed,
        };
        setMessages((prev) => {
          const idx = prev.findIndex((m) => m.id === targetMsgId);
          const next =
            idx >= 0
              ? [...prev.slice(0, idx + 1), modelMsg, ...prev.slice(idx + 1)]
              : [...prev, modelMsg];
          messagesRef.current = next;
          return next;
        });

        if (autoReadRef.current && modelMsg.text) {
          speakMessage(modelMsg.id, modelMsg.text, voiceGenderRef.current);
        }
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          setErrorMsg('Request took too long. Tap Retry to get your answer.');
        } else {
          setErrorMsg(err instanceof Error ? err.message : 'Unable to reach Gemini Chat service.');
        }
      } finally {
        window.clearTimeout(timeoutId);
      }
    },
    [resolvedLanguageName, district, speakMessage]
  );

  const processQueue = useCallback(async () => {
    if (activeRequestRef.current) return;
    activeRequestRef.current = true;
    setLoading(true);
    try {
      while (pendingQueueRef.current.length > 0) {
        const nextItem = pendingQueueRef.current.shift()!;
        const currentList = messagesRef.current;
        const msgIdx = currentList.findIndex((m) => m.id === nextItem.id);
        const queuedIds = new Set(pendingQueueRef.current.map((q) => q.id));
        const priorSlice =
          msgIdx >= 0
            ? currentList.slice(Math.max(0, msgIdx - 16), msgIdx)
            : currentList.slice(-16);
        const historySnapshot = priorSlice
          .filter((m) => !queuedIds.has(m.id))
          .map((m) => ({
            role: m.role,
            text: m.text,
          }));
        await requestReply(nextItem.id, nextItem.text, historySnapshot, nextItem.roleId);
      }
    } finally {
      activeRequestRef.current = false;
      setLoading(false);
    }
  }, [requestReply]);

  const sendMessage = useCallback(
    async (rawText: string) => {
      const trimmed = rawText.trim();
      if (!trimmed) return;

      if (isOffline) {
        setErrorMsg(
          'Offline Mode is enabled. Switch off Offline Mode in the header to chat live with Gemini.'
        );
        return;
      }

      setErrorMsg(null);
      const userMsg: ChatbotMessage = {
        id: `usr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        role: 'user',
        text: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        roleId: activeRoleId,
      };

      setMessages((prev) => {
        const next = [...prev, userMsg];
        messagesRef.current = next;
        return next;
      });
      pendingQueueRef.current.push({ id: userMsg.id, text: trimmed, roleId: activeRoleId });
      await processQueue();
    },
    [isOffline, activeRoleId, processQueue]
  );

  const retryLastMessage = useCallback(async () => {
    if (activeRequestRef.current || messagesRef.current.length === 0) return;
    if (isOffline) {
      setErrorMsg(
        'Offline Mode is enabled. Switch off Offline Mode in the header to chat live with Gemini.'
      );
      return;
    }

    const lastMsg = messagesRef.current[messagesRef.current.length - 1];
    if (lastMsg.role !== 'user') return;

    setErrorMsg(null);
    pendingQueueRef.current.push({ id: lastMsg.id, text: lastMsg.text, roleId: activeRoleId });
    await processQueue();
  }, [isOffline, activeRoleId, processQueue]);

  return (
    <ChatContext.Provider
      value={{
        messages,
        activeRoleId,
        activeRole,
        isDrawerOpen,
        isOffline,
        loading,
        errorMsg,
        autoRead,
        voiceGender,
        voicePersona,
        voiceLanguageId,
        activeVoiceLanguage: {
          ...selectedVoiceLang,
          apiLanguage: resolvedLanguageName,
          speechLang: resolvedSpeechLang,
        },
        speechRate,
        speakingMsgId,
        ttsLoadingMsgId,
        setIsDrawerOpen,
        setActiveRoleId,
        setAutoRead,
        setVoiceGender,
        setVoicePersona,
        setVoiceLanguageId,
        setSpeechRate,
        speakMessage,
        stopSpeaking,
        sendMessage,
        retryLastMessage,
        clearHistory,
        dismissError,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) {
    throw new Error('useChat must be used inside ChatProvider');
  }
  return ctx;
}
