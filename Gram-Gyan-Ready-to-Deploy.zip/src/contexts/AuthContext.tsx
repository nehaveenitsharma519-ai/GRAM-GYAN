import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut as firebaseSignOut,
  updateProfile,
  User,
} from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';
import { LanguageCode, UserLocation } from '../types/gramGyan';

export interface CloudUserProfile {
  uid: string;
  displayName: string;
  language: LanguageCode;
  state: string;
  district: string;
  block: string;
  panchayat: string;
  role: 'citizen' | 'digital_mitra' | 'admin';
  savedBookIds: string[];
  downloadedBookIds: string[];
  savedSchemeIds: string[];
}

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  cloudProfile: CloudUserProfile | null;
  signInWithGoogle: () => Promise<void>;
  signUpWithEmail: (name: string, email: string, password: string, phone?: string) => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  resendVerificationEmail: () => Promise<void>;
  refreshAuthUser: () => Promise<boolean>;
  syncUserPreferences: (patch: Partial<CloudUserProfile>) => Promise<void>;
  updatePrivateContact: (phone: string, consentGiven: boolean) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const VALID_LANGUAGES: LanguageCode[] = ['en', 'hi', 'ur', 'doi', 'ks'];

export const AuthProvider: React.FC<{
  children: React.ReactNode;
  defaultLanguage: LanguageCode;
  defaultLocation: UserLocation;
}> = ({ children, defaultLanguage, defaultLocation }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [cloudProfile, setCloudProfile] = useState<CloudUserProfile | null>(null);

  // Deduplicate concurrent ensureUserDocuments calls for the same UID so
  // onAuthStateChanged + signInWithGoogle/signInWithEmail never race on setDoc(create).
  const inFlightEnsureMap = React.useRef<Map<string, Promise<void>>>(new Map());

  const ensureUserDocumentsInternal = async (firebaseUser: User, phoneOverride = '') => {
    if (!firebaseUser.emailVerified) return;

    const userPath = `users/${firebaseUser.uid}`;
    const privatePath = `users/${firebaseUser.uid}/private/info`;
    const userRef = doc(db, 'users', firebaseUser.uid);
    const privateRef = doc(db, 'users', firebaseUser.uid, 'private', 'info');

    let userSnap;
    try {
      userSnap = await getDoc(userRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, userPath);
    }

    if (!userSnap.exists()) {
      const displayName =
        (firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Gram Citizen')
          .trim()
          .slice(0, 100) || 'Gram Citizen';
      const safeLanguage: LanguageCode = VALID_LANGUAGES.includes(defaultLanguage) ? defaultLanguage : 'en';
      const safeState = (defaultLocation.state || 'Jammu & Kashmir').trim().slice(0, 80) || 'Jammu & Kashmir';
      const safeDistrict = (defaultLocation.district || 'Bhaderwah').trim().slice(0, 80) || 'Bhaderwah';
      const safeBlock = (defaultLocation.block || 'Bhaderwah').trim().slice(0, 80) || 'Bhaderwah';
      const safePanchayat = (defaultLocation.panchayat || 'Chinta').trim().slice(0, 80) || 'Chinta';

      const initialProfile: CloudUserProfile = {
        uid: firebaseUser.uid,
        displayName,
        language: safeLanguage,
        state: safeState,
        district: safeDistrict,
        block: safeBlock,
        panchayat: safePanchayat,
        role: 'citizen',
        savedBookIds: [],
        downloadedBookIds: [],
        savedSchemeIds: [],
      };

      try {
        await setDoc(userRef, {
          ...initialProfile,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        setCloudProfile(initialProfile);
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, userPath);
      }
    } else {
      const data = userSnap.data() as CloudUserProfile;
      setCloudProfile(data);
    }

    let privateSnap;
    try {
      privateSnap = await getDoc(privateRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, privatePath);
    }

    if (!privateSnap.exists()) {
      try {
        await setDoc(privateRef, {
          uid: firebaseUser.uid,
          email: (firebaseUser.email || '').slice(0, 160),
          phone: phoneOverride.slice(0, 30),
          consentGiven: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, privatePath);
      }
    }
  };

  const ensureUserDocuments = (firebaseUser: User, phoneOverride = ''): Promise<void> => {
    const existingPromise = inFlightEnsureMap.current.get(firebaseUser.uid);
    if (existingPromise) {
      return existingPromise;
    }

    const promise = ensureUserDocumentsInternal(firebaseUser, phoneOverride).finally(() => {
      inFlightEnsureMap.current.delete(firebaseUser.uid);
    });
    inFlightEnsureMap.current.set(firebaseUser.uid, promise);
    return promise;
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (nextUser && nextUser.emailVerified) {
        try {
          await ensureUserDocuments(nextUser);
        } catch (err) {
          console.error('Profile sync skipped:', err);
        }
      } else {
        setCloudProfile(null);
      }
    });
    return () => unsub();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signInWithGoogle = async () => {
    const cred = await signInWithPopup(auth, googleProvider);
    if (cred.user && cred.user.emailVerified) {
      await ensureUserDocuments(cred.user);
    }
  };

  const signUpWithEmail = async (name: string, email: string, password: string, phone = '') => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    if (name.trim()) {
      await updateProfile(cred.user, { displayName: name.trim().slice(0, 100) });
    }
    await sendEmailVerification(cred.user);
    if (cred.user.emailVerified) {
      await ensureUserDocuments(cred.user, phone);
    }
  };

  const signInWithEmail = async (email: string, password: string) => {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    if (cred.user && cred.user.emailVerified) {
      await ensureUserDocuments(cred.user);
    }
  };

  const logout = async () => {
    await firebaseSignOut(auth);
    setCloudProfile(null);
  };

  const resendVerificationEmail = async () => {
    if (auth.currentUser && !auth.currentUser.emailVerified) {
      await sendEmailVerification(auth.currentUser);
    }
  };

  const refreshAuthUser = async () => {
    if (!auth.currentUser) return false;
    await auth.currentUser.reload();
    const updated = auth.currentUser;
    if (updated.emailVerified) {
      // Refresh ID token so Firestore receives email_verified: true immediately
      await updated.getIdToken(true);
      setUser(updated);
      await ensureUserDocuments(updated);
      return true;
    }
    setUser(updated);
    return false;
  };

  const syncUserPreferences = async (patch: Partial<CloudUserProfile>) => {
    if (!auth.currentUser || !auth.currentUser.emailVerified) return;
    const allowedPatch: Record<string, unknown> = {};
    if (patch.displayName !== undefined) {
      const cleanName = patch.displayName.trim().slice(0, 100);
      if (cleanName) allowedPatch.displayName = cleanName;
    }
    if (patch.language !== undefined && VALID_LANGUAGES.includes(patch.language)) {
      allowedPatch.language = patch.language;
    }
    if (patch.state !== undefined) {
      const cleanState = patch.state.trim().slice(0, 80);
      if (cleanState) allowedPatch.state = cleanState;
    }
    if (patch.district !== undefined) {
      const cleanDistrict = patch.district.trim().slice(0, 80);
      if (cleanDistrict) allowedPatch.district = cleanDistrict;
    }
    if (patch.block !== undefined) {
      const cleanBlock = patch.block.trim().slice(0, 80);
      if (cleanBlock) allowedPatch.block = cleanBlock;
    }
    if (patch.panchayat !== undefined) {
      const cleanPanchayat = patch.panchayat.trim().slice(0, 80);
      if (cleanPanchayat) allowedPatch.panchayat = cleanPanchayat;
    }
    if (patch.savedBookIds !== undefined) allowedPatch.savedBookIds = patch.savedBookIds.slice(0, 50);
    if (patch.downloadedBookIds !== undefined) allowedPatch.downloadedBookIds = patch.downloadedBookIds.slice(0, 50);
    if (patch.savedSchemeIds !== undefined) allowedPatch.savedSchemeIds = patch.savedSchemeIds.slice(0, 50);

    if (Object.keys(allowedPatch).length === 0) return;

    await ensureUserDocuments(auth.currentUser);
    allowedPatch.updatedAt = serverTimestamp();

    const userRef = doc(db, 'users', auth.currentUser.uid);
    try {
      await updateDoc(userRef, allowedPatch);
      setCloudProfile((prev) => (prev ? { ...prev, ...patch } : prev));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${auth.currentUser.uid}`);
    }
  };

  const updatePrivateContact = async (phone: string, consentGiven: boolean) => {
    if (!auth.currentUser || !auth.currentUser.emailVerified) return;
    const privatePath = `users/${auth.currentUser.uid}/private/info`;
    const privateRef = doc(db, 'users', auth.currentUser.uid, 'private', 'info');

    let snap;
    try {
      snap = await getDoc(privateRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, privatePath);
    }

    if (!snap.exists()) {
      try {
        await setDoc(privateRef, {
          uid: auth.currentUser.uid,
          email: (auth.currentUser.email || '').slice(0, 160),
          phone: phone.slice(0, 30),
          consentGiven,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, privatePath);
      }
      return;
    }

    try {
      await updateDoc(privateRef, {
        email: (auth.currentUser.email || '').slice(0, 160),
        phone: phone.slice(0, 30),
        consentGiven,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, privatePath);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        authReady,
        cloudProfile,
        signInWithGoogle,
        signUpWithEmail,
        signInWithEmail,
        logout,
        resendVerificationEmail,
        refreshAuthUser,
        syncUserPreferences,
        updatePrivateContact,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
