export type LanguageCode = 'en' | 'hi' | 'ur' | 'doi' | 'ks';

export type ProductMode = 'citizen' | 'admin' | 'centres';

export type BottomNavTab = 'home' | 'read' | 'services' | 'village' | 'profile';

export type ContentStatus = 'Draft' | 'Under Review' | 'Verified' | 'Expired';

export type ModuleId =
  | 'library'
  | 'education'
  | 'career'
  | 'skills'
  | 'schemes'
  | 'panchayat'
  | 'documents'
  | 'rights'
  | 'farming'
  | 'business'
  | 'jobs'
  | 'banking'
  | 'health'
  | 'weather'
  | 'transport'
  | 'marketplace'
  | 'news'
  | 'women_child'
  | 'senior_citizen'
  | 'ai_assistant'
  | 'animal_husbandry';

export interface UserLocation {
  state: string;
  district: string;
  block: string;
  panchayat: string;
}

export interface UserProfile {
  name: string;
  phone: string;
  isGuest: boolean;
  role: string;
  consentGiven: boolean;
}

export interface BookChapter {
  title: string;
  content: string;
}

export interface LibraryResource {
  id: string;
  title: string;
  author: string;
  category: string;
  language: string;
  format: 'Book' | 'Textbook' | 'Newspaper' | 'Magazine' | 'Audiobook' | 'Manual';
  pages: number;
  sizeKb: number;
  lowDataSizeKb: number;
  source: string;
  publicationDate: string;
  copyrightStatus: string;
  lastVerified: string;
  status: ContentStatus;
  summary: string;
  coverTone: 'forest' | 'saffron' | 'slate' | 'sky' | 'amber' | 'rose';
  chapters: BookChapter[];
}

export interface GovernmentScheme {
  id: string;
  title: string;
  department: string;
  geography: string;
  benefitSummary: string;
  eligibility: string[];
  documentsRequired: string[];
  applicationSteps: string[];
  officialPortalName: string;
  officialUrl: string;
  deadline: string;
  lastVerified: string;
  status: ContentStatus;
  category:
    | 'Farmers'
    | 'Animal & Sheep Husbandry'
    | 'Women & Child'
    | 'Senior Citizen'
    | 'Education'
    | 'Health'
    | 'Housing & Livelihood';
}

export interface JobNotification {
  id: string;
  title: string;
  organization: string;
  location: string;
  qualification: string;
  vacancies: string;
  closingDate: string;
  officialPortal: string;
  officialUrl: string;
  lastVerified: string;
  status: ContentStatus;
  type: 'Government' | 'Apprenticeship' | 'Private' | 'Defence';
}

export interface MandiPriceItem {
  commodity: string;
  variety: string;
  mandi: string;
  district: string;
  minPrice: number;
  maxPrice: number;
  modalPrice: number;
  unit: string;
  updatedAt: string;
}

export interface CropAdvisory {
  id: string;
  crop: string;
  district: string;
  season: string;
  advisory: string;
  actionChecklist: string[];
  source: string;
  lastVerified: string;
}

export interface HealthCentre {
  id: string;
  name: string;
  type: 'District Hospital' | 'GMC' | 'CHC' | 'PHC' | 'Blood Bank';
  district: string;
  block: string;
  phone: string;
  services: string[];
  timing: string;
}

export interface WeatherForecast {
  district: string;
  tempC: number;
  condition: string;
  humidity: string;
  rainChance: string;
  alertLevel: 'Normal' | 'Advisory' | 'Warning';
  alertMessage: string;
  farmerTip: string;
  source: string;
  updatedAt: string;
}

export interface TransportRoute {
  id: string;
  mode: 'JKSRTC Bus' | 'Northern Railway' | 'Local Shuttle';
  routeName: string;
  district: string;
  schedule: string;
  fareEstimate: string;
  helpline: string;
}

export interface LocalListing {
  id: string;
  name: string;
  category: 'CSC Centre' | 'Electrician & Plumber' | 'Mechanic' | 'Agri & Seed Shop' | 'Women SHG' | 'Homestay';
  district: string;
  village: string;
  contact: string;
  verifiedBy: string;
  description: string;
}

export interface PanchayatNotice {
  id: string;
  title: string;
  panchayat: string;
  block: string;
  district: string;
  date: string;
  category: 'Gram Sabha' | 'MGNREGA Works' | 'Water & Sanitation' | 'Public Notice';
  summary: string;
  issuedBy: string;
  status: ContentStatus;
}

export interface NewsItem {
  id: string;
  headline: string;
  scope: 'District' | 'J&K State' | 'National';
  district?: string;
  source: string;
  publishedAt: string;
  summary: string;
  url: string;
  status: ContentStatus;
}

export interface CertificateGuide {
  id: string;
  name: string;
  issuingAuthority: string;
  documents: string[];
  steps: string[];
  portalName: string;
  portalUrl: string;
  processingTime: string;
  fee: string;
}

export interface QuizQuestion {
  id: string;
  subject: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface GrievanceTicket {
  id: string;
  citizenName: string;
  district: string;
  category: string;
  message: string;
  submittedAt: string;
  status: 'Open' | 'In Progress' | 'Resolved';
}

export interface BookNote {
  id: string;
  bookId: string;
  chapterIndex: number;
  text: string;
  createdAt: string;
}

export interface WeeklyReadingStat {
  weekId: string;
  weekLabel: string;
  booksFinished: number;
  minutesRead: number;
  sessionsCount: number;
}

export type ChatbotRoleId = 'gram_sahayak' | 'krishi_mitra' | 'shiksha_guru' | 'quick_help';

export interface ChatbotMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  roleId: ChatbotRoleId;
  modelUsed?: string;
  checklist?: string[];
  officialSources?: { name: string; url: string }[];
  followUps?: string[];
}

export type CropCategory =
  | 'Cereals & Grains'
  | 'Pulses (Dal)'
  | 'Oilseeds'
  | 'Cash & Commercial'
  | 'Spices & Plantation'
  | 'Vegetables & Staples'
  | 'Fruits & Nuts'
  | 'Fodder & Forage';

export type SeedSeason = 'Kharif' | 'Rabi' | 'Zaid' | 'Perennial';

export interface CropAgronomyInfo {
  season: SeedSeason | 'Kharif & Rabi';
  sowingWindow: string;
  harvestDuration: string;
  soilType: string;
  seedRatePerAcre: string;
  seedPriceRange: string;
  recommendedSeeds: string[];
  irrigationAndCare: string;
}

export interface SeedCatalogueItem {
  id: string;
  seedName: string;
  cropName: string;
  hindiName: string;
  category: CropCategory;
  seedType: 'Certified HYV' | 'Hybrid (F1)' | 'GI / Heirloom' | 'Tuber / Rhizome / Sapling';
  season: SeedSeason;
  marketPrice: number;
  subsidisedPrice: number | null;
  priceUnit: '₹ / Kg' | '₹ / 10g Packet' | '₹ / Sapling' | '₹ / 50 Kg Bag' | '₹ / Quintal';
  seedRatePerAcreKg: number;
  seedRateLabel: string;
  maturityDays: string;
  expectedYieldPerAcre: string;
  suitableRegions: string;
  soilRequirement: string;
  seedTreatment: string;
  procurementSource: string;
}

export interface CropStockItem {
  id: string;
  symbol: string;
  name: string;
  localName: string;
  variety: string;
  category: CropCategory;
  primaryMandi: string;
  state: string;
  unit: string;
  currentPrice: number;
  previousPrice: number;
  minPrice: number;
  maxPrice: number;
  mspPrice: number | null;
  weeklySeries: { day: string; price: number }[];
  demandNote: string;
  farmerAction: string;
  updatedAt: string;
}

export type VillageRegion =
  | 'Jammu & Kashmir'
  | 'All India'
  | 'Asia'
  | 'Europe'
  | 'Americas'
  | 'Africa'
  | 'Oceania';

export interface VillageEntry {
  id: string;
  name: string;
  blockOrTehsil: string;
  district: string;
  stateOrProvince: string;
  country: string;
  region: VillageRegion;
  populationApprox: string;
  highlights: string;
  isCustom?: boolean;
}

export interface CropDetectionResult {
  isPlantOrCrop: boolean;
  cropName: string;
  localName: string;
  varietyOrStage: string;
  confidencePercent: number;
  healthStatus:
    | 'Healthy'
    | 'Mild Stress / Deficiency'
    | 'Pest / Disease Alert'
    | 'Nutrient Deficiency'
    | 'Unclear Image';
  detectedIssue: string;
  severity: 'None' | 'Low' | 'Moderate' | 'High';
  visualSymptoms: string[];
  organicAndImmediateActions: string[];
  chemicalAndKvkGuidance: string;
  recommendedFertilizerOrCare: string;
  estimatedHarvestOrSeedTip: string;
  spokenSummary: string;
  modelUsed?: string;
}

export interface CropScanHistoryItem {
  id: string;
  scannedAt: string;
  district: string;
  result: CropDetectionResult;
}



