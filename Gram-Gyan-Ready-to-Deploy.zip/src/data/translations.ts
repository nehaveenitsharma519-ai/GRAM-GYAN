import { LanguageCode } from '../types/gramGyan';

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeLabel: string;
  speechLang: string;
}

export const LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeLabel: 'English', speechLang: 'en-IN' },
  { code: 'hi', name: 'Hindi', nativeLabel: 'हिन्दी', speechLang: 'hi-IN' },
  { code: 'ur', name: 'Urdu', nativeLabel: 'اردو', speechLang: 'ur-IN' },
  { code: 'doi', name: 'Dogri', nativeLabel: 'डोगरी', speechLang: 'hi-IN' },
  { code: 'ks', name: 'Kashmiri', nativeLabel: 'كٲشُر', speechLang: 'ur-IN' },
];

export interface UiStrings {
  brand: string;
  tagline: string;
  greeting: string;
  heroTitle: string;
  heroSubtitle: string;
  searchPlaceholder: string;
  todaysUpdate: string;
  exploreServices: string;
  askAiTitle: string;
  askAiSubtitle: string;
  askAiCta: string;
  recommendedReading: string;
  navHome: string;
  navRead: string;
  navServices: string;
  navVillage: string;
  navProfile: string;
  offlineLabel: string;
  onlineLabel: string;
  lowDataLabel: string;
  verifiedSourceNote: string;
}

export const TRANSLATIONS: Record<LanguageCode, UiStrings> = {
  en: {
    brand: 'GRAM GYAN',
    tagline: 'पढ़ेगा गांव, बढ़ेगा गांव',
    greeting: 'Namaste! Welcome to your village',
    heroTitle: 'One village. One app. Thousands of opportunities.',
    heroSubtitle: 'Verified reading library, government schemes, jobs, farming guidance, and voice assistance in your language.',
    searchPlaceholder: 'Search books, schemes, JKSSB jobs, mandi rates, health centres...',
    todaysUpdate: "Today's Village Update",
    exploreServices: 'Explore 20 Citizen Services',
    askAiTitle: 'Ask Gram Gyan AI',
    askAiSubtitle: 'Ask anything about pensions, scholarships, apple orchard care, or documents in your own language.',
    askAiCta: 'Ask AI Assistant',
    recommendedReading: 'Recommended Reading',
    navHome: 'Home',
    navRead: 'Read',
    navServices: 'Services',
    navVillage: 'Village',
    navProfile: 'Profile',
    offlineLabel: 'Offline Mode',
    onlineLabel: 'Online Synced',
    lowDataLabel: 'Low-Data Saver',
    verifiedSourceNote: 'Informational guides link directly to official portals (UMANG, DigiLocker, JKSSB, AGMARKNET).',
  },
  hi: {
    brand: 'ग्राम ज्ञान',
    tagline: 'पढ़ेगा गांव, बढ़ेगा गांव',
    greeting: 'नमस्ते! आपके गांव में स्वागत है',
    heroTitle: 'एक गांव। एक ऐप। हजारों अवसर।',
    heroSubtitle: 'पुस्तकालय, सरकारी योजनाएं, नौकरियां, खेती की सलाह और आपकी अपनी भाषा में आवाज़ सहायता।',
    searchPlaceholder: 'किताबें, योजनाएं, JKSSB नौकरियां, मंडी भाव या अस्पताल खोजें...',
    todaysUpdate: 'आज का गांव अपडेट',
    exploreServices: 'सभी 20 नागरिक सेवाएं देखें',
    askAiTitle: 'ग्राम ज्ञान AI से पूछें',
    askAiSubtitle: 'पेंशन, छात्रवृत्ति, सेब की खेती या प्रमाणपत्र के बारे में अपनी भाषा में पूछें।',
    askAiCta: 'AI सहायक से पूछें',
    recommendedReading: 'आज की प्रमुख पुस्तकें',
    navHome: 'होम',
    navRead: 'पढ़ें',
    navServices: 'सेवाएं',
    navVillage: 'गांव',
    navProfile: 'प्रोफ़ाइल',
    offlineLabel: 'ऑफ़लाइन मोड',
    onlineLabel: 'ऑनलाइन सिंक',
    lowDataLabel: 'कम डेटा मोड',
    verifiedSourceNote: 'सभी सरकारी सेवाओं की जानकारी सीधे आधिकारिक पोर्टल (UMANG, DigiLocker, JanSugam) से जुड़ी है।',
  },
  ur: {
    brand: 'گرام گیان',
    tagline: 'پڑھے گا گاؤں، بڑھے گا گاؤں',
    greeting: 'آداب! آپ کے گاؤں میں خوش آمدید',
    heroTitle: 'ایک گاؤں۔ ایک ایپ۔ ہزاروں مواقع۔',
    heroSubtitle: 'ڈیجیٹل لائبریری، سرکاری اسکیمیں، روزگار، کھیتی باڑی اور آپ کی زبان میں رہنمائی۔',
    searchPlaceholder: 'کتابیں، سرکاری اسکیمیں، نوکریاں، منڈی نرخ یا صحت مرکز تلاش کریں...',
    todaysUpdate: 'آج کی گاؤں اپڈیٹ',
    exploreServices: 'تمام 20 عوامی خدمات دیکھیں',
    askAiTitle: 'گرام گیان AI سے پوچھیں',
    askAiSubtitle: 'پنشن، وظیفہ، باغبانی یا سرکاری دستاویزات کے بارے میں اپنی زبان میں پوچھیں۔',
    askAiCta: 'AI اسسٹنٹ سے پوچھیں',
    recommendedReading: 'تجویز کردہ مطالعہ',
    navHome: 'ہوم',
    navRead: 'پڑھیں',
    navServices: 'خدمات',
    navVillage: 'گاؤں',
    navProfile: 'پروفائل',
    offlineLabel: 'آف لائن موڈ',
    onlineLabel: 'آن لائن',
    lowDataLabel: 'کم ڈیٹا موڈ',
    verifiedSourceNote: 'تمام معلومات سرکاری پورٹلز (UMANG, DigiLocker, JKSSB) سے تصدیق شدہ ہیں۔',
  },
  doi: {
    brand: 'ग्राम ज्ञान',
    tagline: 'पढ़ेगा ग्रां, बढ़ेगा ग्रां',
    greeting: 'नमस्ते! तुंदे ग्रां च सुआगत ऐ',
    heroTitle: 'इक ग्रां। इक ऐप। हजारां मौके।',
    heroSubtitle: 'डिजिटल किताबां, सरकारी योजनां, नौकरियां, खेती-बाड़ी ते अपनी बोली च मदद।',
    searchPlaceholder: 'किताबां, योजनां, JKSSB नौकरियां, मंडी भाव जां अस्पताल तुप्पो...',
    todaysUpdate: 'अज्जै दा ग्रां अपडेट',
    exploreServices: 'सभ 20 सेवां दिक्खो',
    askAiTitle: 'ग्राम ज्ञान AI कोला पुच्छो',
    askAiSubtitle: 'पेंशन, वजीफा, फसल जां कागजां बारे अपनी बोली च गल्ल करो।',
    askAiCta: 'AI मददगार',
    recommendedReading: 'पढ़ने जोग किताबां',
    navHome: 'घर',
    navRead: 'पढ़ो',
    navServices: 'सेवां',
    navVillage: 'ग्रां',
    navProfile: 'खाता',
    offlineLabel: 'ऑफ़लाइन',
    onlineLabel: 'ऑनलाइन',
    lowDataLabel: 'घट्ट डेटा',
    verifiedSourceNote: 'सरकारी योजनां दी जानकारी सरकारी पोर्टल (UMANG, DigiLocker) कन्नै जुड़ी ऐ।',
  },
  ks: {
    brand: 'گرام گیان',
    tagline: 'پَرِ گام، بَڈِ گام',
    greeting: 'آداب! تُہٕندِ گامَس مَنٛز خوٗش آمدیٖد',
    heroTitle: 'اَکھ گام۔ اَکھ ایپ۔ ساسہٕ بٕدؠ موقعہٕ۔',
    heroSubtitle: 'ڈیجیٹل کِتابہٕ، سَرکٲرؠ سکیمہٕ، نوکری، باغ بٲنی تہٕ تُہٕنٛزِ زَبانہِ مَنٛز مَدَتھ۔',
    searchPlaceholder: 'کِتابہٕ، سکیمہٕ، JKSSB نوکری، مَنڈی نَرخ ژھانٛڈِو...',
    todaysUpdate: 'اَزُک گام اَپڈیٹ',
    exploreServices: 'سٲری 20 خِدمات وُچھِو',
    askAiTitle: 'گرام گیان AI یَس پُژھِو',
    askAiSubtitle: 'پینشَن، سِکالَرشِپ، ژوٗنٛٹھ باغ یا کاغذاتَن ہٕنٛز جانکٲری پَنٕنہِ زَبانہِ مَنٛز حٲصِل کٔرِو۔',
    askAiCta: 'AI مَدَتھ گار',
    recommendedReading: 'خاص کِتابہٕ',
    navHome: 'ہوم',
    navRead: 'پَرِو',
    navServices: 'خِدمات',
    navVillage: 'گام',
    navProfile: 'پروفائل',
    offlineLabel: 'آف لائن',
    onlineLabel: 'آن لائن',
    lowDataLabel: 'کَم ڈیٹا',
    verifiedSourceNote: 'سَرکٲرؠ سکیمَن ہٕنٛز جانکٲری UMANG تہٕ DigiLocker پورٹَلَن سٟتؠ جُڑِتھ چھِ۔',
  },
};
