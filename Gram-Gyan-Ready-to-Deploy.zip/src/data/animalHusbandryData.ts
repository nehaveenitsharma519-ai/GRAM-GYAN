import { GovernmentScheme } from '../types/gramGyan';

export type LivestockSchemeFocus =
  | 'Sheep & Goat'
  | 'Dairy & Cattle'
  | 'Credit & Insurance'
  | 'Poultry & Fodder'
  | 'Health & Breeding';

export interface AnimalSchemeMeta {
  schemeId: string;
  focus: LivestockSchemeFocus;
  subsidyHighlight: string;
  implementingWing: 'Animal Husbandry' | 'Sheep Husbandry' | 'Joint (Animal & Sheep)';
  isLatest?: boolean;
}

export interface VaccinationScheduleItem {
  id: string;
  disease: string;
  species: string;
  seasonTiming: string;
  frequency: string;
  symptomsAndImpact: string;
  govtSupport: string;
}

export interface LivestockBreedItem {
  id: string;
  species: 'Sheep' | 'Goat' | 'Dairy Cattle' | 'Buffalo' | 'Poultry';
  breedName: string;
  originRegion: string;
  keyYield: string;
  bestSuitedFor: string;
  managementTip: string;
}

export interface VeterinaryCentreItem {
  id: string;
  name: string;
  wing: 'Animal Husbandry' | 'Sheep Husbandry' | 'Mobile Vet / Helpline';
  district: string;
  blockLocation: string;
  services: string[];
  contact: string;
  timing: string;
}

export const ANIMAL_HUSBANDRY_SCHEMES: GovernmentScheme[] = [
  {
    id: 'sch-dorper-ram-shd',
    title: 'Dorper Breeding Ram Scheme — Directorate of Sheep Husbandry',
    department: 'Directorate of Sheep Husbandry (J&K) & DAHD Mutton Mission',
    geography: 'Jammu & Kashmir (Bhaderwah, Kathua, Doda, Baramulla & All Blocks) + All-India Clusters',
    benefitSummary:
      'Latest 2026 breed-improvement programme providing pedigree Dorper Breeding Rams (and F1/F2 Dorper crosses) at 50%–75% Government subsidy / subsidised departmental issue rate to double flock mutton yield, accelerate lamb growth (reach market weight in 5–6 months), and reduce wool-shearing maintenance costs.',
    eligibility: [
      'Registered sheep farmers, progressive breeders, migratory Chopan/Bakerwal/Gaddi flock owners, and FPOs/SHGs owning at least 10–25 healthy breeding ewes',
      'Mandatory participation in breed-recording, Pashu Aadhaar 12-digit ear-tagging, and PPR/ET flock vaccination',
      'Commitment to retain the Dorper breeding ram for active flock crossbreeding for at least 2–3 breeding seasons without slaughter',
    ],
    documentsRequired: [
      'Aadhaar Card & Domicile / Resident Proof',
      'Flock Ownership Verification & Tagging Certificate from nearest Sheep Extension Centre (SEC)',
      'Bank Passbook / JanSugam Application Slip & 2 Passport Photographs',
      'Bond / Undertaking for Ram Maintenance & Breeding Record Sharing',
    ],
    applicationSteps: [
      'Apply at your nearest Sheep Extension Centre (SEC), District Sheep Husbandry Officer (DSHO), or online via J&K JanSugam / HADP Kisan Sathi portal.',
      'Get your existing ewe flock inspected and tagged with Pashu Aadhaar ear tags by the Block Sheep Husbandry team.',
      'Upon district committee approval, collect the health-certified & vaccinated Dorper Breeding Ram from the Govt. Sheep Breeding Farm / SEC distribution camp at subsidised cost.',
    ],
    officialPortalName: 'Sheep Husbandry Dept. / JanSugam',
    officialUrl: 'https://jksheephusbandryjammu.nic.in',
    deadline: 'Latest 2026 Distribution Cycle Active',
    lastVerified: '23 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-nlm-edp',
    title: 'National Livestock Mission (NLM) — Sheep, Goat, Poultry & Fodder Entrepreneurship',
    department: 'Dept. of Animal Husbandry & Dairying (DAHD), Govt. of India',
    geography: 'All India (incl. J&K Animal & Sheep Husbandry Depts.)',
    benefitSummary:
      '50% back-ended capital subsidy up to ₹25–50 Lakh for establishing commercial Sheep/Goat breeding farms (100–500 females), Rural Poultry units, Piggery, or Fodder/Silage processing units.',
    eligibility: [
      'Individual farmers, Self-Help Groups (SHGs), FPOs, FCOs, JLGs, and Section 8 companies',
      'Minimum land availability (owned or registered lease) for shed and fodder cultivation',
      'Mandatory bank loan sanction or verified self-financing commitment for project DPCR',
    ],
    documentsRequired: [
      'Aadhaar Card & PAN Card',
      'Detailed Project Report (DPR) in NLM format',
      'Land Ownership / Lease Agreement (Jamabandi / Khasra)',
      '3-Year Bank Statement & Caste Certificate (if applicable)',
      'Training Certificate in Sheep/Goat/Poultry Farming (from KVK / Dept.)',
    ],
    applicationSteps: [
      'Prepare a Detailed Project Report (100+5 or 500+25 Sheep/Goat unit, Poultry, or Fodder Silage) with your Block Veterinary/Sheep Officer.',
      'Register and upload DPR on nlm.udyamimitra.in choosing Animal/Sheep Husbandry State Implementing Agency (SIA).',
      'After bank loan sanction and SIA technical screening, 50% subsidy is released in two instalments via SIDBI.',
    ],
    officialPortalName: 'NLM UdyamiMitra Portal',
    officialUrl: 'https://nlm.udyamimitra.in',
    deadline: 'Open Year-Round (Rolling Screening)',
    lastVerified: '21 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-isds-jk',
    title: 'Integrated Sheep Development Scheme (ISDS) — J&K Sheep Husbandry',
    department: 'Directorate of Sheep Husbandry, Govt. of J&K',
    geography: 'Jammu & Kashmir (All Districts incl. Bhaderwah, Doda, Baramulla)',
    benefitSummary:
      'Subsidised / interest-subvented financial support to set up Mini & Commercial Sheep/Goat Units (25 Ewes + 1 Ram or 100-animal breeder unit), free high-merit Merino/Rambouillet breeding rams & wool-shearing machine kits.',
    eligibility: [
      'Permanent resident / Domicile of Jammu & Kashmir engaged in or starting sheep/goat rearing',
      'Priority for unemployed rural youth, nomadic Chopan / Bakerwal / Gaddi families, and Women SHGs',
      'Availability of basic shed/winter housing and grazing/fodder access',
    ],
    documentsRequired: [
      'J&K Domicile Certificate & Aadhaar Card',
      'Ration Card & Bank Passbook',
      '2 Passport Photographs & Affidavit of no previous default',
      'Verification by nearest Sheep Extension Centre (SEC) / DSHO',
    ],
    applicationSteps: [
      'Visit your nearest Sheep Extension Centre (e.g., SEC Chinta/Bhaderwah) or District Sheep Husbandry Officer (DSHO) office.',
      'Submit application during district annual action plan notification or via J&K JanSugam.',
      'Selected beneficiaries receive breed-certified livestock purchase assistance, tagging, and free 1-year veterinary insurance cover.',
    ],
    officialPortalName: 'Sheep Husbandry Jammu / Kashmir',
    officialUrl: 'https://jksheephusbandryjammu.nic.in',
    deadline: 'Annual District Plan Cycle (Active)',
    lastVerified: '21 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-idds-jk',
    title: 'Integrated Dairy Development Scheme (IDDS) — Dairy & Milk Value Chain',
    department: 'Directorate of Animal Husbandry, Govt. of J&K',
    geography: 'Jammu & Kashmir',
    benefitSummary:
      '50% capital subsidy on establishment of 2-to-20 High-Yielding Dairy Cow/Buffalo units (up to ₹1.50 Lakh per 2-animal unit), plus subsidy for Bulk Milk Coolers (BMCs), automated milking machines & paneer/ghee processing vans.',
    eligibility: [
      'Unemployed youth, dairy farmers, SHGs, and Cooperative Milk Societies with J&K Domicile',
      'Adequate space for clean ventilated cattle shed and green fodder',
    ],
    documentsRequired: [
      'J&K Domicile & Aadhaar Card',
      'Land Record / Shed Availability Proof',
      'Bank Consent / Savings Passbook',
      'Recommendation from Block Veterinary Officer / CAHO',
    ],
    applicationSteps: [
      'Apply online via J&K JanSugam (e-Unnat) or submit physical file to Chief Animal Husbandry Officer (CAHO).',
      'Complete district committee interview/verification for high-yielding HF/Jersey/Sahiwal cattle or Murrah buffalo procurement.',
      'Install ear-tag (Pashu Aadhaar) and submit cattle insurance policy to receive direct subsidy release.',
    ],
    officialPortalName: 'J&K JanSugam (e-Unnat)',
    officialUrl: 'https://jansugam.jk.gov.in',
    deadline: 'Open Under Annual UT Capex Plan',
    lastVerified: '21 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-hadp-livestock',
    title: 'HADP — J&K Self-Sufficiency in Mutton, Wool & Commercial Poultry',
    department: 'Agriculture Production & Animal/Sheep Husbandry Dept., J&K',
    geography: 'Jammu & Kashmir (All 20 Districts)',
    benefitSummary:
      'Holistic Agriculture Development Programme (HADP) grants up to 50% assistance for semi-intensive mutton farms, machine wool-shearing & pelt processing, backyard/commercial layer poultry, and silage fodder banks.',
    eligibility: [
      'J&K farmers, orchardists, youth & SHGs registered on Kisan Sathi / DAKSH Kisan',
      'Must complete short free online orientation module on DAKSH Kisan for chosen livestock project',
    ],
    documentsRequired: [
      'Kisan Khidmat Ghar / HADP Farmer ID',
      'J&K Domicile & Aadhaar',
      'DAKSH Kisan Training Completion Certificate',
      'Bank Account & Project Estimate',
    ],
    applicationSteps: [
      'Log in on hadp.jk.gov.in (Kisan Sathi portal) using mobile OTP.',
      'Select Animal/Sheep Husbandry project (Mutton Self-Sufficiency, Wool Development, Dairy Promotion, or Fodder Security).',
      'Track block-level verification at your nearest Kisan Khidmat Ghar or Block Veterinary Officer.',
    ],
    officialPortalName: 'HADP Kisan Sathi J&K',
    officialUrl: 'https://hadp.jk.gov.in',
    deadline: 'Rolling Selection Windows Active',
    lastVerified: '21 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-kcc-livestock',
    title: 'Kisan Credit Card (KCC) for Animal Husbandry, Sheep & Dairy',
    department: 'DAHD Govt. of India & NABARD / Scheduled Banks',
    geography: 'All India & J&K',
    benefitSummary:
      'Working capital credit up to ₹2,00,000 collateral-free (₹3 Lakh combined farming cap) at 7% p.a., reduced to 4% effective interest on timely repayment for fodder, concentrate feed, medicines, shelter repairs & labour.',
    eligibility: [
      'Individual dairy farmers, sheep/goat rearers, poultry farmers owning or leasing cattle/flocks',
      'Members of Joint Liability Groups (JLGs), SHGs, or Dairy Cooperatives',
    ],
    documentsRequired: [
      'Aadhaar Card & PAN / Voter ID',
      'Livestock Ownership Verification from Veterinary / Sheep Officer',
      '2 Passport Photos & Bank Savings Account',
    ],
    applicationSteps: [
      'Download simple 1-page KCC Animal Husbandry form or apply on JanSamarth portal.',
      'Get flock/herd verification stamped by your nearest VAS (Veterinary Assistant Surgeon) or Sheep Officer.',
      'Submit at nearest J&K Bank / SBI / Grameen Bank branch; banks target disposal within 14 days.',
    ],
    officialPortalName: 'JanSamarth National Portal',
    officialUrl: 'https://www.jansamarth.in',
    deadline: 'Open Year-Round',
    lastVerified: '20 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-rgm-jk',
    title: 'Rashtriya Gokul Mission (RGM) — Free AI, Sex-Sorted Semen & Breed Farms',
    department: 'Dept. of Animal Husbandry & Dairying (DAHD), Govt. of India',
    geography: 'All India & J&K',
    benefitSummary:
      'Free doorstep Artificial Insemination (AI) via trained MAITRIs, high-conception Sex-Sorted Semen (~90% female calves), genomic Pashu Aadhaar tagging, and up to ₹2 Crore (50% subsidy) for Breed Multiplication Farms.',
    eligibility: [
      'All cattle & buffalo rearers are eligible for free/subsidised AI and Pashu Aadhaar services at their doorstep',
      'Entrepreneurs/FPOs applying for Breed Multiplication Farm require 200+ cow shed land capacity',
    ],
    documentsRequired: [
      'Owner Aadhaar & Mobile Number for Bharat Pashudhan (INAPH) Registration',
      'Pashu Aadhaar 12-Digit Ear Tag Number',
    ],
    applicationSteps: [
      'Contact your village MAITRI worker or Veterinary Dispensary to get your cow/buffalo tagged with a free 12-digit Pashu Aadhaar ear tag.',
      'Request Sex-Sorted Semen AI during heat period for female calf birth.',
      'For large Breed Multiplication Farms, apply via ahidf.udyamimitra.in / rashtriyagokulmission.dahd.gov.in.',
    ],
    officialPortalName: 'Rashtriya Gokul Mission Portal',
    officialUrl: 'https://rashtriyagokulmission.dahd.gov.in',
    deadline: 'Ongoing Nationwide Programme',
    lastVerified: '20 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-lhdcp-1962',
    title: 'Livestock Health & Disease Control Programme (LHDCP) & 1962 Mobile Vet',
    department: 'DAHD Govt. of India & State Animal/Sheep Husbandry Depts.',
    geography: 'All India & J&K',
    benefitSummary:
      '100% Free Govt. preventive vaccination against FMD, Brucellosis, PPR (Sheep/Goat plague), and Sheep Pox, plus Toll-Free 1962 Mobile Veterinary Units (MVU) bringing doctors & medicines directly to remote villages.',
    eligibility: [
      'Every livestock, sheep, goat & poultry owner — completely free public service regardless of herd size',
    ],
    documentsRequired: [
      'No documents needed for emergency call; Pashu Aadhaar Ear Tag used to record vaccination history',
    ],
    applicationSteps: [
      'Dial toll-free 1962 during animal sickness, sudden drop in milk, injury, or bloat emergencies to request a Mobile Veterinary Unit van.',
      'Keep animals available during biannual village FMD/PPR vaccination drives notified by your Panchayat & VAS.',
    ],
    officialPortalName: 'DAHD Livestock Health Portal',
    officialUrl: 'https://dahd.gov.in',
    deadline: '24/7 Helpline & Seasonal Drives',
    lastVerified: '21 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
  {
    id: 'sch-ahidf-infra',
    title: 'Animal Husbandry Infrastructure Development Fund (AHIDF)',
    department: 'Ministry of Fisheries, Animal Husbandry & Dairying',
    geography: 'All India & J&K',
    benefitSummary:
      '3% Interest Subvention for 8 years on up to 90% project bank loans + 25% Credit Guarantee for Dairy Chilling Plants, Mutton Cold Storage, Wool Processing Units, and Animal Feed / Mineral Mixture factories.',
    eligibility: [
      'FPOs, Dairy/Sheep Cooperatives, MSMEs, Private Entrepreneurs & Section 8 entities',
    ],
    documentsRequired: [
      'Project DPR, Land Proof, GST / Udyam MSME Registration & Promoter KYC',
    ],
    applicationSteps: [
      'Prepare detailed DPR for processing/cold-chain/feed plant.',
      'Apply online at ahidf.udyamimitra.in to link with participating scheduled commercial banks.',
    ],
    officialPortalName: 'AHIDF UdyamiMitra Portal',
    officialUrl: 'https://ahidf.udyamimitra.in',
    deadline: 'Open Until 31 Mar 2026 / Extended Cycle',
    lastVerified: '20 Nov 2026',
    status: 'Verified',
    category: 'Animal & Sheep Husbandry',
  },
];

export const ANIMAL_SCHEME_META: Record<string, AnimalSchemeMeta> = {
  'sch-dorper-ram-shd': {
    schemeId: 'sch-dorper-ram-shd',
    focus: 'Sheep & Goat',
    subsidyHighlight: 'Latest Scheme · 50%–75% Subsidised Pedigree Dorper Breeding Ram (Fast Mutton Growth)',
    implementingWing: 'Sheep Husbandry',
    isLatest: true,
  },
  'sch-nlm-edp': {
    schemeId: 'sch-nlm-edp',
    focus: 'Sheep & Goat',
    subsidyHighlight: '50% Capital Subsidy (up to ₹50 Lakh)',
    implementingWing: 'Joint (Animal & Sheep)',
  },
  'sch-isds-jk': {
    schemeId: 'sch-isds-jk',
    focus: 'Sheep & Goat',
    subsidyHighlight: 'Mini & Commercial Units + Free High-Merit Rams',
    implementingWing: 'Sheep Husbandry',
  },
  'sch-idds-jk': {
    schemeId: 'sch-idds-jk',
    focus: 'Dairy & Cattle',
    subsidyHighlight: '50% Subsidy (up to ₹1.5L/2-cow unit + Milk Coolers)',
    implementingWing: 'Animal Husbandry',
  },
  'sch-hadp-livestock': {
    schemeId: 'sch-hadp-livestock',
    focus: 'Sheep & Goat',
    subsidyHighlight: 'Up to 50% UT Assistance (Mutton, Wool & Fodder)',
    implementingWing: 'Joint (Animal & Sheep)',
  },
  'sch-kcc-livestock': {
    schemeId: 'sch-kcc-livestock',
    focus: 'Credit & Insurance',
    subsidyHighlight: 'Up to ₹2L Collateral-Free @ 4% Effective Interest',
    implementingWing: 'Joint (Animal & Sheep)',
  },
  'sch-rgm-jk': {
    schemeId: 'sch-rgm-jk',
    focus: 'Health & Breeding',
    subsidyHighlight: 'Free Doorstep AI + 50% Subsidy on Breed Farms',
    implementingWing: 'Animal Husbandry',
  },
  'sch-lhdcp-1962': {
    schemeId: 'sch-lhdcp-1962',
    focus: 'Health & Breeding',
    subsidyHighlight: '100% Free Vaccines + Toll-Free 1962 Mobile Vet',
    implementingWing: 'Joint (Animal & Sheep)',
  },
  'sch-ahidf-infra': {
    schemeId: 'sch-ahidf-infra',
    focus: 'Poultry & Fodder',
    subsidyHighlight: '3% Interest Subvention + 25% Credit Guarantee',
    implementingWing: 'Joint (Animal & Sheep)',
  },
};

export const LIVESTOCK_VACCINATION_SCHEDULE: VaccinationScheduleItem[] = [
  {
    id: 'vac-fmd',
    disease: 'Foot & Mouth Disease (FMD)',
    species: 'Cattle, Buffalo, Sheep & Goat',
    seasonTiming: 'March–April & September–October',
    frequency: 'Every 6 Months (Biannual)',
    symptomsAndImpact: 'Mouth blisters, hoof lameness, sharp drop in milk yield & lamb/calf mortality.',
    govtSupport: '100% Free NADCP vaccination + Pashu Aadhaar entry at village camp.',
  },
  {
    id: 'vac-ppr',
    disease: 'PPR (Peste des Petits Ruminants / Goat Plague)',
    species: 'Sheep & Goat (above 3–4 months)',
    seasonTiming: 'Pre-Winter / Migration (Oct–Nov & Mar)',
    frequency: 'Once every 3 Years',
    symptomsAndImpact: 'High fever, nasal discharge, severe diarrhoea — up to 70% flock loss if unvaccinated.',
    govtSupport: '100% Free Govt. Sheep Husbandry immunization.',
  },
  {
    id: 'vac-et',
    disease: 'Enterotoxaemia (ET / Pulpy Kidney)',
    species: 'Sheep & Goat',
    seasonTiming: 'Spring flush & Monsoon onset (Feb–Mar / Jul)',
    frequency: 'Annual (+ 15-day booster for first-timers)',
    symptomsAndImpact: 'Sudden deaths in healthy thriving lambs after eating lush green pasture grass.',
    govtSupport: 'Free dose through Sheep Extension Centres (SECs) & highland transit camps.',
  },
  {
    id: 'vac-sheep-pox',
    disease: 'Sheep Pox & Contagious Ecthyma',
    species: 'Sheep',
    seasonTiming: 'December – February (Winter Protection)',
    frequency: 'Annual',
    symptomsAndImpact: 'Skin nodules, wool damage, pneumonia in lambs during cold stress.',
    govtSupport: 'Free vaccination by District Sheep Husbandry teams.',
  },
  {
    id: 'vac-hs-bq',
    disease: 'Haemorrhagic Septicaemia (HS) & Black Quarter (BQ)',
    species: 'Cattle & Buffalo',
    seasonTiming: 'Pre-Monsoon (May – June)',
    frequency: 'Annual',
    symptomsAndImpact: 'Throat swelling, breathing difficulty (Galghotu) & sudden limb swelling.',
    govtSupport: 'Free combined HS+BQ dose at Veterinary Hospitals.',
  },
  {
    id: 'vac-deworm',
    disease: 'Internal Parasite Deworming & Ectoparasite Dipping',
    species: 'Sheep, Goat & Dairy Animals',
    seasonTiming: 'Pre-Spring Migration (Mar–Apr) & Post-Monsoon (Sep–Oct)',
    frequency: 'Twice to Thrice Yearly',
    symptomsAndImpact: 'Poor weight gain, anaemia (bottle jaw), rough fleece/wool shedding.',
    govtSupport: 'Free deworming tablets/drenching & dipping vats at Sheep Extension Centres.',
  },
];

export const LIVESTOCK_BREEDS_GUIDE: LivestockBreedItem[] = [
  {
    id: 'brd-dorper',
    species: 'Sheep',
    breedName: 'Dorper Breeding Ram (Pure & Crossbred Mutton Sheep)',
    originRegion: 'Govt. Sheep Breeding Farms (J&K / All-India Mutton Clusters)',
    keyYield: '25–32 kg lamb weight in 5 months · 75–95 kg adult ram · 50%+ carcass dressing',
    bestSuitedFor: 'Commercial mutton production, fast weight gain & hair-coat low-shearing flocks',
    managementTip: 'Provide mineral mixture & deworm every 4 months; cross 1 Dorper ram with 25–30 local/Bakerwal ewes for hardy hybrid lambs.',
  },
  {
    id: 'brd-merino',
    species: 'Sheep',
    breedName: 'Kashmiri Merino & Rambouillet Cross',
    originRegion: 'Bhaderwah, Doda, Kashmir & Chenab Valley',
    keyYield: '2.5 – 3.5 kg Fine Apparel Wool / year + 32–42 kg Adult Weight',
    bestSuitedFor: 'Dual wool & mutton income in mountain & temperate blocks',
    managementTip: 'Use machine wool-shearing in spring & autumn; shelter from freezing damp drafts.',
  },
  {
    id: 'brd-bhakarwal',
    species: 'Goat',
    breedName: 'Bhakarwali & Beetal Goat',
    originRegion: 'Jammu Division, Doda, Rajouri & Punjab Belt',
    keyYield: 'High twin-kidding rate + 1.5 – 2.2 L milk/day (Beetal) + fast meat growth',
    bestSuitedFor: 'Nomadic alpine grazing as well as stall-fed semi-intensive units',
    managementTip: 'Supplement pregnant does with mineral bricks and urea-molasses blocks in winter.',
  },
  {
    id: 'brd-sahiwal',
    species: 'Dairy Cattle',
    breedName: 'Crossbred Jersey / HF & Indigenous Sahiwal',
    originRegion: 'All-India Plains & Mid-Hill J&K Blocks',
    keyYield: '10 – 18 Litres / day (Crossbred) · High A2 Fat 4.8% (Sahiwal)',
    bestSuitedFor: 'Jersey/Sahiwal fit hill terrain & heat resilience; HF ideal for high-output sheds',
    managementTip: 'Use Sex-Sorted Semen AI via MAITRI worker for 90% female heifer calves.',
  },
  {
    id: 'brd-murrah',
    species: 'Buffalo',
    breedName: 'Murrah & Nili-Ravi Buffalo',
    originRegion: 'Punjab, Haryana, Jammu Plains & UP',
    keyYield: '12 – 18 Litres / day with 7%+ butterfat',
    bestSuitedFor: 'Plains commercial dairy, khoya/ghee production & high-fat cooperatives',
    managementTip: 'Provide shaded wallowing/sprinklers in May–July to prevent silent heat.',
  },
  {
    id: 'brd-vanaraja',
    species: 'Poultry',
    breedName: 'Vanaraja, Gramapriya & Chabro',
    originRegion: 'ICAR-DPR All-India Backyard Adaptation',
    keyYield: '110 – 160 brown eggs / year + hardy backyard foraging meat weight',
    bestSuitedFor: 'Low-cost rural household nutrition & Women SHG micro-enterprises',
    managementTip: 'Purchase 4-week brooded chicks from Govt. Poultry Farms; give Lasota Ranikhet eye-drop.',
  },
];

export const VETERINARY_CENTRES: VeterinaryCentreItem[] = [
  {
    id: 'vet-mvu',
    wing: 'Mobile Vet / Helpline',
    name: 'Toll-Free 1962 Pashu Chikitsa Mobile Veterinary Unit (MVU)',
    district: 'All India & J&K',
    blockLocation: 'Doorstep GPS-Tracked Van Dispatch',
    services: ['Emergency Sick-Animal Treatment', 'Calving Assistance', 'Sample Collection', 'On-Spot Medicine'],
    contact: '1962 (Toll-Free)',
    timing: '8:00 AM – 6:00 PM / Emergency Triage',
  },
  {
    id: 'vet-bhaderwah-sec',
    wing: 'Sheep Husbandry',
    name: 'Sheep Extension Centre (SEC) & Sub-Divisional Sheep Office, Bhaderwah',
    district: 'Bhaderwah',
    blockLocation: 'Chinta & Bhaderwah Town',
    services: ['Flock Deworming & Dipping', 'Free ET/PPR/Sheep Pox Vaccination', 'ISDS / NLM Unit Verification', 'High-Merit Breeding Rams'],
    contact: '01997-244190',
    timing: '9:30 AM – 4:30 PM',
  },
  {
    id: 'vet-bhaderwah-ah',
    wing: 'Animal Husbandry',
    name: 'Sub-Divisional Veterinary Hospital (Animal Husbandry), Bhaderwah',
    district: 'Bhaderwah',
    blockLocation: 'Main Hospital Road, Bhaderwah',
    services: ['Livestock OPD & Surgery', 'Frozen Semen Artificial Insemination', 'Pashu Aadhaar Tagging', 'KCC Livestock Stamp'],
    contact: '01997-244265',
    timing: '9:00 AM – 4:00 PM',
  },
  {
    id: 'vet-doda-caho',
    wing: 'Animal Husbandry',
    name: 'Chief Animal Husbandry Officer (CAHO) & District Vet Hospital, Doda',
    district: 'Doda',
    blockLocation: 'Doda District HQ',
    services: ['IDDS & HADP Dairy Approval', 'Disease Diagnostic Lab', 'FMD/HS Vaccination Hub'],
    contact: '01996-233412',
    timing: '10:00 AM – 4:00 PM',
  },
  {
    id: 'vet-baramulla-dsho',
    wing: 'Sheep Husbandry',
    name: 'District Sheep Husbandry Officer (DSHO) & Mutton Cluster Hub, Baramulla',
    district: 'Baramulla',
    blockLocation: 'Baramulla & Sopore Blocks',
    services: ['NLM & ISDS Project Screening', 'Machine Shearing Kits', 'Highland Pasture Transit Camps'],
    contact: '01952-234388',
    timing: '10:00 AM – 4:00 PM',
  },
];
