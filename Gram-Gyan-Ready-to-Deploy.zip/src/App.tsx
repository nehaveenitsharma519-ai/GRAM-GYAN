import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Bell,
  BookOpen,
  Briefcase,
  Building2,
  Camera,
  CloudRain,
  FileText,
  Globe2,
  GraduationCap,
  HeartPulse,
  Home as HomeIcon,
  Landmark,
  Languages,
  Layers,
  LogIn,
  LogOut,
  MapPin,
  Mic,
  Moon,
  Newspaper,
  Plus,
  Scale,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sprout,
  Sun,
  Train,
  User,
  Users,
  Wallet,
  WifiOff,
  X,
} from 'lucide-react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { AuthModal } from './components/AuthModal';
import { BookCoverArt } from './components/BookCoverArt';
import { BookReaderModal } from './components/BookReaderModal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { GeminiChatbotDrawer } from './components/GeminiChatbotDrawer';
import { ModulesViews } from './components/ModulesViews';
import { AdminPortalView } from './components/AdminPortalView';
import { ProfileAndSetupView } from './components/ProfileAndSetupView';
import { VillageCentresView } from './components/VillageCentresView';
import { NewVillageDraft, VillageDirectoryPanel } from './components/VillageDirectoryPanel';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ChatProvider } from './contexts/ChatContext';
import {
  INITIAL_BOOKS,
  INITIAL_JOBS,
  INITIAL_NEWS,
  INITIAL_SCHEMES,
  INITIAL_NOTICES,
  JK_DISTRICTS,
  MODULES_LIST,
  WEATHER_FORECASTS,
} from './data/gramGyanData';
import { WORLD_AND_INDIA_VILLAGES } from './data/villagesData';
import { LANGUAGES, TRANSLATIONS } from './data/translations';
import { db, handleFirestoreError, OperationType } from './firebase';
import {
  BookNote,
  BottomNavTab,
  ContentStatus,
  GovernmentScheme,
  GrievanceTicket,
  JobNotification,
  LanguageCode,
  LibraryResource,
  ModuleId,
  PanchayatNotice,
  ProductMode,
  UserLocation,
  VillageEntry,
  VillageRegion,
  WeeklyReadingStat,
} from './types/gramGyan';

const DEFAULT_WEEKLY_STATS: WeeklyReadingStat[] = [
  { weekId: '2026-W42', weekLabel: 'Oct 12', booksFinished: 1, minutesRead: 95, sessionsCount: 4 },
  { weekId: '2026-W43', weekLabel: 'Oct 19', booksFinished: 2, minutesRead: 140, sessionsCount: 6 },
  { weekId: '2026-W44', weekLabel: 'Oct 26', booksFinished: 1, minutesRead: 115, sessionsCount: 5 },
  { weekId: '2026-W45', weekLabel: 'Nov 02', booksFinished: 3, minutesRead: 210, sessionsCount: 8 },
  { weekId: '2026-W46', weekLabel: 'Nov 09', booksFinished: 2, minutesRead: 175, sessionsCount: 7 },
  { weekId: '2026-W47', weekLabel: 'Nov 16', booksFinished: 1, minutesRead: 130, sessionsCount: 5 },
];

const MODULE_ICONS: Record<ModuleId, React.FC<{ className?: string }>> = {
  library: BookOpen,
  education: GraduationCap,
  career: Layers,
  skills: Languages,
  schemes: Landmark,
  panchayat: Building2,
  documents: FileText,
  rights: Scale,
  farming: Sprout,
  business: ShoppingBag,
  jobs: Briefcase,
  banking: Wallet,
  health: HeartPulse,
  weather: CloudRain,
  transport: Train,
  marketplace: ShoppingBag,
  news: Newspaper,
  women_child: Users,
  senior_citizen: User,
  ai_assistant: Mic,
  animal_husbandry: ShieldCheck,
};

function readLocalJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

const GramGyanShell: React.FC<{
  language: LanguageCode;
  setLanguage: (l: LanguageCode) => void;
  location: UserLocation;
  setLocation: (loc: UserLocation) => void;
}> = ({ language, setLanguage, location, setLocation }) => {
  const { user, cloudProfile, logout, syncUserPreferences } = useAuth();
  const t = TRANSLATIONS[language];

  // App Modes & Navigation
  const [productMode, setProductMode] = useState<ProductMode>('citizen');
  const [activeTab, setActiveTab] = useState<BottomNavTab>('home');
  const [activeModule, setActiveModule] = useState<ModuleId | null>(null);

  // Preferences & Accessibility
  const [darkMode, setDarkMode] = useState<boolean>(() => readLocalJson('gg_dark', false));
  const [textScale, setTextScale] = useState<'normal' | 'large' | 'xlarge'>(() =>
    readLocalJson('gg_text_scale', 'normal')
  );
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [lowDataMode, setLowDataMode] = useState<boolean>(() => readLocalJson('gg_low_data', false));

  // Content Data (editable live via Admin Control Centre)
  const [books, setBooks] = useState<LibraryResource[]>(INITIAL_BOOKS);
  const [schemes, setSchemes] = useState<GovernmentScheme[]>(INITIAL_SCHEMES);
  const [jobs, setJobs] = useState<JobNotification[]>(INITIAL_JOBS);
  const [notices, setNotices] = useState<PanchayatNotice[]>(INITIAL_NOTICES);
  const [news] = useState(INITIAL_NEWS);

  // User Saved State (synced locally + Firestore when verified user signs in)
  const [bookmarkedBookIds, setBookmarkedBookIds] = useState<string[]>(() =>
    readLocalJson('gg_bookmarks', ['bk-gk-2026'])
  );
  const [downloadedBookIds, setDownloadedBookIds] = useState<string[]>(() =>
    readLocalJson('gg_downloads', ['bk-gk-2026', 'bk-apple-orchard'])
  );
  const [savedSchemeIds, setSavedSchemeIds] = useState<string[]>(() =>
    readLocalJson('gg_saved_schemes', ['sch-pm-kisan'])
  );
  const [readingProgress, setReadingProgress] = useState<Record<string, number>>(() =>
    readLocalJson('gg_reading_progress', {})
  );
  const [localNotes, setLocalNotes] = useState<BookNote[]>(() => readLocalJson('gg_notes', []));
  const [cloudNotes, setCloudNotes] = useState<BookNote[]>([]);
  const [localGrievances, setLocalGrievances] = useState<GrievanceTicket[]>(() =>
    readLocalJson('gg_grievances', [
      {
        id: 'tkt-sample-1',
        citizenName: 'Mohd. Yousuf',
        district: 'Baramulla',
        category: 'Book Request',
        message: 'Please add Class 10 JKBOSE Urdu & Kashmiri sample papers for offline reading.',
        submittedAt: '18 Nov 2026',
        status: 'In Progress',
      },
    ])
  );
  const [cloudGrievances, setCloudGrievances] = useState<GrievanceTicket[]>([]);
  const [finishedBookIds, setFinishedBookIds] = useState<string[]>(() =>
    readLocalJson('gg_finished_books', ['bk-children-story', 'bk-gramin-samachar'])
  );
  const [localReadingStats, setLocalReadingStats] = useState<WeeklyReadingStat[]>(() =>
    readLocalJson('gg_reading_stats', DEFAULT_WEEKLY_STATS)
  );
  const [cloudReadingStats, setCloudReadingStats] = useState<WeeklyReadingStat[]>([]);
  const [localCustomVillages, setLocalCustomVillages] = useState<VillageEntry[]>(() =>
    readLocalJson('gg_custom_villages_v1', [])
  );
  const [cloudCustomVillages, setCloudCustomVillages] = useState<VillageEntry[]>([]);

  // Overlays & Search
  const [universalQuery, setUniversalQuery] = useState('');
  const [readerBook, setReaderBook] = useState<LibraryResource | null>(null);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [villageModalState, setVillageModalState] = useState<{ open: boolean; openAddForm: boolean }>({
    open: false,
    openAddForm: false,
  });

  // Apply Dark Mode & Accessibility Text Scale on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
    localStorage.setItem('gg_dark', JSON.stringify(darkMode));
  }, [darkMode]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('text-scale-large', 'text-scale-xlarge');
    if (textScale === 'large') root.classList.add('text-scale-large');
    if (textScale === 'xlarge') root.classList.add('text-scale-xlarge');
    localStorage.setItem('gg_text_scale', JSON.stringify(textScale));
  }, [textScale]);

  useEffect(() => {
    localStorage.setItem('gg_low_data', JSON.stringify(lowDataMode));
  }, [lowDataMode]);

  useEffect(() => {
    localStorage.setItem('gg_bookmarks', JSON.stringify(bookmarkedBookIds));
  }, [bookmarkedBookIds]);

  useEffect(() => {
    localStorage.setItem('gg_downloads', JSON.stringify(downloadedBookIds));
  }, [downloadedBookIds]);

  useEffect(() => {
    localStorage.setItem('gg_saved_schemes', JSON.stringify(savedSchemeIds));
  }, [savedSchemeIds]);

  useEffect(() => {
    localStorage.setItem('gg_reading_progress', JSON.stringify(readingProgress));
  }, [readingProgress]);

  useEffect(() => {
    localStorage.setItem('gg_notes', JSON.stringify(localNotes));
  }, [localNotes]);

  useEffect(() => {
    localStorage.setItem('gg_grievances', JSON.stringify(localGrievances));
  }, [localGrievances]);

  useEffect(() => {
    localStorage.setItem('gg_finished_books', JSON.stringify(finishedBookIds));
  }, [finishedBookIds]);

  useEffect(() => {
    localStorage.setItem('gg_reading_stats', JSON.stringify(localReadingStats));
  }, [localReadingStats]);

  useEffect(() => {
    localStorage.setItem('gg_custom_villages_v1', JSON.stringify(localCustomVillages));
  }, [localCustomVillages]);

  // Hydrate preferences from Firestore profile when signed in
  useEffect(() => {
    if (!cloudProfile) return;
    setLanguage(cloudProfile.language);
    if (cloudProfile.district === 'Kathua') {
      setLocation({
        state: cloudProfile.state || 'Jammu & Kashmir',
        district: 'Bhaderwah',
        block: 'Bhaderwah',
        panchayat: 'Chinta',
      });
    } else {
      setLocation({
        state: cloudProfile.state,
        district: cloudProfile.district,
        block: cloudProfile.block,
        panchayat: cloudProfile.panchayat,
      });
    }
    if (cloudProfile.savedBookIds?.length) setBookmarkedBookIds(cloudProfile.savedBookIds);
    if (cloudProfile.downloadedBookIds?.length) setDownloadedBookIds(cloudProfile.downloadedBookIds);
    if (cloudProfile.savedSchemeIds?.length) setSavedSchemeIds(cloudProfile.savedSchemeIds);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cloudProfile?.uid]);

  // Subscribe to Firestore notes & grievances for verified signed-in user
  useEffect(() => {
    if (!user || !user.emailVerified) {
      setCloudNotes([]);
      setCloudGrievances([]);
      setCloudReadingStats([]);
      return;
    }

    const notesPath = `users/${user.uid}/notes`;
    const notesQuery = query(collection(db, 'users', user.uid, 'notes'), orderBy('createdAt', 'desc'));
    const unsubNotes = onSnapshot(
      notesQuery,
      (snap) => {
        const items: BookNote[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            bookId: String(data.bookId || ''),
            chapterIndex: Number(data.chapterIndex || 0),
            text: String(data.text || ''),
            createdAt: 'Synced',
          };
        });
        setCloudNotes(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, notesPath);
      }
    );

    const grievancePath = 'grievances';
    const isAdminUser = user.email === 'nehaveenitsharma519@gmail.com';
    const grievanceQuery = isAdminUser
      ? query(collection(db, 'grievances'))
      : query(collection(db, 'grievances'), where('ownerId', '==', user.uid));

    const unsubGrievances = onSnapshot(
      grievanceQuery,
      (snap) => {
        const items: GrievanceTicket[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            citizenName: String(data.citizenName || 'Citizen'),
            district: String(data.district || 'Bhaderwah'),
            category: String(data.category || 'Support'),
            message: String(data.message || ''),
            submittedAt: 'Cloud Synced',
            status: (data.status as GrievanceTicket['status']) || 'Open',
          };
        });
        setCloudGrievances(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, grievancePath);
      }
    );

    const statsPath = `users/${user.uid}/readingStats`;
    const statsQuery = query(collection(db, 'users', user.uid, 'readingStats'));
    const unsubStats = onSnapshot(
      statsQuery,
      (snap) => {
        const items: WeeklyReadingStat[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              weekId: String(data.weekId || d.id),
              weekLabel: String(data.weekLabel || d.id),
              booksFinished: Number(data.booksFinished || 0),
              minutesRead: Number(data.minutesRead || 0),
              sessionsCount: Number(data.sessionsCount || 0),
            };
          })
          .sort((a, b) => a.weekId.localeCompare(b.weekId));
        setCloudReadingStats(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, statsPath);
      }
    );

    const villagesPath = `users/${user.uid}/villages`;
    const villagesQuery = query(collection(db, 'users', user.uid, 'villages'), orderBy('createdAt', 'desc'));
    const unsubVillages = onSnapshot(
      villagesQuery,
      (snap) => {
        const items: VillageEntry[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            name: String(data.name || ''),
            blockOrTehsil: String(data.blockOrTehsil || ''),
            district: String(data.district || ''),
            stateOrProvince: String(data.stateOrProvince || ''),
            country: String(data.country || 'India'),
            region: (data.region as VillageRegion) || 'All India',
            populationApprox: String(data.populationApprox || ''),
            highlights: String(data.highlights || ''),
            isCustom: true,
          };
        });
        setCloudCustomVillages(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, villagesPath);
      }
    );

    return () => {
      unsubNotes();
      unsubGrievances();
      unsubStats();
      unsubVillages();
    };
  }, [user, user?.emailVerified]);

  const activeNotes = user && user.emailVerified ? cloudNotes : localNotes;
  const activeGrievances = user && user.emailVerified ? [...cloudGrievances, ...localGrievances] : localGrievances;
  const activeReadingStats = useMemo(() => {
    if (!user || !user.emailVerified || cloudReadingStats.length === 0) {
      return localReadingStats;
    }
    const merged = new Map<string, WeeklyReadingStat>();
    for (const s of localReadingStats) merged.set(s.weekId, s);
    for (const s of cloudReadingStats) merged.set(s.weekId, s);
    return Array.from(merged.values()).sort((a, b) => a.weekId.localeCompare(b.weekId));
  }, [user, cloudReadingStats, localReadingStats]);

  const allVillages = useMemo(() => {
    const custom =
      user && user.emailVerified
        ? [...cloudCustomVillages, ...localCustomVillages]
        : localCustomVillages;
    const seen = new Set<string>();
    const merged: VillageEntry[] = [];
    for (const v of [...custom, ...WORLD_AND_INDIA_VILLAGES]) {
      const key = `${v.name.toLowerCase()}::${v.district.toLowerCase()}::${v.country.toLowerCase()}`;
      if (seen.has(key)) continue;
      seen.add(key);
      merged.push(v);
    }
    return merged;
  }, [user, cloudCustomVillages, localCustomVillages]);

  const handleLanguageChange = (nextLang: LanguageCode) => {
    setLanguage(nextLang);
    localStorage.setItem('gg_lang', JSON.stringify(nextLang));
    if (user && user.emailVerified) {
      void syncUserPreferences({ language: nextLang });
    }
  };

  const handleLocationChange = (nextLoc: UserLocation) => {
    setLocation(nextLoc);
    localStorage.setItem('gg_location', JSON.stringify(nextLoc));
    if (user && user.emailVerified) {
      void syncUserPreferences({
        state: nextLoc.state,
        district: nextLoc.district,
        block: nextLoc.block,
        panchayat: nextLoc.panchayat,
      });
    }
  };

  const handleSelectVillage = (village: VillageEntry) => {
    const stateLabel =
      village.country === 'India'
        ? village.stateOrProvince
        : `${village.stateOrProvince}, ${village.country}`;
    handleLocationChange({
      state: stateLabel.slice(0, 80),
      district: village.district.slice(0, 80),
      block: village.blockOrTehsil.slice(0, 80),
      panchayat: village.name.slice(0, 80),
    });
  };

  const handleAddVillage = async (draft: NewVillageDraft, setAsActive: boolean) => {
    const cleanEntry: VillageEntry = {
      id: `vil-custom-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: draft.name.trim().slice(0, 80),
      blockOrTehsil: (draft.blockOrTehsil.trim() || draft.name.trim()).slice(0, 80),
      district: draft.district.trim().slice(0, 80),
      stateOrProvince: draft.stateOrProvince.trim().slice(0, 80),
      country: draft.country.trim().slice(0, 80),
      region: draft.region,
      populationApprox: draft.populationApprox.trim().slice(0, 40),
      highlights: draft.highlights.trim().slice(0, 300),
      isCustom: true,
    };

    if (user && user.emailVerified) {
      const path = `users/${user.uid}/villages`;
      try {
        await addDoc(collection(db, 'users', user.uid, 'villages'), {
          ownerId: user.uid,
          name: cleanEntry.name,
          blockOrTehsil: cleanEntry.blockOrTehsil,
          district: cleanEntry.district,
          stateOrProvince: cleanEntry.stateOrProvince,
          country: cleanEntry.country,
          region: cleanEntry.region,
          populationApprox: cleanEntry.populationApprox,
          highlights: cleanEntry.highlights,
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, path);
      }
    } else {
      setLocalCustomVillages((prev) => [cleanEntry, ...prev]);
    }

    if (setAsActive) {
      handleSelectVillage(cleanEntry);
    }
  };

  const handleDeleteCustomVillage = async (villageId: string) => {
    const isCloud = cloudCustomVillages.some((v) => v.id === villageId);
    if (isCloud && user && user.emailVerified) {
      const path = `users/${user.uid}/villages/${villageId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'villages', villageId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, path);
      }
      return;
    }
    setLocalCustomVillages((prev) => prev.filter((v) => v.id !== villageId));
  };

  const handleToggleBookmark = (bookId: string) => {
    const next = bookmarkedBookIds.includes(bookId)
      ? bookmarkedBookIds.filter((id) => id !== bookId)
      : [...bookmarkedBookIds, bookId];
    setBookmarkedBookIds(next);
    if (user && user.emailVerified) {
      void syncUserPreferences({ savedBookIds: next });
    }
  };

  const handleToggleDownload = (bookId: string) => {
    const next = downloadedBookIds.includes(bookId)
      ? downloadedBookIds.filter((id) => id !== bookId)
      : [...downloadedBookIds, bookId];
    setDownloadedBookIds(next);
    if (user && user.emailVerified) {
      void syncUserPreferences({ downloadedBookIds: next });
    }
  };

  const handleToggleSaveScheme = (schemeId: string) => {
    const next = savedSchemeIds.includes(schemeId)
      ? savedSchemeIds.filter((id) => id !== schemeId)
      : [...savedSchemeIds, schemeId];
    setSavedSchemeIds(next);
    if (user && user.emailVerified) {
      void syncUserPreferences({ savedSchemeIds: next });
    }
  };

  const handleProgressChange = useCallback((bookId: string, chapterIndex: number) => {
    setReadingProgress((prev) => {
      if (prev[bookId] === chapterIndex) return prev;
      return { ...prev, [bookId]: chapterIndex };
    });
  }, []);

  const persistWeekStatToCloud = useCallback(
    async (stat: WeeklyReadingStat) => {
      if (!user || !user.emailVerified) return;
      const statRef = doc(db, 'users', user.uid, 'readingStats', stat.weekId);
      try {
        await setDoc(statRef, {
          ownerId: user.uid,
          weekId: stat.weekId,
          weekLabel: stat.weekLabel,
          booksFinished: stat.booksFinished,
          minutesRead: stat.minutesRead,
          sessionsCount: stat.sessionsCount,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/readingStats/${stat.weekId}`);
      }
    },
    [user]
  );

  const handleLogReadingMinutes = useCallback(
    (minutes: number) => {
      const currentWeekId = '2026-W47';
      const existingWeek = activeReadingStats.find((w) => w.weekId === currentWeekId) ?? {
        weekId: currentWeekId,
        weekLabel: 'Nov 16',
        booksFinished: 0,
        minutesRead: 0,
        sessionsCount: 0,
      };
      const updatedWeek: WeeklyReadingStat = {
        ...existingWeek,
        minutesRead: Math.min(10080, existingWeek.minutesRead + minutes),
        sessionsCount: Math.min(1000, existingWeek.sessionsCount + 1),
      };

      setLocalReadingStats((prev) => {
        const hasWeek = prev.some((w) => w.weekId === currentWeekId);
        return hasWeek
          ? prev.map((w) => (w.weekId === currentWeekId ? updatedWeek : w))
          : [...prev, updatedWeek];
      });
      void persistWeekStatToCloud(updatedWeek);
    },
    [activeReadingStats, persistWeekStatToCloud]
  );

  const handleMarkBookFinished = useCallback(
    (bookId: string) => {
      if (finishedBookIds.includes(bookId)) return;
      setFinishedBookIds((prev) => [...prev, bookId]);
      const currentWeekId = '2026-W47';
      const existingWeek = activeReadingStats.find((w) => w.weekId === currentWeekId) ?? {
        weekId: currentWeekId,
        weekLabel: 'Nov 16',
        booksFinished: 0,
        minutesRead: 0,
        sessionsCount: 0,
      };
      const updatedWeek: WeeklyReadingStat = {
        ...existingWeek,
        booksFinished: Math.min(500, existingWeek.booksFinished + 1),
      };

      setLocalReadingStats((prev) => {
        const hasWeek = prev.some((w) => w.weekId === currentWeekId);
        return hasWeek
          ? prev.map((w) => (w.weekId === currentWeekId ? updatedWeek : w))
          : [...prev, updatedWeek];
      });
      void persistWeekStatToCloud(updatedWeek);
    },
    [finishedBookIds, activeReadingStats, persistWeekStatToCloud]
  );

  const handleAddNote = async (bookId: string, chapterIndex: number, text: string) => {
    if (user && user.emailVerified) {
      const path = `users/${user.uid}/notes`;
      try {
        await addDoc(collection(db, 'users', user.uid, 'notes'), {
          ownerId: user.uid,
          bookId: bookId.slice(0, 100),
          chapterIndex,
          text: text.slice(0, 1000),
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, path);
      }
      return;
    }

    setLocalNotes((prev) => [
      {
        id: `note-${Date.now()}`,
        bookId,
        chapterIndex,
        text,
        createdAt: 'Today',
      },
      ...prev,
    ]);
  };

  const handleDeleteNote = async (noteId: string) => {
    if (user && user.emailVerified) {
      const path = `users/${user.uid}/notes/${noteId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'notes', noteId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, path);
      }
      return;
    }
    setLocalNotes((prev) => prev.filter((n) => n.id !== noteId));
  };

  const handleSubmitGrievance = async (category: string, message: string) => {
    if (user && user.emailVerified) {
      try {
        await addDoc(collection(db, 'grievances'), {
          ownerId: user.uid,
          citizenName: (user.displayName || user.email || 'Citizen').slice(0, 100),
          district: location.district.slice(0, 80),
          category: category.slice(0, 80),
          message: message.slice(0, 1500),
          status: 'Open',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'grievances');
      }
    }

    setLocalGrievances((prev) => [
      {
        id: `tkt-${Date.now()}`,
        citizenName: user?.displayName || 'Guest Citizen',
        district: location.district,
        category,
        message,
        submittedAt: 'Today',
        status: 'Open',
      },
      ...prev,
    ]);
  };

  const handleUpdateGrievanceStatus = async (id: string, status: GrievanceTicket['status']) => {
    const isCloud = cloudGrievances.some((g) => g.id === id);
    if (isCloud && user && user.emailVerified) {
      try {
        await updateDoc(doc(db, 'grievances', id), {
          status,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `grievances/${id}`);
      }
      return;
    }
    setLocalGrievances((prev) => prev.map((g) => (g.id === id ? { ...g, status } : g)));
  };

  const handleUpdateItemStatus = (
    kind: 'book' | 'scheme' | 'job' | 'notice',
    id: string,
    status: ContentStatus
  ) => {
    if (kind === 'book') setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, status } : b)));
    if (kind === 'scheme') setSchemes((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));
    if (kind === 'job') setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, status } : j)));
    if (kind === 'notice') setNotices((prev) => prev.map((n) => (n.id === id ? { ...n, status } : n)));
  };

  const navigateToModule = (modId: ModuleId) => {
    setProductMode('citizen');
    setActiveModule(modId);
    if (modId === 'library') setActiveTab('read');
    else if (modId === 'panchayat') setActiveTab('village');
    else setActiveTab('services');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBottomTabClick = (tab: BottomNavTab) => {
    setProductMode('citizen');
    setActiveTab(tab);
    if (tab === 'home') setActiveModule(null);
    else if (tab === 'read') setActiveModule('library');
    else if (tab === 'services') setActiveModule('schemes');
    else if (tab === 'village') setActiveModule('panchayat');
    else if (tab === 'profile') setActiveModule(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Universal Search Results across books, schemes, jobs, modules
  const universalResults = useMemo(() => {
    const q = universalQuery.trim().toLowerCase();
    if (!q) return null;
    return {
      modules: MODULES_LIST.filter(
        (m) => m.title.toLowerCase().includes(q) || m.shortDesc.toLowerCase().includes(q)
      ),
      books: books.filter(
        (b) => b.title.toLowerCase().includes(q) || b.category.toLowerCase().includes(q)
      ),
      schemes: schemes.filter(
        (s) => s.title.toLowerCase().includes(q) || s.benefitSummary.toLowerCase().includes(q)
      ),
      jobs: jobs.filter(
        (j) => j.title.toLowerCase().includes(q) || j.organization.toLowerCase().includes(q)
      ),
    };
  }, [universalQuery, books, schemes, jobs]);

  const districtWeather =
    WEATHER_FORECASTS.find((w) => w.district === location.district) ?? WEATHER_FORECASTS[0];

  const groupedModules = useMemo(() => {
    const groups: Record<string, typeof MODULES_LIST> = {};
    for (const mod of MODULES_LIST) {
      if (!groups[mod.category]) groups[mod.category] = [];
      groups[mod.category].push(mod);
    }
    return Object.entries(groups);
  }, []);

  return (
    <ChatProvider language={language} district={location.district} isOffline={isOffline}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20 md:pb-8">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => handleBottomTabClick('home')}
            className="font-display font-bold text-lg sm:text-xl tracking-tight text-emerald-800 dark:text-emerald-400 whitespace-nowrap shrink-0"
          >
            GRAM GYAN
          </button>

          {/* Zone 2: 5 concise single-line text nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
            {[
              { id: 'home' as const, label: t.navHome },
              { id: 'read' as const, label: t.navRead },
              { id: 'services' as const, label: t.navServices },
              { id: 'village' as const, label: t.navVillage },
              { id: 'profile' as const, label: t.navProfile },
            ].map((item) => {
              const active = productMode === 'citizen' && activeTab === item.id && (item.id !== 'home' || !activeModule);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleBottomTabClick(item.id)}
                  className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 ${
                    active
                      ? 'text-emerald-800 dark:text-emerald-400 border-emerald-700'
                      : 'border-transparent hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary Auth / Account action */}
          <div className="flex items-center shrink-0">
            {user ? (
              <button
                type="button"
                onClick={() => void logout()}
                className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                Log Out ({(user.displayName || user.email || 'User').split(' ')[0]})
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setAuthModalMode('login')}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
              >
                <LogIn className="w-3.5 h-3.5" />
                Log In / Sign Up
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Workspace Toolbar (Product Switcher, Location, Language, Offline & Theme) */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
          {/* 3-Product Ecosystem Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs">
            {[
              { id: 'citizen' as const, label: 'Citizen App' },
              { id: 'admin' as const, label: 'Control Centre' },
              { id: 'centres' as const, label: 'Village Centres' },
            ].map((mode) => (
              <button
                key={mode.id}
                type="button"
                onClick={() => setProductMode(mode.id)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  productMode === mode.id
                    ? 'bg-white dark:bg-slate-950 text-emerald-700 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {mode.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 flex-wrap text-xs">
            <button
              type="button"
              onClick={() => setVillageModalState({ open: true, openAddForm: false })}
              className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-emerald-600 inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
              {location.panchayat}, {location.district}
            </button>

            <button
              type="button"
              onClick={() => setVillageModalState({ open: true, openAddForm: true })}
              className="min-h-[36px] px-2.5 py-1.5 rounded-lg bg-emerald-700 text-white hover:bg-emerald-800 inline-flex items-center gap-1 whitespace-nowrap font-medium transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Village
            </button>

            <button
              type="button"
              onClick={() => navigateToModule('farming')}
              className="min-h-[36px] px-2.5 py-1.5 rounded-lg border border-emerald-700 text-emerald-800 dark:text-emerald-300 dark:border-emerald-500/60 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 inline-flex items-center gap-1.5 whitespace-nowrap font-medium transition-colors"
            >
              <Camera className="w-3.5 h-3.5" />
              Crop AI Camera
            </button>

            <select
              value={language}
              onChange={(e) => handleLanguageChange(e.target.value as LanguageCode)}
              aria-label="Select application language"
              className="min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-medium"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="dark:bg-slate-900">
                  {l.nativeLabel}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => setIsOffline((v) => !v)}
              className={`min-h-[36px] px-2.5 py-1.5 rounded-lg border inline-flex items-center gap-1.5 whitespace-nowrap ${
                isOffline
                  ? 'bg-amber-600 text-white border-amber-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              <WifiOff className="w-3.5 h-3.5" />
              {isOffline ? t.offlineLabel : t.onlineLabel}
            </button>

            <button
              type="button"
              onClick={() => setShowNotifications((v) => !v)}
              aria-label="Toggle village notifications"
              className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Bell className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label="Toggle dark mode"
              className="min-h-[36px] min-w-[36px] rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Notifications Drawer */}
      {showNotifications && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-display font-semibold text-sm">
                District Alerts & Notifications ({location.district})
              </span>
              <button
                type="button"
                onClick={() => setShowNotifications(false)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                <div className="font-semibold">Weather · {districtWeather.district}</div>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5">{districtWeather.alertMessage}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                <div className="font-semibold">JKSSB Vacancy Closing Soon</div>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5">
                  Junior Assistant & Patwari applications close on 12 Dec 2026.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                <div className="font-semibold">Offline Library Synced</div>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5">
                  {downloadedBookIds.length} books saved locally for zero-internet reading.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Canvas */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
        {productMode === 'admin' && (
          <AdminPortalView
            books={books}
            schemes={schemes}
            jobs={jobs}
            notices={notices}
            grievances={activeGrievances}
            onUpdateItemStatus={handleUpdateItemStatus}
            onAddScheme={(s) => setSchemes((prev) => [s, ...prev])}
            onAddJob={(j) => setJobs((prev) => [j, ...prev])}
            onAddNotice={(n) => setNotices((prev) => [n, ...prev])}
            onUpdateGrievanceStatus={handleUpdateGrievanceStatus}
          />
        )}

        {productMode === 'centres' && (
          <VillageCentresView
            villages={allVillages}
            currentLocation={location}
            isCloudSynced={Boolean(user && user.emailVerified)}
            onSelectDistrict={(dist) => {
              const info = JK_DISTRICTS[dist] ?? JK_DISTRICTS.Bhaderwah;
              const blk = info.blocks[0];
              handleLocationChange({
                state: 'Jammu & Kashmir',
                district: dist,
                block: blk,
                panchayat: info.panchayats[blk]?.[0] ?? 'Main Panchayat',
              });
              setProductMode('citizen');
              setActiveTab('home');
              setActiveModule(null);
            }}
            onSelectVillage={(v) => {
              handleSelectVillage(v);
              setProductMode('citizen');
              setActiveTab('home');
              setActiveModule(null);
            }}
            onAddVillage={handleAddVillage}
            onDeleteCustomVillage={handleDeleteCustomVillage}
          />
        )}

        {productMode === 'citizen' && activeTab === 'profile' && !activeModule && (
          <ProfileAndSetupView
            language={language}
            location={location}
            darkMode={darkMode}
            textScale={textScale}
            isOffline={isOffline}
            lowDataMode={lowDataMode}
            books={books}
            schemes={schemes}
            bookmarkedBookIds={bookmarkedBookIds}
            downloadedBookIds={downloadedBookIds}
            savedSchemeIds={savedSchemeIds}
            grievances={activeGrievances}
            readingStats={activeReadingStats}
            finishedBookIds={finishedBookIds}
            onLogReadingMinutes={handleLogReadingMinutes}
            onLanguageChange={handleLanguageChange}
            onLocationChange={handleLocationChange}
            onDarkModeChange={setDarkMode}
            onTextScaleChange={setTextScale}
            onToggleOffline={() => setIsOffline((v) => !v)}
            onToggleLowData={() => setLowDataMode((v) => !v)}
            onOpenBook={setReaderBook}
            onRemoveDownload={handleToggleDownload}
            onSubmitGrievance={handleSubmitGrievance}
            onOpenAuth={(mode) => setAuthModalMode(mode)}
            villages={allVillages}
            onOpenVillageModal={(openAdd = false) =>
              setVillageModalState({ open: true, openAddForm: openAdd })
            }
            onSelectVillage={handleSelectVillage}
          />
        )}

        {productMode === 'citizen' && activeModule && (
          <div className="space-y-4">
            {/* Module Switcher Breadcrumb Strip */}
            <div className="flex items-center justify-between flex-wrap gap-3">
              <button
                type="button"
                onClick={() => {
                  setActiveModule(null);
                  setActiveTab('home');
                }}
                className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
              >
                ← Back to Home Dashboard
              </button>

              <select
                value={activeModule}
                onChange={(e) => navigateToModule(e.target.value as ModuleId)}
                aria-label="Jump to any of the 21 GRAM GYAN modules"
                className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium"
              >
                {MODULES_LIST.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.number}. {m.title}
                  </option>
                ))}
              </select>
            </div>

            <ModulesViews
              activeModule={activeModule}
              language={language}
              district={location.district}
              isOffline={isOffline}
              lowDataMode={lowDataMode}
              books={books}
              schemes={schemes}
              jobs={jobs}
              notices={notices}
              news={news}
              bookmarkedBookIds={bookmarkedBookIds}
              downloadedBookIds={downloadedBookIds}
              savedSchemeIds={savedSchemeIds}
              textScale={textScale}
              onLanguageChange={handleLanguageChange}
              onOpenBook={setReaderBook}
              onToggleBookmark={handleToggleBookmark}
              onToggleDownload={handleToggleDownload}
              onToggleSaveScheme={handleToggleSaveScheme}
              onTextScaleChange={setTextScale}
              onSelectModule={navigateToModule}
              villages={allVillages}
              currentLocation={location}
              isCloudSynced={Boolean(user && user.emailVerified)}
              onSelectVillage={handleSelectVillage}
              onAddVillage={handleAddVillage}
              onDeleteCustomVillage={handleDeleteCustomVillage}
            />
          </div>
        )}

        {/* Home Dashboard (Screen 6) */}
        {productMode === 'citizen' && !activeModule && activeTab !== 'profile' && (
          <div className="space-y-8">
            {/* Hero Focal Anchor + Today's Village Update */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between gap-6">
                <div className="space-y-3">
                  <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                    {t.tagline} · Jammu & Kashmir Pilot ({location.district})
                  </p>
                  <h1 className="font-display font-bold text-3xl sm:text-4xl leading-tight text-balance">
                    {t.greeting}
                  </h1>
                  <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
                    {t.heroTitle} {t.heroSubtitle}
                  </p>
                </div>

                {/* Universal Search (Screen 7) */}
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={universalQuery}
                      onChange={(e) => setUniversalQuery(e.target.value)}
                      placeholder={t.searchPlaceholder}
                      className="w-full min-h-[48px] pl-11 pr-10 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                    {universalQuery && (
                      <button
                        type="button"
                        onClick={() => setUniversalQuery('')}
                        aria-label="Clear search"
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Universal Search Instant Results Dropdown */}
                  {universalResults && (
                    <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 space-y-3 text-xs">
                      <div className="font-semibold text-slate-700 dark:text-slate-200">
                        Search Results across GRAM GYAN
                      </div>
                      {universalResults.modules.length === 0 &&
                      universalResults.books.length === 0 &&
                      universalResults.schemes.length === 0 &&
                      universalResults.jobs.length === 0 ? (
                        <p className="text-slate-500">No matches found. Try asking the AI Village Assistant.</p>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {universalResults.modules.slice(0, 4).map((m) => (
                            <button
                              key={m.id}
                              type="button"
                              onClick={() => {
                                setUniversalQuery('');
                                navigateToModule(m.id);
                              }}
                              className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-left hover:border-emerald-600"
                            >
                              <div className="font-semibold">Module: {m.title}</div>
                              <div className="text-slate-500 truncate">{m.shortDesc}</div>
                            </button>
                          ))}
                          {universalResults.books.slice(0, 2).map((b) => (
                            <button
                              key={b.id}
                              type="button"
                              onClick={() => {
                                setUniversalQuery('');
                                setReaderBook(b);
                              }}
                              className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-left hover:border-emerald-600"
                            >
                              <div className="font-semibold">Book: {b.title}</div>
                              <div className="text-slate-500 truncate">{b.category}</div>
                            </button>
                          ))}
                          {universalResults.schemes.slice(0, 2).map((s) => (
                            <button
                              key={s.id}
                              type="button"
                              onClick={() => {
                                setUniversalQuery('');
                                navigateToModule('schemes');
                              }}
                              className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-left hover:border-emerald-600"
                            >
                              <div className="font-semibold">Scheme: {s.title}</div>
                              <div className="text-slate-500 truncate">{s.department}</div>
                            </button>
                          ))}
                          {universalResults.jobs.slice(0, 2).map((j) => (
                            <button
                              key={j.id}
                              type="button"
                              onClick={() => {
                                setUniversalQuery('');
                                navigateToModule('jobs');
                              }}
                              className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-left hover:border-emerald-600"
                            >
                              <div className="font-semibold">Job: {j.title}</div>
                              <div className="text-slate-500 truncate">{j.closingDate}</div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Single Primary Hero CTA + AI Assistant Trigger */}
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => navigateToModule('ai_assistant')}
                    className="min-h-[46px] px-5 py-2.5 rounded-xl bg-emerald-700 text-white text-sm font-medium hover:bg-emerald-800 inline-flex items-center gap-2 transition-colors"
                  >
                    <Mic className="w-4 h-4" />
                    {t.askAiCta}
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateToModule('library')}
                    className="min-h-[46px] px-5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-2 transition-colors"
                  >
                    <BookOpen className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                    Open Digital Library
                  </button>
                </div>
              </div>

              {/* Today's Village Update Card */}
              <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col justify-between gap-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display font-bold text-lg">{t.todaysUpdate}</h2>
                    <span className="font-mono text-xs text-slate-500">20 Nov 2026</span>
                  </div>

                  <div className="space-y-3 text-xs sm:text-sm">
                    <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-between font-semibold">
                        <span>{districtWeather.district} Weather</span>
                        <span className="font-mono tabular-nums">{districtWeather.tempC}°C</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                        {districtWeather.alertMessage}
                      </p>
                    </div>

                    <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
                      <div className="font-semibold">Latest Panchayat Notice</div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                        {notices[0]?.title} ({notices[0]?.district})
                      </p>
                    </div>

                    <div>
                      <div className="font-semibold">Sopore Apple Modal Rate</div>
                      <p className="text-xs text-emerald-700 dark:text-emerald-400 font-mono tabular-nums mt-1">
                        ₹6,100 / Quintal · AGMARKNET Verified
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => navigateToModule('weather')}
                  className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline inline-flex items-center gap-1"
                >
                  View Weather & Mandi Details <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </section>

            {/* Quick 12-Service Shortcuts from Blueprint Section 7 + All 20 Modules */}
            <section className="space-y-5">
              <div className="flex items-end justify-between flex-wrap gap-2">
                <div>
                  <h2 className="font-display font-bold text-2xl">{t.exploreServices}</h2>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                    All 21 modules organised into 5 citizen-first categories.
                  </p>
                </div>
                <span className="text-xs text-slate-500">{t.verifiedSourceNote}</span>
              </div>

              <div className="space-y-6">
                {groupedModules.map(([categoryName, items]) => (
                  <div key={categoryName} className="space-y-3">
                    <h3 className="font-display font-semibold text-base text-slate-800 dark:text-slate-200">
                      {categoryName}
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {items.map((mod) => {
                        const Icon = MODULE_ICONS[mod.id];
                        return (
                          <button
                            key={mod.id}
                            type="button"
                            onClick={() => navigateToModule(mod.id)}
                            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-600 dark:hover:border-emerald-500 rounded-2xl p-4 text-left transition-colors flex items-start gap-3.5 min-h-[84px]"
                          >
                            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                              <Icon className="w-5 h-5" />
                            </div>
                            <div className="min-w-0 space-y-1">
                              <div className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100 truncate">
                                {mod.number}. {mod.title}
                              </div>
                              <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                                {mod.shortDesc}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Recommended Reading Strip */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display font-bold text-2xl">{t.recommendedReading}</h2>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                    Read a little every day — free open-access books with offline download and read-aloud audio.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToModule('library')}
                  className="text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline whitespace-nowrap"
                >
                  Browse All Books →
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {books.slice(0, 4).map((book) => (
                  <div
                    key={book.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col justify-between gap-3"
                  >
                    <div className="space-y-3">
                      {!lowDataMode && <BookCoverArt book={book} compact />}
                      <div className="space-y-1">
                        <p className="text-[11px] text-slate-500">
                          {book.language} · {book.pages} pages
                        </p>
                        <h3 className="font-display font-semibold text-sm line-clamp-2">{book.title}</h3>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setReaderBook(book)}
                      className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 transition-colors"
                    >
                      Read Now
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}
      </main>

      {/* Clean Quiet Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 pb-8 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center justify-between gap-3">
        <span>GRAM GYAN — पढ़ेगा गांव, बढ़ेगा गांव · Jammu & Kashmir Pilot & All India</span>
        <span>Free Essential Citizen Knowledge · DPDP Act 2023 Compliant</span>
      </footer>

      {/* Mobile Fixed 5-Tab Bottom Navigation (< md, <= 15% sticky height cap) */}
      <nav
        aria-label="Primary Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 items-center"
      >
        {[
          { id: 'home' as const, label: t.navHome, Icon: HomeIcon },
          { id: 'read' as const, label: t.navRead, Icon: BookOpen },
          { id: 'services' as const, label: t.navServices, Icon: Layers },
          { id: 'village' as const, label: t.navVillage, Icon: Building2 },
          { id: 'profile' as const, label: t.navProfile, Icon: User },
        ].map(({ id, label, Icon }) => {
          const active = productMode === 'citizen' && activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => handleBottomTabClick(id)}
              className={`min-h-[48px] flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
                active ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="truncate max-w-[60px]">{label}</span>
            </button>
          );
        })}
      </nav>

      {/* Full Book Reader Modal (Screen 9) */}
      {readerBook && (
        <BookReaderModal
          book={readerBook}
          isBookmarked={bookmarkedBookIds.includes(readerBook.id)}
          isDownloaded={downloadedBookIds.includes(readerBook.id)}
          isFinished={finishedBookIds.includes(readerBook.id)}
          initialChapter={readingProgress[readerBook.id] ?? 0}
          notes={activeNotes}
          lowDataMode={lowDataMode}
          onClose={() => setReaderBook(null)}
          onToggleBookmark={handleToggleBookmark}
          onToggleDownload={handleToggleDownload}
          onMarkFinished={handleMarkBookFinished}
          onLogReadingMinutes={handleLogReadingMinutes}
          onProgressChange={handleProgressChange}
          onAddNote={handleAddNote}
          onDeleteNote={handleDeleteNote}
        />
      )}

      {/* Firebase Authentication Modal (Sign Up / Log In) */}
      {authModalMode && (
        <AuthModal initialMode={authModalMode} onClose={() => setAuthModalMode(null)} />
      )}

      {/* Global World & India Village Directory + Add Village Modal */}
      {villageModalState.open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="All Villages Directory & Add Village"
          className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-start sm:items-center justify-center p-3 sm:p-6 overflow-y-auto"
        >
          <div className="w-full max-w-5xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col">
            <div className="px-5 py-3.5 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2 font-display font-bold text-base">
                <Globe2 className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
                Select or Add a Village Worldwide
              </div>
              <button
                type="button"
                onClick={() => setVillageModalState({ open: false, openAddForm: false })}
                aria-label="Close village directory modal"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 sm:p-5 overflow-y-auto">
              <VillageDirectoryPanel
                key={villageModalState.openAddForm ? 'add-open' : 'browse'}
                villages={allVillages}
                currentLocation={location}
                isCloudSynced={Boolean(user && user.emailVerified)}
                initialShowAddForm={villageModalState.openAddForm}
                compactHeader
                onSelectVillage={(v) => {
                  handleSelectVillage(v);
                  setVillageModalState({ open: false, openAddForm: false });
                }}
                onAddVillage={handleAddVillage}
                onDeleteCustomVillage={handleDeleteCustomVillage}
              />
            </div>
          </div>
        </div>
      )}

      {/* Global Floating Multi-Turn Gemini Chatbot Drawer */}
      <GeminiChatbotDrawer language={language} district={location.district} />
    </div>
    </ChatProvider>
  );
};

export default function App() {
  const [language, setLanguage] = useState<LanguageCode>(() => readLocalJson('gg_lang', 'en'));
  const [location, setLocation] = useState<UserLocation>(() => {
    const stored = readLocalJson<UserLocation>('gg_location', {
      state: 'Jammu & Kashmir',
      district: 'Bhaderwah',
      block: 'Bhaderwah',
      panchayat: 'Chinta',
    });
    if (stored.district === 'Kathua') {
      return {
        state: 'Jammu & Kashmir',
        district: 'Bhaderwah',
        block: 'Bhaderwah',
        panchayat: 'Chinta',
      };
    }
    return stored;
  });

  return (
    <ErrorBoundary>
      <AuthProvider defaultLanguage={language} defaultLocation={location}>
        <GramGyanShell
          language={language}
          setLanguage={setLanguage}
          location={location}
          setLocation={setLocation}
        />
      </AuthProvider>
    </ErrorBoundary>
  );
}
