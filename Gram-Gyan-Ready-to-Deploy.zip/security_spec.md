# GRAM GYAN Firestore Security Specification

## 1. Data Invariants
1. A citizen profile (`/users/{userId}`) can only be created with `uid == request.auth.uid`, `role == 'citizen'`, and server timestamps (`createdAt == request.time`, `updatedAt == request.time`). Users cannot self-assign `admin` or `digital_mitra`.
2. PII (`email`, `phone`, `consentGiven`) is isolated in `/users/{userId}/private/info` and is never readable or listable by other users.
3. Book notes (`/users/{userId}/notes/{noteId}`) must have `ownerId == userId == request.auth.uid` and `text.size() <= 1000`.
4. Grievance tickets (`/grievances/{ticketId}`) must start with `status == 'Open'` and `ownerId == request.auth.uid`. Only an admin can transition a ticket out of `'Resolved'` or update ticket `status`.
5. Custom villages (`/users/{userId}/villages/{villageId}`) must have `ownerId == userId == request.auth.uid`, valid bounded string lengths (`<= 80` / `<= 300`), allowed `region` enum, and server `createdAt == request.time`.
6. No collection allows unauthenticated writes or unrestricted blanket `allow list`.

## 2. Adversarial Test Vectors ("Dirty Dozen")
1. Self-escalation: Creating `/users/{uid}` with `role: 'admin'`. -> `PERMISSION_DENIED`
2. Shadow field injection: Creating `/users/{uid}` with extra `isVerified: true` field. -> `PERMISSION_DENIED`
3. Cross-user profile read/write: User A reading `/users/UserB/private/info`. -> `PERMISSION_DENIED`
4. Spoofed ownerId on grievance: Creating `/grievances/t1` with `ownerId: 'victimUid'`. -> `PERMISSION_DENIED`
5. Terminal state bypass: Updating a `'Resolved'` grievance back to `'Open'` as non-admin. -> `PERMISSION_DENIED`
6. Fake timestamp injection: Creating `/grievances/t1` with backdated `createdAt`. -> `PERMISSION_DENIED`
7. Oversized payload DoS: Creating note with `text` > 1000 characters. -> `PERMISSION_DENIED`
8. ID poisoning: Writing `/grievances/../../../badId` (>128 chars or invalid chars). -> `PERMISSION_DENIED`
9. Unbounded array injection: Writing `savedBookIds` with >50 elements. -> `PERMISSION_DENIED`
10. Unverified email spoofing: Request with matching admin email where `email_verified == false`. -> `PERMISSION_DENIED`
11. Unrestricted list query: Listing `/grievances` without filtering by `ownerId == request.auth.uid` as non-admin. -> `PERMISSION_DENIED`
12. Immutable field tampering: Updating `uid` or `createdAt` on `/users/{uid}`. -> `PERMISSION_DENIED`
