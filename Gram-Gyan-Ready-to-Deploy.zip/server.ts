import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const VERIFIED_GROUNDING_CONTEXT = `
GRAM GYAN VERIFIED KNOWLEDGE BASE (Jammu & Kashmir Pilot + All India):
1. Government Schemes (Informational Guidance -> Official Portals):
   - PM-KISAN Samman Nidhi: Dept of Agriculture & Farmers Welfare. ₹6,000/year in 3 equal installments. Docs: Aadhaar, Land Records (Jamabandi/Khasra), Bank Account seeded with Aadhaar, e-KYC. Official: https://pmkisan.gov.in / UMANG. Verified: Nov 2026.
   - J&K Integrated Social Security Pension (Old Age, Widow, Specially Abled): Social Welfare Dept J&K. Docs: Domicile Certificate J&K, Age/Income/Medical/Death Certificate, Ration Card, Bank Passbook. Official: https://jansugam.jk.gov.in / UMANG. Verified: Nov 2026.
   - Ladli Beti Scheme (J&K): Social Welfare Dept J&K. ₹1,000/month deposited for eligible girl child born in districts with low sex ratio; matures at age 21 (~₹6.5 lakh). Docs: Birth Certificate, J&K Domicile, Income Certificate (<₹75,000/yr), Parent Aadhaar. Official: https://jk.gov.in / JanSugam. Verified: Nov 2026.
   - Ayushman Bharat PM-JAY SEHAT (J&K): ₹5 lakh annual health cover per family for all J&K residents. Docs: Aadhaar, Ration Card / Family ID. Official: https://beneficiary.nha.gov.in. Verified: Nov 2026.
   - National Scholarship Portal (NSP) & J&K Post-Matric Scholarships: Pre-Matric, Post-Matric, Merit-cum-Means. Docs: Aadhaar, School/College Bonafide, Previous Marksheet, Income & Domicile Certificate, Bank Passbook. Official: https://scholarships.gov.in. Verified: Nov 2026.
2. Agriculture & Horticulture (J&K):
   - Apple Scab / Alternaria Leaf Spot / Powdery Mildew: Prune infected twigs in winter, clear fallen leaves, follow SKUAST-K / Dept of Horticulture spray schedule (contact nearest Krishi Vigyan Kendra - KVK Bhaderwah, Doda, Baramulla). Never recommend unverified chemical dosages; advise consulting Block Horticulture Officer or KVK helpline 1800-180-1551.
   - Saffron (Pampore), High-Density Apple, Walnut, Bhaderwah Rajmash, Maize (Doda). Mandi Prices via AGMARKNET (https://agmarknet.gov.in). Weather alerts via IMD (https://api.imd.gov.in).
3. Jobs & Competitive Exams:
   - JKSSB (https://jkssb.nic.in): Patwari, Junior Assistant, Supervisor, Constable recruitment notices.
   - JKPSC (https://jkpsc.nic.in): KAS / Combined Competitive & Gazetted posts.
   - National Career Service (https://www.ncs.gov.in) & NHM J&K (https://jknhm.com).
4. Health & Emergency Contacts (J&K):
   - Emergency Medical Ambulance: 108 | Maternal/Child 102 | Police/Emergency: 112 | Senior Citizen Helpline: 14567 | Kisan Call Centre: 1800-180-1551.
   - Pilot Hospitals: SDH Bhaderwah, District Hospital Doda, GMC Baramulla, SMHS Srinagar, GMC Jammu.
5. Education & Skills:
   - DIKSHA (https://diksha.gov.in), JKBOSE (https://jkbose.nic.in), NCERT ePathshala, Spoken English & Digital Literacy via CSC Gramin e-Store / PMGDISHA.
6. Animal & Sheep Husbandry Department (All India + Jammu & Kashmir Directorates):
   - Toll-Free Livestock Emergency Helpline: 1962 (Mobile Veterinary Units under LHDCP — doorstep treatment, AI, free FMD/PPR/HS/ET vaccines).
   - National Livestock Mission (NLM): 50% back-ended capital subsidy (up to ₹25–50 Lakh) via https://nlm.udyamimitra.in for Sheep/Goat breeding farms (100–500 females), Rural Poultry mother units, Piggery, and Fodder/Silage units.
   - Integrated Sheep Development Scheme (ISDS, J&K Sheep Husbandry Dept): Subsidy & unit support (25 Ewes + 1 Ram / shearing machines / migratory breeder support) via Sheep Extension Centres (SECs) & J&K JanSugam (https://jansugam.jk.gov.in).
   - Integrated Dairy Development Scheme (IDDS, J&K Animal Husbandry Dept): 50% subsidy on milch cows/buffaloes (2–20 animals), milking machines, bulk milk coolers, paneer/khoya units & milk vans via Animal Husbandry Dept J&K / JanSugam.
   - Holistic Agriculture Development Programme (HADP, J&K): Commercial sheep/goat farming, high-yield dairy clusters, backyard poultry & Pashmina/Kagani genetics; free farmer training via DAKSH Kisan (https://dakskisan.jk.gov.in).
   - Kisan Credit Card (KCC) for Animal Husbandry & Fisheries: Working capital up to ₹1.60 Lakh collateral-free (up to ₹3 Lakh with tie-up) at 4% effective interest after 3% prompt-repayment subvention via nearest bank/PM-KISAN.
   - Rashtriya Gokul Mission (RGM) & MAITRI: Free Sex-Sorted Semen AI, indigenous breed conservation (Sahiwal, Red Sindhi, Crossbred Jersey/HF), e-Gopala app (https://dahd.nic.in).
   - Animal Husbandry Infrastructure Development Fund (AHIDF): 3% interest subvention & credit guarantee for dairy processing, meat processing, and animal feed plants via https://ahidf.udyamimitra.in.
   - Dorper Breeding Ram Scheme (Latest 2026, Directorate of Sheep Husbandry J&K & DAHD): 50%–75% subsidised high-genetic-merit Dorper Breeding Rams distributed through Sheep Extension Centres (SECs), Govt. Sheep Breeding Farms & DSHO / J&K JanSugam (https://jksheephusbandryjammu.nic.in) for flock owners with 10–25 tagged ewes to double mutton growth rate.
   - Regional Centres: SDH Veterinary Bhaderwah, SEC & Sub-Divisional Sheep Office Bhaderwah, CAHO Doda, DSHO Baramulla. Recommended breeds: Dorper Breeding Ram (mutton crossbreeding), Kashmiri Merino & Rambouillet (wool/mutton), Bhakarwali/Beetal goats, Crossbred Jersey/HF & Sahiwal cattle, Murrah buffalo, Vanaraja/Gramapriya poultry.
7. All-India Crops, Market Rates & Certified Seeds Portals:
   - Official Seed Portals: SATHI Seed Traceability Portal (https://sathi.dac.gov.in), National Seeds Corporation NSC (https://www.indiaseeds.com), SeedNet India (https://seednet.gov.in), AGMARKNET (https://agmarknet.gov.in), e-NAM (https://enam.gov.in).
   - Seed Subsidies: National Food Security Mission (NFSM) & Sub-Mission on Seeds & Planting Material (SMSP) provide ~40–50% subsidy on certified HYV seeds (Wheat HD-3086/DBW-187/Shalimar Wheat-2 ₹24–26/kg subsidised vs ₹44–48 market; Paddy PB-1121/PR-126; Maize DHM-117; Bajra HHB-67; Chana JG-11; Mustard RH-749/PM-31; Bhaderwah Rajmash; Potato Kufri Chipsona-1/Jyoti; Fodder Berseem BL-42 & Kent Oats; High-Density M-9 Apple & Walnut saplings under HADP/MIDH).
`;

type ChatRoleId = 'gram_sahayak' | 'krishi_mitra' | 'shiksha_guru' | 'quick_help';

interface RoleConfig {
  label: string;
  model: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
  systemPromptPrefix: string;
}

const CHAT_ROLE_CONFIGS: Record<ChatRoleId, RoleConfig> = {
  gram_sahayak: {
    label: 'Gram Sahayak',
    model: 'gemini-4-hydrogen',
    systemPromptPrefix:
      'You are Gram Sahayak, a warm, knowledgeable, all-purpose AI assistant for GRAM GYAN citizens. Answer EVERY question the user asks completely—whether about government schemes, documents, science, maths, coding, general knowledge, history, health awareness, recipes, creative writing, or daily life. Never refuse or skip a question for being outside schemes; for official scheme applications, also mention the right government portal (JanSugam, UMANG, DigiLocker, PM-KISAN, CSC).',
  },
  krishi_mitra: {
    label: 'Krishi Mitra',
    model: 'gemini-4-hydrogen',
    systemPromptPrefix:
      'You are Krishi Mitra, an all-purpose AI advisor specializing in Indian farming, crops, certified seeds, animal & sheep husbandry, and rural markets, who also gladly answers any general knowledge, science, maths, or daily-life question the user asks. Answer every question directly without skipping; for crop spraying dosages or livestock emergencies, remind users to confirm with KVK (1800-180-1551) or 1962 MVU.',
  },
  shiksha_guru: {
    label: 'Shiksha Guru',
    model: 'gemini-4-hydrogen',
    systemPromptPrefix:
      'You are Shiksha Guru, an encouraging all-subject AI tutor and helper for students and citizens. Answer EVERY question directly—including maths step-by-step, science, coding, JKBOSE/NCERT homework, JKSSB/UPSC prep, English grammar, scholarships, and any general topic—without ever skipping a question.',
  },
  quick_help: {
    label: 'Quick Help (Fast)',
    model: 'gemini-3.1-flash-lite',
    systemPromptPrefix:
      'You are GRAM GYAN Quick Help, a fast, helpful all-purpose AI assistant. Answer EVERY question of any type directly and clearly (helplines, translations, math, GK, tech, farming, schemes, or multi-part questions) without skipping any part.',
  },
};

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out under high demand.`)), ms)
    ),
  ]);
}

function parseGeminiError(err: unknown): { message: string; status: number; isTransient: boolean } {
  const raw = err instanceof Error ? err.message : String(err ?? 'Unknown error');
  let message = raw;
  let code = 502;
  let statusStr = '';

  try {
    const parsed = JSON.parse(raw);
    if (parsed?.error?.message) {
      message = String(parsed.error.message);
    }
    if (typeof parsed?.error?.code === 'number') {
      code = parsed.error.code;
    }
    if (typeof parsed?.error?.status === 'string') {
      statusStr = parsed.error.status;
    }
  } catch {
    // raw string message
  }

  const lower = `${message} ${statusStr}`.toLowerCase();
  const isAuthError =
    lower.includes('permission_denied') ||
    lower.includes('api_key_invalid') ||
    lower.includes('api key not valid') ||
    code === 403;

  if (isAuthError) {
    return {
      message: message && message !== raw ? message : 'Please check your GEMINI_API_KEY in Settings > Secrets.',
      status: 403,
      isTransient: false,
    };
  }

  const isTransient =
    code === 500 ||
    code === 502 ||
    code === 503 ||
    code === 504 ||
    code === 429 ||
    code === 404 ||
    statusStr === 'UNAVAILABLE' ||
    statusStr === 'RESOURCE_EXHAUSTED' ||
    statusStr === 'INTERNAL' ||
    lower.includes('high demand') ||
    lower.includes('unavailable') ||
    lower.includes('overloaded') ||
    lower.includes('timed out') ||
    lower.includes('empty response') ||
    lower.includes('fetch failed') ||
    lower.includes('network');

  return { message, status: isTransient ? 503 : code >= 400 ? code : 502, isTransient };
}

function extractChatReplyText(response: {
  text?: string;
  candidates?: Array<{ content?: { parts?: Array<{ text?: string; thought?: boolean }> } }>;
}): string {
  const direct = (response.text ?? '').trim();
  if (direct) return direct;
  const parts = response.candidates?.[0]?.content?.parts ?? [];
  return parts
    .filter((p) => !p.thought && typeof p.text === 'string' && p.text.trim())
    .map((p) => p.text!.trim())
    .join('\n')
    .trim();
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '12mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'gram-gyan-api', timestamp: new Date().toISOString() });
  });

  app.post('/api/chat', async (req, res) => {
    const {
      message,
      history = [],
      roleId = 'gram_sahayak',
      language = 'English',
      district = 'Bhaderwah',
    } = req.body ?? {};

    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Please enter a message to continue the conversation.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error:
          'Gemini API key is not configured on the server. Please configure GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const safeRoleId: ChatRoleId =
      roleId in CHAT_ROLE_CONFIGS ? (roleId as ChatRoleId) : 'gram_sahayak';
    const roleConfig = CHAT_ROLE_CONFIGS[safeRoleId];

    // Sanitize multi-turn conversation history into Gemini Content objects
    const rawHistory = Array.isArray(history) ? history.slice(-16) : [];
    const formattedHistory: { role: 'user' | 'model'; parts: { text: string }[] }[] = [];
    for (const item of rawHistory) {
      const role = item?.role === 'model' ? 'model' : item?.role === 'user' ? 'user' : null;
      const text = typeof item?.text === 'string' ? item.text.trim() : '';
      if (!role || !text) continue;
      // Ensure history starts with 'user' and alternates cleanly
      if (formattedHistory.length === 0 && role !== 'user') continue;
      const last = formattedHistory[formattedHistory.length - 1];
      if (last && last.role === role) {
        last.parts[0].text += `\n${text}`;
      } else {
        formattedHistory.push({ role, parts: [{ text }] });
      }
    }
    // Trim trailing 'user' message if caller accidentally included current turn
    if (formattedHistory.length > 0 && formattedHistory[formattedHistory.length - 1].role === 'user') {
      formattedHistory.pop();
    }

    const systemInstruction = `${roleConfig.systemPromptPrefix}
USER CONTEXT: District ${district}, Jammu & Kashmir | Preferred Language: ${language}.
RESPONSE RULES:
1. ANSWER EVERY QUESTION: Answer ANY type of question the user asks (general knowledge, maths, science, coding, essays, stories, health tips, cooking, travel, school homework, farming, crops & seeds, animal/sheep husbandry, or government schemes). NEVER skip, deflect, or refuse a normal question.
2. ANSWER ALL PARTS COMPLETELY: If the user asks 2, 3, or multiple questions in one message (numbered, bulleted, or combined), number and answer EVERY SINGLE ONE clearly and completely without omitting or skipping any part.
3. LANGUAGE & VOICE CLARITY: Reply in ${language} (or naturally match the language/script of the user's message such as Hindi, English, Marathi, Kannada, Tamil, Telugu, Bengali, Gujarati, Punjabi, Malayalam, Urdu, Dogri, or Kashmiri) in clear, warm, natural sentences suitable for reading and listening aloud. Use clean plain text without markdown asterisks (**).
4. VERIFIED LOCAL INFO: For J&K/India schemes, crops, seeds, or veterinary care, use the verified facts below accurately. Never fabricate official scheme IDs or exam dates; if something depends on a live portal, still answer the question fully and suggest the relevant official portal for live verification.

${VERIFIED_GROUNDING_CONTEXT}`;

    const modelOrder: ('gemini-4-hydrogen' | 'gemini-3.1-flash-lite')[] =
      roleConfig.model === 'gemini-4-hydrogen'
        ? ['gemini-4-hydrogen', 'gemini-3.1-flash-lite']
        : ['gemini-3.1-flash-lite', 'gemini-4-hydrogen'];

    let lastParsedError: { message: string; status: number } = {
      message: 'Unable to reach Gemini Chat service.',
      status: 502,
    };

    for (const candidateModel of modelOrder) {
      const isPrimary = candidateModel === modelOrder[0];
      const maxAttempts = isPrimary && candidateModel === 'gemini-3.1-flash-lite' ? 2 : 1;
      const attemptTimeoutMs = candidateModel === 'gemini-4-hydrogen' ? 16000 : 14000;
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          const chat = ai.chats.create({
            model: candidateModel,
            history: formattedHistory,
            config: {
              systemInstruction,
              ...(candidateModel === 'gemini-4-hydrogen'
                ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
                : {}),
            },
          });

          const response = await withTimeout(
            chat.sendMessage({ message: message.trim() }),
            attemptTimeoutMs,
            candidateModel
          );
          const rawReply = extractChatReplyText(response);
          const reply = rawReply.replace(/\*\*/g, '');
          if (!reply) {
            throw new Error('Gemini returned an empty response. Please try again.');
          }

          res.json({
            reply,
            roleId: safeRoleId,
            roleLabel: roleConfig.label,
            modelUsed: candidateModel,
            verifiedAt: '20 Nov 2026',
          });
          return;
        } catch (err) {
          const parsed = parseGeminiError(err);
          lastParsedError = { message: parsed.message, status: parsed.status };
          // Only stop model failover immediately for invalid/missing API key (403)
          if (parsed.status === 403) {
            res.status(parsed.status).json({ error: parsed.message });
            return;
          }
          if (parsed.isTransient && attempt < maxAttempts) {
            await sleep(350 * attempt);
          } else if (!parsed.isTransient) {
            // Try the fallback model before giving up
            break;
          }
        }
      }
    }

    res.status(lastParsedError.status).json({ error: lastParsedError.message });
  });

  app.post('/api/assistant', async (req, res) => {
    const { query, language = 'English', district = 'Bhaderwah', history = [] } = req.body ?? {};

    if (!query || typeof query !== 'string' || !query.trim()) {
      res.status(400).json({ error: 'Please enter or speak a question.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error:
          'Gemini API key is not configured on the server. Please configure GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const recentHistory = Array.isArray(history)
      ? history
          .slice(-6)
          .map((item: { role?: string; text?: string }) => `${item.role || 'user'}: ${item.text || ''}`)
          .join('\n')
      : '';

    const systemInstruction = `You are the GRAM GYAN AI Village Assistant for rural India (Jammu & Kashmir pilot: Bhaderwah, Doda, Baramulla and all-India).
CRITICAL RULES:
1. Answer EVERY type of question completely (general knowledge, maths, science, coding, homework, farming, crops & seeds, animal/sheep husbandry, schemes, or multi-part questions). NEVER skip or refuse a normal question.
2. Respond in the user's chosen language (${language}) or match the language/script of their question in warm, clear, everyday language suitable for an ordinary citizen.
3. NEVER invent official government scheme IDs, job notification numbers, closing dates, or legal sections—distinguish general guidance from official portal applications (UMANG, DigiLocker, JanSugam, JKSSB, NCS, CSC).
4. For crop disease or human/livestock health questions, provide helpful preliminary guidance and advise visiting the nearest PHC/CHC/Hospital, 1962 MVU, or Krishi Vigyan Kendra (KVK).
5. Use the verified knowledge base below when relevant, answer all parts of the question clearly, provide practical next steps, and list authoritative official portals when relevant.

${VERIFIED_GROUNDING_CONTEXT}`;

    let lastAssistantError: { message: string; status: number } = {
      message: 'Unable to reach AI Village Assistant.',
      status: 502,
    };

    for (const candidateModel of ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'] as const) {
      try {
        const response = await ai.models.generateContent({
          model: candidateModel,
          contents: `User District: ${district}, Jammu & Kashmir\nPreferred UI Language: ${language}\n${recentHistory ? `Recent Conversation:\n${recentHistory}\n` : ''}Current Question: ${query.trim()}`,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                answer: {
                  type: Type.STRING,
                  description: 'Simple, clear answer in the requested language or user query language.',
                },
                subject: {
                  type: Type.STRING,
                  description: 'Detected subject area such as Government Schemes, Farming, Jobs, Health, Education, Banking, or Village Services.',
                },
                checklist: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Required documents or step-by-step action checklist for the villager.',
                },
                officialSources: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      url: { type: Type.STRING },
                    },
                  },
                  description: 'Verified official government or public portals relevant to the answer.',
                },
                verificationNote: {
                  type: Type.STRING,
                  description: 'Brief note stating verification status and reminding the user to verify/apply on official portals or CSC.',
                },
                followUps: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: '2 to 3 natural short follow-up questions the villager might ask next.',
                },
              },
              required: ['answer', 'subject', 'checklist', 'officialSources', 'verificationNote', 'followUps'],
            },
          },
        });

        const rawText = (response.text ?? '{}').trim();
        const parsed = JSON.parse(rawText);
        res.json({
          ...parsed,
          verifiedAt: '20 Nov 2026',
        });
        return;
      } catch (err) {
        const parsed = parseGeminiError(err);
        lastAssistantError = { message: parsed.message, status: parsed.status };
        if (!parsed.isTransient) {
          res.status(parsed.status).json({ error: parsed.message });
          return;
        }
      }
    }

    res.status(lastAssistantError.status).json({ error: lastAssistantError.message });
  });

  const TTS_ALLOWED_VOICES = new Set(['Kore', 'Zephyr', 'Charon', 'Puck', 'Fenrir']);

  app.post('/api/tts', async (req, res) => {
    const {
      text,
      language = 'English (India)',
      gender = 'female',
      voiceName,
    } = req.body ?? {};

    if (!text || typeof text !== 'string' || !text.trim()) {
      res.status(400).json({ error: 'Text is required for speech synthesis.' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        error:
          'Gemini API key is not configured on the server. Please configure GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const aiTts = new GoogleGenAI({
      apiKey,
      apiVersion: 'v1beta',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const cleanedText = text
      .replace(/https?:\/\/\S+/gi, '')
      .replace(/\*\*/g, '')
      .replace(/[#_`]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 1200);

    if (!cleanedText) {
      res.status(400).json({ error: 'No speakable text found in message.' });
      return;
    }

    const safeGender = gender === 'male' ? 'male' : 'female';
    const selectedVoice =
      typeof voiceName === 'string' && TTS_ALLOWED_VOICES.has(voiceName)
        ? voiceName
        : safeGender === 'male'
          ? 'Charon'
          : 'Kore';

    const stylePrompt = `Speak warmly, naturally, and with crystal-clear everyday conversational pronunciation in ${String(
      language
    )}, suited for rural Indian citizens.`;

    let lastTtsError: { message: string; status: number } = {
      message: 'Unable to synthesize speech right now.',
      status: 502,
    };

    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await withTimeout(
          aiTts.models.generateContent({
            model: 'gemini-3.8-flash-lite-tts',
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    text: cleanedText,
                    speechMetadata: {
                      style: stylePrompt,
                    },
                  },
                ],
              },
            ],
            config: {
              responseModalities: ['AUDIO'],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: selectedVoice },
                },
              },
            },
          }),
          14000,
          'gemini-3.8-flash-lite-tts'
        );

        const part = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
        const base64Audio = part?.data;
        if (!base64Audio) {
          throw new Error('Gemini TTS returned no audio data.');
        }

        res.json({
          audioBase64: base64Audio,
          mimeType: part?.mimeType || 'audio/wav',
          voiceName: selectedVoice,
          language,
        });
        return;
      } catch (err) {
        const parsed = parseGeminiError(err);
        lastTtsError = { message: parsed.message, status: parsed.status };
        if (!parsed.isTransient) {
          res.status(parsed.status).json({ error: parsed.message });
          return;
        }
        if (attempt < 2) {
          await sleep(350);
        }
      }
    }

    res.status(lastTtsError.status).json({ error: lastTtsError.message });
  });

  app.post('/api/stt', async (req, res) => {
    const { audioBase64, mimeType = 'audio/webm', language = 'English (India)' } = req.body ?? {};

    if (!audioBase64 || typeof audioBase64 !== 'string') {
      res.status(400).json({ error: 'Audio data is required for transcription.' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        error:
          'Gemini API key is not configured on the server. Please configure GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const aiStt = new GoogleGenAI({
      apiKey,
      apiVersion: 'v1beta',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const normalizedMime = String(mimeType).split(';')[0].trim() || 'audio/webm';
    const prompt = `Transcribe this spoken audio accurately into clean text in ${String(
      language
    )} (keeping the natural spoken script/language such as Hindi, English, Marathi, Kannada, Tamil, Telugu, Bengali, Gujarati, Punjabi, Malayalam, Urdu, Dogri, or Kashmiri). Return ONLY the exact transcribed text with proper punctuation, no labels or commentary.`;

    let lastSttError: { message: string; status: number } = {
      message: 'Unable to transcribe audio right now.',
      status: 502,
    };

    for (const candidateModel of ['gemini-3.5-transcribe', 'gemini-4-hydrogen'] as const) {
      try {
        const response = await withTimeout(
          aiStt.models.generateContent({
            model: candidateModel,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: normalizedMime,
                    data: audioBase64,
                  },
                },
                { text: prompt },
              ],
            },
          }),
          candidateModel === 'gemini-3.5-transcribe' ? 12000 : 10000,
          candidateModel
        );

        const transcript = (response.text ?? '').trim();
        res.json({
          transcript,
          modelUsed: candidateModel,
          language,
        });
        return;
      } catch (err) {
        const parsed = parseGeminiError(err);
        lastSttError = { message: parsed.message, status: parsed.status };
        if (!parsed.isTransient && parsed.status !== 404) {
          res.status(parsed.status).json({ error: parsed.message });
          return;
        }
      }
    }

    res.status(lastSttError.status).json({ error: lastSttError.message });
  });

  app.post('/api/crop-detect', async (req, res) => {
    const {
      imageBase64,
      mimeType = 'image/jpeg',
      language = 'English (India)',
      district = 'Bhaderwah',
      userNote = '',
    } = req.body ?? {};

    if (!imageBase64 || typeof imageBase64 !== 'string' || imageBase64.trim().length < 32) {
      res.status(400).json({ error: 'Please capture or upload a clear crop photo to analyze.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error:
          'Gemini API key is not configured on the server. Please configure GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '').trim();
    const normalizedMime = String(mimeType).split(';')[0].trim() || 'image/jpeg';
    const safeNote = typeof userNote === 'string' ? userNote.trim().slice(0, 300) : '';

    const systemInstruction = `You are a senior Indian & Himalayan Agronomist, Plant Pathologist, and Crop Vision Specialist for GRAM GYAN.
Analyze the captured camera image carefully at a high scientific and practical level.
RULES:
1. Identify the exact crop, fruit, vegetable, seed, or plant species (if visible) along with its Hindi / regional Indian name and likely variety or growth stage.
2. Inspect leaves, stems, fruits, grains, or soil carefully for fungal/bacterial/viral lesions, pests (aphids, mites, borers), or nutrient deficiencies (N, P, K, Zn, Fe, B).
3. If the photo does NOT contain a plant, crop, leaf, seed, fruit, or agricultural field, set isPlantOrCrop to false, healthStatus to "Unclear Image", severity to "None", and clearly ask the farmer to point the camera closely at the crop leaf, stem, or produce in good daylight.
4. Provide safe, actionable organic and immediate field steps first. For chemical sprays, mention general scientific group guidance only and ALWAYS remind the farmer to verify exact dosage with their nearest Krishi Vigyan Kendra (KVK, Helpline 1800-180-1551) or Block Agriculture/Horticulture Officer.
5. Write all descriptive fields cleanly in ${String(language)} (or simple clear ${String(language)}/English agricultural terms easy for farmers in ${String(district)} to understand). No markdown asterisks (**).`;

    const textPrompt = `District Context: ${String(district)}, India
Preferred Output Language: ${String(language)}
${safeNote ? `Farmer Observation Note: ${safeNote}\n` : ''}Perform high-level AI crop identification, health & disease detection, nutrient/soil care, and harvest/seed guidance for the attached photo.`;

    let lastDetectError: { message: string; status: number } = {
      message: 'Unable to analyze crop image right now.',
      status: 502,
    };

    for (const candidateModel of ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'] as const) {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const response = await withTimeout(
            ai.models.generateContent({
              model: candidateModel,
              contents: {
                parts: [
                  {
                    inlineData: {
                      mimeType: normalizedMime,
                      data: cleanBase64,
                    },
                  },
                  { text: textPrompt },
                ],
              },
              config: {
                systemInstruction,
                ...(candidateModel === 'gemini-4-hydrogen'
                  ? { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH } }
                  : {}),
                responseMimeType: 'application/json',
                responseSchema: {
                  type: Type.OBJECT,
                  properties: {
                    isPlantOrCrop: {
                      type: Type.BOOLEAN,
                      description: 'True if the photo clearly depicts a crop, plant, leaf, fruit, vegetable, or seed.',
                    },
                    cropName: {
                      type: Type.STRING,
                      description: 'Identified crop or plant name (e.g., Apple, Bhaderwah Rajmash, Wheat, Paddy, Maize, Tomato).',
                    },
                    localName: {
                      type: Type.STRING,
                      description: 'Common Hindi or regional Indian name of the crop.',
                    },
                    varietyOrStage: {
                      type: Type.STRING,
                      description: 'Observed variety clues or growth stage (e.g., Vegetative / Flowering / Fruit Set / Grain Filling).',
                    },
                    confidencePercent: {
                      type: Type.INTEGER,
                      description: 'Detection confidence percentage from 0 to 100.',
                    },
                    healthStatus: {
                      type: Type.STRING,
                      description: 'One of: Healthy, Mild Stress / Deficiency, Pest / Disease Alert, Nutrient Deficiency, Unclear Image.',
                    },
                    detectedIssue: {
                      type: Type.STRING,
                      description: 'Specific disease, pest, nutrient deficiency, or "No visible disease or pest symptoms".',
                    },
                    severity: {
                      type: Type.STRING,
                      description: 'One of: None, Low, Moderate, High.',
                    },
                    visualSymptoms: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                      description: '2 to 4 concrete visual symptoms observed in the image.',
                    },
                    organicAndImmediateActions: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                      description: '3 to 4 practical immediate & organic field actions.',
                    },
                    chemicalAndKvkGuidance: {
                      type: Type.STRING,
                      description: 'Safe scientific & KVK advisory guidance including Helpline 1800-180-1551.',
                    },
                    recommendedFertilizerOrCare: {
                      type: Type.STRING,
                      description: 'Targeted NPK, micronutrient, irrigation, or soil care recommendation.',
                    },
                    estimatedHarvestOrSeedTip: {
                      type: Type.STRING,
                      description: 'Harvest readiness, storage, or certified seed selection tip.',
                    },
                    spokenSummary: {
                      type: Type.STRING,
                      description: 'Clear 2 to 3 sentence plain-text summary suitable for read-aloud TTS in the requested language.',
                    },
                  },
                  required: [
                    'isPlantOrCrop',
                    'cropName',
                    'localName',
                    'varietyOrStage',
                    'confidencePercent',
                    'healthStatus',
                    'detectedIssue',
                    'severity',
                    'visualSymptoms',
                    'organicAndImmediateActions',
                    'chemicalAndKvkGuidance',
                    'recommendedFertilizerOrCare',
                    'estimatedHarvestOrSeedTip',
                    'spokenSummary',
                  ],
                },
              },
            }),
            candidateModel === 'gemini-4-hydrogen' ? 24000 : 16000,
            candidateModel
          );

          const rawText = extractChatReplyText(response);
          const cleanedJson = rawText.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
          const parsed = JSON.parse(cleanedJson || '{}');
          res.json({
            ...parsed,
            modelUsed: candidateModel,
          });
          return;
        } catch (err) {
          const parsed = parseGeminiError(err);
          lastDetectError = { message: parsed.message, status: parsed.status };
          if (parsed.status === 403) {
            res.status(parsed.status).json({ error: parsed.message });
            return;
          }
          if (parsed.isTransient && attempt < 2) {
            await sleep(450);
          } else if (!parsed.isTransient) {
            break;
          }
        }
      }
    }

    res.status(lastDetectError.status).json({ error: lastDetectError.message });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GRAM GYAN server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start GRAM GYAN server:', err);
  process.exit(1);
});
